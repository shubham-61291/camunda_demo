@echo off
setlocal
cd /d "%~dp0"

echo.
echo ================================================
echo  Shubham Singh ProcessOS Demo
echo ================================================
echo.

if not exist .venv\Scripts\python.exe (
  echo Creating the local Python environment...
  py -3.11 -m venv .venv
  if errorlevel 1 (
    echo ERROR: Python 3.11 was not found. Install Python 3.11 or newer and retry.
    pause
    exit /b 1
  )
)

call .venv\Scripts\python.exe -m pip install --upgrade pip
if errorlevel 1 goto :pip_error
call .venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 goto :pip_error

if not exist .env (
  copy .env.example .env >nul
  echo Created .env. Edit it and set only OPENAI_API_KEY, then run run.bat again.
  notepad .env
  pause
  exit /b 0
)

findstr /R /C:"^OPENAI_API_KEY=[^ ]" .env >nul
if errorlevel 1 (
  echo OPENAI_API_KEY appears empty in .env.
  echo Add your OpenAI key to .env, then run run.bat again.
  notepad .env
  pause
  exit /b 2
)

echo Starting ProcessOS on http://127.0.0.1:8090
echo Camunda status is checked in the UI. ProcessOS will install the official Camunda CLI and start the local cluster when you choose Install / start Camunda or authorize a workflow run.
echo The .env must contain only OPENAI_API_KEY. API credentials and URLs are collected in the chat session.
echo.
call .venv\Scripts\python.exe -m uvicorn main:app --host 127.0.0.1 --port 8090
exit /b %errorlevel%

:pip_error
echo ERROR: Could not install Python dependencies. Check internet access and retry.
pause
exit /b 1
