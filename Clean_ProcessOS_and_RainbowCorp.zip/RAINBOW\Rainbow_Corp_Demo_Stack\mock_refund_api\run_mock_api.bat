@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (echo Install Python 3.11+ first.& pause & exit /b 1)
if not exist ".env" (
  copy ".env.example" ".env" >nul
  echo Created .env. Set DEMO_REFUND_API_KEY to the same value configured in local_bridge\.env.
  notepad .env
  echo Save .env, then run run_mock_api.bat again.
  pause
  exit /b 0
)
if not exist ".venv\Scripts\python.exe" (py -3 -m venv .venv)
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 (pause & exit /b 1)
echo Mock refund API running on http://127.0.0.1:8001
".venv\Scripts\python.exe" -m uvicorn mock_bank_api:app --host 127.0.0.1 --port 8001
pause
