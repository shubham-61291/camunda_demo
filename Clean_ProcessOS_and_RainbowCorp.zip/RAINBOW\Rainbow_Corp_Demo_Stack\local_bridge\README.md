# Rainbow Corp — local workflow bridge

This component is separate from `rainbow_corp_app`. It runs on the same PC, calls the local app at `127.0.0.1:8000`, and connects outward to the configured workflow REST API. The local app does not contain a workflow SDK, BPMN, workflow credentials, job workers, routing rules, or refund-execution code.

## Configure

1. Copy `.env.example` to `.env`.
2. Set `CAMUNDA_REST_ADDRESS` to the REST API address supplied for your workflow cluster (with or without the `/v2` suffix).
3. Fill `CAMUNDA_CLIENT_ID` and `CAMUNDA_CLIENT_SECRET`; leave `CAMUNDA_AUTH_MODE=oauth` for client-credentials authentication.
4. Make sure `INTEGRATION_API_TOKEN` matches the value in `rainbow_corp_app/.env` (or both use the shared local-demo default).
5. Ensure the app and Mock Refund API are running before starting this bridge.

Do not share or commit `.env` credentials.

## Deploy the process

Run `deploy_process.bat` from this folder after configuring `.env`. It deploys `../workflow_assets/rainbow-refund-process.bpmn` through the REST API. The BPMN process ID is `rainbow-refund-process`.

## Start the bridge

Run `run_bridge.bat`. Before consuming requests it checks the local app, Mock Refund API and workflow authentication. It then:

- polls the local app for new requests every 60 seconds;
- starts one workflow instance per claimed request;
- activates each BPMN service-task type in independent long-poll loops;
- creates the local human-review record only when the BPMN selects that branch;
- checks human decisions every 5 seconds and completes the corresponding workflow user task;
- calls the Mock Refund API only in the `execute-demo-refund` job handler, after the workflow gateways permit it;
- writes confirmed results back to the app's generic integration API.

This is a local interview demo. The mock API never moves real money. End-to-end execution against a live cluster requires valid cluster credentials, process deployment and confirmation of REST API compatibility for that cluster.
