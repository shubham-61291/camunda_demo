"""Local integration bridge, deliberately separate from the Rainbow Corp web app.

It polls the local app for queued requests, starts process instances through the
external workflow REST API, runs workflow job workers, and returns workflow
results to the app. The app itself has no workflow-engine SDK or credentials.
"""
from __future__ import annotations

import asyncio
import logging
import os
from pathlib import Path
from typing import Any

import httpx
from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")

APP_BASE_URL = os.getenv("APP_BASE_URL", "http://127.0.0.1:8000").rstrip("/")
INTEGRATION_API_TOKEN = os.getenv("INTEGRATION_API_TOKEN", "").strip()
MOCK_REFUND_API_URL = os.getenv("DEMO_REFUND_API_URL", "http://127.0.0.1:8001/api/v1/refunds")
DEMO_REFUND_API_KEY = os.getenv("DEMO_REFUND_API_KEY", "").strip()
CAMUNDA_REST_ADDRESS = os.getenv("CAMUNDA_REST_ADDRESS", "").strip().rstrip("/")
CAMUNDA_AUTH_MODE = os.getenv("CAMUNDA_AUTH_MODE", "oauth").strip().lower()
CAMUNDA_PROCESS_DEFINITION_ID = os.getenv("CAMUNDA_PROCESS_DEFINITION_ID", "rainbow-refund-process").strip()
CAMUNDA_OAUTH_URL = os.getenv("CAMUNDA_OAUTH_URL", "https://login.cloud.camunda.io/oauth/token").strip()
CAMUNDA_CLIENT_ID = os.getenv("CAMUNDA_CLIENT_ID", "").strip()
CAMUNDA_CLIENT_SECRET = os.getenv("CAMUNDA_CLIENT_SECRET", "").strip()
CAMUNDA_TOKEN_AUDIENCE = os.getenv("CAMUNDA_TOKEN_AUDIENCE", "zeebe.camunda.io").strip()
REQUEST_POLL_SECONDS = max(5, int(os.getenv("REQUEST_POLL_SECONDS", "60")))
REVIEW_POLL_SECONDS = max(2, int(os.getenv("REVIEW_POLL_SECONDS", "5")))

logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"), format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("rainbow-local-bridge")


def api_v2_base() -> str:
    if not CAMUNDA_REST_ADDRESS:
        raise RuntimeError("CAMUNDA_REST_ADDRESS is blank. Configure the external workflow API in local_bridge/.env.")
    return CAMUNDA_REST_ADDRESS if CAMUNDA_REST_ADDRESS.endswith("/v2") else f"{CAMUNDA_REST_ADDRESS}/v2"


class WorkflowRestClient:
    """REST API client with OAuth client-credentials token caching."""

    def __init__(self) -> None:
        self.base_url = api_v2_base()
        self.client = httpx.AsyncClient(timeout=httpx.Timeout(20, connect=5))
        self._token = ""
        self._token_expiry = 0.0

    async def close(self) -> None:
        await self.client.aclose()

    async def _access_token(self) -> str:
        loop = asyncio.get_running_loop()
        if self._token and loop.time() < self._token_expiry - 60:
            return self._token
        if not CAMUNDA_CLIENT_ID or not CAMUNDA_CLIENT_SECRET:
            raise RuntimeError("CAMUNDA_CLIENT_ID and CAMUNDA_CLIENT_SECRET are required when CAMUNDA_AUTH_MODE=oauth.")
        response = await self.client.post(
            CAMUNDA_OAUTH_URL,
            data={
                "grant_type": "client_credentials",
                "client_id": CAMUNDA_CLIENT_ID,
                "client_secret": CAMUNDA_CLIENT_SECRET,
                "audience": CAMUNDA_TOKEN_AUDIENCE,
            },
            headers={"Content-Type": "application/x-www-form-urlencoded"},
        )
        response.raise_for_status()
        payload = response.json()
        self._token = str(payload.get("access_token", ""))
        if not self._token:
            raise RuntimeError("OAuth response did not contain access_token.")
        self._token_expiry = loop.time() + float(payload.get("expires_in", 300))
        return self._token

    async def request(
        self,
        method: str,
        path: str,
        *,
        json_body: dict[str, Any] | None = None,
        files: dict[str, tuple[str, bytes, str]] | None = None,
    ) -> dict[str, Any]:
        headers: dict[str, str] = {"Accept": "application/json"}
        if CAMUNDA_AUTH_MODE != "none":
            headers["Authorization"] = f"Bearer {await self._access_token()}"
        response = await self.client.request(
            method,
            f"{self.base_url}/{path.lstrip('/')}",
            json=json_body,
            files=files,
            headers=headers,
        )
        if response.status_code == 204 or not response.content:
            response.raise_for_status()
            return {}
        response.raise_for_status()
        try:
            return response.json()
        except ValueError:
            return {"text": response.text}


class RainbowAppClient:
    def __init__(self) -> None:
        self.client = httpx.AsyncClient(
            base_url=APP_BASE_URL,
            timeout=httpx.Timeout(10, connect=3),
            headers={"X-Integration-Key": INTEGRATION_API_TOKEN},
        )

    async def close(self) -> None:
        await self.client.aclose()

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc, tb):
        await self.close()
        return False

    async def get(self, path: str, params: dict[str, Any] | None = None) -> dict[str, Any]:
        response = await self.client.get(path, params=params)
        response.raise_for_status()
        return response.json()

    async def post(self, path: str, payload: dict[str, Any] | None = None) -> dict[str, Any]:
        response = await self.client.post(path, json=payload or {})
        response.raise_for_status()
        return response.json() if response.content else {}


async def start_workflow_process(rest: WorkflowRestClient, request: dict[str, Any]) -> str:
    """Start one process instance; amount routing happens in the BPMN gateway, not here."""
    request_id = str(request["request_id"])
    variables = {
        "requestId": request_id,
        "orderId": str(request["order_id"]),
        "customerEmail": str(request["customer_email"]),
        "productId": str(request.get("product_id", "")),
        "productName": str(request["product"]),
        "refundAmount": float(request["refund_amount"]),
        "reason": str(request["reason"]),
        "humanApproved": False,
        "reviewerId": "",
        "reviewerComments": "",
    }
    result = await rest.request(
        "POST",
        "/process-instances",
        json_body={
            "processDefinitionId": CAMUNDA_PROCESS_DEFINITION_ID,
            "businessId": request_id,
            "variables": variables,
        },
    )
    process_key = result.get("processInstanceKey") or result.get("processInstanceId") or result.get("key")
    if not process_key:
        raise RuntimeError(f"Workflow API did not return a process-instance key. Response: {str(result)[:1000]}")
    return str(process_key)


async def dispatch_new_requests(app_client: RainbowAppClient, rest: WorkflowRestClient) -> None:
    payload = await app_client.get("/api/integration/requests/pending", {"limit": 100})
    for request in payload.get("records", []):
        request_id = str(request.get("request_id", ""))
        if not request_id:
            continue
        claim = await app_client.post(f"/api/integration/requests/{request_id}/claim")
        if not claim.get("claimed"):
            continue
        log.info("Claimed local request %s; submitting it to the workflow engine.", request_id)
        try:
            process_key = await start_workflow_process(rest, request)
            await app_client.post(
                f"/api/integration/requests/{request_id}/dispatch-result",
                {"outcome": "STARTED", "workflow_reference": process_key},
            )
            log.info("Workflow started for %s (process reference %s).", request_id, process_key)
        except httpx.TimeoutException as exc:
            # The engine could have accepted the request before the network timed out. Do not blindly replay.
            detail = f"Workflow start timed out; outcome may be unknown. Verify in the workflow engine before retrying. {exc}"
            await app_client.post(
                f"/api/integration/requests/{request_id}/dispatch-result",
                {"outcome": "UNKNOWN", "error": detail[:1450]},
            )
            log.error("Start result for %s is unknown; automatic replay is blocked.", request_id)
        except httpx.HTTPStatusError as exc:
            detail = f"Workflow API returned HTTP {exc.response.status_code}: {exc.response.text[:900]}"
            outcome = "UNKNOWN" if exc.response.status_code >= 500 else "FAILED"
            await app_client.post(
                f"/api/integration/requests/{request_id}/dispatch-result",
                {"outcome": outcome, "error": detail[:1450]},
            )
            log.error("Could not start workflow for %s: %s", request_id, detail)
        except Exception as exc:
            detail = f"{type(exc).__name__}: {exc}"
            await app_client.post(
                f"/api/integration/requests/{request_id}/dispatch-result",
                {"outcome": "UNKNOWN", "error": detail[:1450]},
            )
            log.exception("Could not confirm workflow start for %s; automatic replay is blocked.", request_id)


async def sync_pending_review_decisions(app_client: RainbowAppClient, rest: WorkflowRestClient) -> None:
    payload = await app_client.get("/api/integration/review-decisions/pending", {"limit": 100})
    for item in payload.get("records", []):
        review_id = str(item.get("review_id", ""))
        process_key = str(item.get("workflow_reference", ""))
        if not review_id or not process_key:
            # Process-start response may not yet be recorded; keep the decision queued.
            continue
        try:
            result = await rest.request(
                "POST",
                "/user-tasks/search",
                json_body={
                    "filter": {"processInstanceKey": process_key, "state": "CREATED"},
                    "page": {"limit": 100},
                },
            )
            tasks = result.get("items", result.get("userTasks", []))
            task = next((t for t in tasks if str(t.get("state", "CREATED")).upper() == "CREATED"), None)
            if not task:
                # Task might not have become active yet. Retain the decision for next poll.
                continue
            task_key = task.get("userTaskKey") or task.get("key")
            if not task_key:
                log.warning("Review task for %s did not include a task key; decision remains queued.", review_id)
                continue
            approved = str(item.get("reviewer_decision", "")).lower() == "approve"
            await rest.request(
                "POST",
                f"/user-tasks/{task_key}/completion",
                json_body={
                    "variables": {
                        "humanApproved": approved,
                        "reviewerId": str(item.get("reviewer_id", "local reviewer")),
                        "reviewerComments": str(item.get("reviewer_comments", "")),
                    }
                },
            )
            await app_client.post(f"/api/integration/review-decisions/{review_id}/ack")
            log.info("Delivered %s decision for review %s to process %s.", "approval" if approved else "rejection", review_id, process_key)
        except httpx.HTTPStatusError as exc:
            # A missing active task or temporary remote error is retried on a later poll.
            log.warning("Could not deliver review %s yet (HTTP %s); will retry.", review_id, exc.response.status_code)
        except Exception:
            log.exception("Could not deliver review decision %s yet; will retry.", review_id)


async def worker_register_human_review(variables: dict[str, Any], app_client: RainbowAppClient) -> dict[str, Any]:
    request_id = str(variables["requestId"])
    reason = "Workflow rule: refund amount exceeds the configured approval threshold"
    await app_client.post(f"/api/integration/requests/{request_id}/review-required", {"review_reason": reason})
    log.info("Workflow routed %s to the human review queue.", request_id)
    return {"humanReviewRequired": True, "reviewQueueCreated": True}


async def worker_execute_demo_refund(variables: dict[str, Any]) -> dict[str, Any]:
    """Called only when the BPMN service task is activated after its routing/approval gates."""
    request_id = str(variables["requestId"])
    payload = {
        "request_id": request_id,
        "order_id": str(variables["orderId"]),
        "product_id": str(variables.get("productId", "")),
        "product_name": str(variables["productName"]),
        "amount_inr": float(variables["refundAmount"]),
        "customer_email": str(variables["customerEmail"]),
        "reason": str(variables["reason"]),
    }
    try:
        async with httpx.AsyncClient(timeout=10) as client:
            response = await client.post(
                MOCK_REFUND_API_URL,
                json=payload,
                headers={"X-Demo-API-Key": DEMO_REFUND_API_KEY, "Idempotency-Key": request_id},
            )
            response.raise_for_status()
            result = response.json()
        if result.get("status") != "SUCCESS" or not result.get("transaction_id"):
            return {"refundApiStatus": "FAILED", "refundTransactionId": "", "refundApiMessage": str(result.get("message", "Mock API did not confirm success."))[:1800]}
        log.info("Workflow called mock refund API for %s; transaction %s.", request_id, result["transaction_id"])
        return {"refundApiStatus": "SUCCESS", "refundTransactionId": str(result["transaction_id"]), "refundApiMessage": str(result.get("message", "Demo only; no real money moved."))[:1800]}
    except Exception as exc:
        message = f"Mock refund API failed: {type(exc).__name__}: {exc}"[:1800]
        log.error("%s", message)
        return {"refundApiStatus": "FAILED", "refundTransactionId": "", "refundApiMessage": message}


async def worker_sync_refund_result(variables: dict[str, Any], app_client: RainbowAppClient) -> dict[str, Any]:
    request_id = str(variables["requestId"])
    status = str(variables.get("refundApiStatus", "FAILED")).upper()
    if status not in {"SUCCESS", "FAILED"}:
        status = "FAILED"
    payload = {
        "status": status,
        "transaction_id": str(variables.get("refundTransactionId", "")),
        "message": str(variables.get("refundApiMessage", "No response from mock API."))[:1800],
    }
    await app_client.post(f"/api/integration/requests/{request_id}/workflow-result", payload)
    log.info("Workflow result %s for request %s was saved to Rainbow Corp SQLite.", status, request_id)
    return {"workflowResultSaved": True}


async def worker_record_rejection(variables: dict[str, Any], app_client: RainbowAppClient) -> dict[str, Any]:
    request_id = str(variables["requestId"])
    reviewer_id = str(variables.get("reviewerId", "local reviewer"))
    reviewer_comments = str(variables.get("reviewerComments", ""))
    message = "Request rejected by the human reviewer. The refund task was not executed."
    if reviewer_comments:
        message += f" Reviewer note: {reviewer_comments[:1200]}"
    await app_client.post(
        f"/api/integration/requests/{request_id}/workflow-result",
        {"status": "REJECTED", "transaction_id": "", "message": message},
    )
    log.info("Rejection by %s for %s synced to local app.", reviewer_id, request_id)
    return {"rejectionSaved": True}


JOB_FETCH_VARIABLES: dict[str, list[str]] = {
    "register-human-review": ["requestId", "refundAmount"],
    "execute-demo-refund": ["requestId", "orderId", "customerEmail", "productId", "productName", "refundAmount", "reason"],
    "sync-refund-result": ["requestId", "refundApiStatus", "refundTransactionId", "refundApiMessage"],
    "record-refund-rejection": ["requestId", "reviewerId", "reviewerComments"],
}


async def process_activated_job(job_type: str, job: dict[str, Any], app_client: RainbowAppClient, rest: WorkflowRestClient) -> None:
    job_key = str(job.get("jobKey", ""))
    variables = job.get("variables") or {}
    if not job_key:
        log.error("Activated job of type %s has no jobKey; skip completion.", job_type)
        return
    try:
        if job_type == "register-human-review":
            output = await worker_register_human_review(variables, app_client)
        elif job_type == "execute-demo-refund":
            output = await worker_execute_demo_refund(variables)
        elif job_type == "sync-refund-result":
            output = await worker_sync_refund_result(variables, app_client)
        elif job_type == "record-refund-rejection":
            output = await worker_record_rejection(variables, app_client)
        else:
            raise RuntimeError(f"No handler configured for job type {job_type}")
        await rest.request("POST", f"/jobs/{job_key}/completion", json_body={"variables": output})
        log.info("Completed workflow job %s (%s).", job_key, job_type)
    except Exception as exc:
        retries_left = max(0, int(job.get("retries", 3)) - 1)
        message = f"{type(exc).__name__}: {exc}"[:1500]
        try:
            await rest.request(
                "POST",
                f"/jobs/{job_key}/failure",
                json_body={"retries": retries_left, "retryBackoff": 5000, "errorMessage": message},
            )
        except Exception:
            log.exception("Could not report failure for workflow job %s.", job_key)
        log.error("Workflow job %s (%s) failed: %s", job_key, job_type, message)


async def poll_one_job_type_forever(
    job_type: str,
    fetch_variables: list[str],
    app_client: RainbowAppClient,
    rest: WorkflowRestClient,
) -> None:
    """Long-poll one workflow job type independently so one idle type cannot delay another."""
    worker_id = f"rainbow-local-bridge-{os.getpid()}-{job_type}"
    while True:
        try:
            result = await rest.request(
                "POST",
                "/jobs/activation",
                json_body={
                    "type": job_type,
                    "worker": worker_id,
                    "timeout": 10000,
                    "maxJobsToActivate": 5,
                    "fetchVariable": fetch_variables,
                },
            )
            for job in result.get("jobs", []):
                await process_activated_job(job_type, job, app_client, rest)
        except httpx.HTTPStatusError as exc:
            log.error("Job activation for %s returned HTTP %s: %s", job_type, exc.response.status_code, exc.response.text[:700])
            await asyncio.sleep(2)
        except Exception:
            log.exception("Job activation for %s failed; retrying shortly.", job_type)
            await asyncio.sleep(2)


async def poll_workflow_jobs_forever(app_client: RainbowAppClient, rest: WorkflowRestClient) -> None:
    await asyncio.gather(*[
        poll_one_job_type_forever(job_type, fetch_variables, app_client, rest)
        for job_type, fetch_variables in JOB_FETCH_VARIABLES.items()
    ])


async def poll_requests_forever(app_client: RainbowAppClient, rest: WorkflowRestClient) -> None:
    while True:
        try:
            await dispatch_new_requests(app_client, rest)
        except Exception:
            log.exception("Request polling failed; next attempt will occur after the configured interval.")
        await asyncio.sleep(REQUEST_POLL_SECONDS)


async def poll_review_forever(app_client: RainbowAppClient, rest: WorkflowRestClient) -> None:
    while True:
        try:
            await sync_pending_review_decisions(app_client, rest)
        except Exception:
            log.exception("Review-decision polling failed; next attempt will occur after the configured interval.")
        await asyncio.sleep(REVIEW_POLL_SECONDS)


async def main() -> None:
    if not CAMUNDA_REST_ADDRESS:
        print("CAMUNDA_REST_ADDRESS is blank. Configure local_bridge/.env before starting the bridge.")
        raise SystemExit(2)
    if CAMUNDA_AUTH_MODE == "oauth" and (not CAMUNDA_CLIENT_ID or not CAMUNDA_CLIENT_SECRET):
        print("Set CAMUNDA_CLIENT_ID and CAMUNDA_CLIENT_SECRET in local_bridge/.env first.")
        raise SystemExit(2)
    if not INTEGRATION_API_TOKEN:
        print("Set INTEGRATION_API_TOKEN in local_bridge/.env to match rainbow_corp_app/.env.")
        raise SystemExit(2)
    if not DEMO_REFUND_API_KEY:
        print("Set DEMO_REFUND_API_KEY in local_bridge/.env to match mock_refund_api/.env.")
        raise SystemExit(2)
    await run_bridge()


async def run_bridge() -> None:
    os.environ["CAMUNDA_REST_ADDRESS"] = api_v2_base()
    async with RainbowAppClient() as app_client:
        rest = WorkflowRestClient()
        try:
            # Do not start consuming requests unless the two local dependencies and auth are reachable.
            app_health = await app_client.get("/api/integration/health")
            if not app_health.get("ok"):
                raise RuntimeError("Rainbow Corp integration health check did not pass.")
            mock_health_url = MOCK_REFUND_API_URL.rsplit("/api/v1/refunds", 1)[0].rstrip("/") + "/health"
            async with httpx.AsyncClient(timeout=5) as local_client:
                mock_response = await local_client.get(mock_health_url)
                mock_response.raise_for_status()
                mock_health = mock_response.json()
            if mock_health.get("status") != "ok":
                raise RuntimeError("Mock Refund API health check did not pass.")
            if CAMUNDA_AUTH_MODE != "none":
                await rest._access_token()
            log.info("Preflight PASS: Rainbow Corp API, Mock Refund API, and configured workflow authentication.")
            log.info("New requests polled every %ss; human decisions polled every %ss; workflow jobs polled by REST.", REQUEST_POLL_SECONDS, REVIEW_POLL_SECONDS)
            log.info("Rainbow Corp remains standalone. Routing and refund API execution happen only in the deployed process.")
            await asyncio.gather(
                poll_requests_forever(app_client, rest),
                poll_review_forever(app_client, rest),
                poll_workflow_jobs_forever(app_client, rest),
            )
        finally:
            await rest.close()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        log.info("Local integration bridge stopped.")
