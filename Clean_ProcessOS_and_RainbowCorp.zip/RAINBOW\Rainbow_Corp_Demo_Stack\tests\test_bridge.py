from __future__ import annotations
import asyncio
import importlib.util
from pathlib import Path

BRIDGE_PATH = Path(__file__).resolve().parents[1] / "local_bridge" / "bridge.py"
spec = importlib.util.spec_from_file_location("rainbow_bridge_under_test", BRIDGE_PATH)
bridge = importlib.util.module_from_spec(spec)
assert spec and spec.loader
spec.loader.exec_module(bridge)

class FakeAppClient:
    def __init__(self, request_records=None, review_records=None):
        self.request_records = request_records or []
        self.review_records = review_records or []
        self.posts = []
    async def get(self, path, params=None):
        if path == "/api/integration/requests/pending":
            return {"records": self.request_records}
        if path == "/api/integration/review-decisions/pending":
            return {"records": self.review_records}
        raise AssertionError(path)
    async def post(self, path, payload=None):
        self.posts.append((path, payload or {}))
        if path.endswith("/claim"):
            return {"claimed": True}
        return {"ok": True}

class FakeRestClient:
    def __init__(self, process_response=None, task_response=None, error=None):
        self.process_response = process_response or {"processInstanceKey": "PI-123"}
        self.task_response = task_response or {"items": [{"userTaskKey": "UT-999", "state": "CREATED"}]}
        self.error = error
        self.calls = []
    async def request(self, method, path, *, json_body=None, files=None):
        self.calls.append((method, path, json_body))
        if self.error:
            raise self.error
        if path == "/process-instances": return self.process_response
        if path == "/user-tasks/search": return self.task_response
        if path.endswith("/completion"): return {}
        return {}


def sample_request():
    return {"request_id":"REQ-1", "order_id":"ORD-1", "customer_email":"customer@example.com",
            "product_id":"PROD-001", "product":"Wireless Mouse", "refund_amount":1299.0, "reason":"Damaged"}


def test_dispatch_polls_app_and_starts_workflow_then_records_reference():
    app = FakeAppClient([sample_request()])
    rest = FakeRestClient()
    asyncio.run(bridge.dispatch_new_requests(app, rest))
    starts = [call for call in rest.calls if call[0] == "POST" and call[1] == "/process-instances"]
    assert len(starts) == 1, "one claimed refund must create at most one process-start request per bridge dispatch"
    assert ("POST", "/process-instances", starts[0][2]) in rest.calls
    result_calls = [p for p in app.posts if p[0].endswith("/dispatch-result")]
    assert result_calls[0][1] == {"outcome":"STARTED", "workflow_reference":"PI-123"}
    assert all("humanReviewRequired" not in rest_call[2].get("variables", {}) for rest_call in rest.calls if rest_call[1] == "/process-instances")


def test_review_decision_completes_user_task_and_acknowledges_delivery():
    review = {"review_id":"REV-1", "workflow_reference":"PI-123", "reviewer_decision":"Approve",
              "reviewer_id":"Tester", "reviewer_comments":"Test approval"}
    app = FakeAppClient(review_records=[review])
    rest = FakeRestClient()
    asyncio.run(bridge.sync_pending_review_decisions(app, rest))
    completion = [call for call in rest.calls if call[1].endswith("/completion")][0]
    assert completion[2]["variables"]["humanApproved"] is True
    assert app.posts[-1][0].endswith("/REV-1/ack")


def test_review_decision_waits_if_workflow_reference_not_yet_attached():
    review = {"review_id":"REV-2", "workflow_reference":"", "reviewer_decision":"Approve", "reviewer_id":"Tester", "reviewer_comments":""}
    app = FakeAppClient(review_records=[review])
    rest = FakeRestClient()
    asyncio.run(bridge.sync_pending_review_decisions(app, rest))
    assert rest.calls == []
    assert app.posts == []
