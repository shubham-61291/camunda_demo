"""ProcessOS discovery, endpoint probing, and bounded Coder/Tester loop.

Discovery begins generically; deployment compatibility is checked later. Credentials
are held in process memory and environment variables only; they are not sent to the LLM.
"""
from __future__ import annotations

import ast
import json
import os
import re
import socket
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

import httpx
from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent
BUILD_ID = "processos-2026.10.14-audit8"
load_dotenv(BASE_DIR / ".env")

MAX_REACT_ITERATIONS = 3
DEFAULT_MODEL = os.getenv("OPENAI_MODEL", "gpt-4.1-nano")
BPMN_NS = {"bpmn": "http://www.omg.org/spec/BPMN/20100524/MODEL", "zeebe": "http://camunda.org/schema/zeebe/1.0", "xsi": "http://www.w3.org/2001/XMLSchema-instance"}
REQUIRED_JOB_TYPES = {"register-human-review", "execute-demo-refund", "sync-refund-result", "record-refund-rejection"}


def env(name: str, default: str = "") -> str:
    return os.getenv(name, default).strip()


def initial_blueprint() -> dict[str, Any]:
    """Return a credential-free, conversation-populated workflow blueprint."""
    return {
        "project_name": "Shubham Singh ProcessOS Demo",
        "rainbow_stack_dir": "",
        "app_base_url": "",
        "integration_poll_endpoint": "",
        "integration_status_endpoint": "",
        "integration_health_endpoint": "",
        "integration_header_name": "X-Integration-Key",
        "action_api_url": "",
        "action_health_url": "",
        "action_verify_url": "",
        "action_header_name": "X-Demo-API-Key",
        "websocket_url": "",
        "process_id": "chat_refund_process",
        # This value is a runtime fallback, not a user-confirmed business rule.
        "refund_threshold": 5000.0,
        "business_rules": [],
        "camunda_base_url": "http://127.0.0.1:8080/v2",
        "camunda_auth_mode": "none",
    }


def redact_secrets(message: str) -> str:
    """Redact explicit credential syntax without mangling ordinary business prose."""
    text = re.sub(
        r"(?i)(\bAuthorization\s*:\s*)(?:[A-Za-z][A-Za-z0-9_-]*\s+)?[^\s,;]+",
        lambda m: m.group(1) + "[REDACTED]",
        message,
    )
    # Header-like credential names require an explicit ':' or '=' delimiter.
    text = re.sub(
        r"(?i)(\b(?:X-[A-Za-z0-9_-]*(?:key|token|secret)|[A-Za-z][A-Za-z0-9_-]*(?:key|token|secret|password|passwd)|api[-_ ]?key)\s*[:=]\s*)(?:`[^`]*`|'[^']*'|\"[^\"]*\"|[^\s,;&]+)",
        lambda m: m.group(1) + "[REDACTED]",
        text,
    )
    text = re.sub(r"(?i)(\bbearer\s+)[^\s,;]+", r"\1[REDACTED]", text)
    text = re.sub(r"(?i)(https?://[^/@\s]+):([^/@\s]+)@", r"\1:[REDACTED]@", text)
    text = re.sub(r"(?i)([?&](?:token|access_token|api_key|apikey|key|secret|password|authorization|signature|client_secret)=)[^&#\s]+", r"\1[REDACTED]", text)
    # URL fragments are client-side only; drop them before model context/history.
    text = re.sub(r"(?i)((?:https?|wss?)://[^\s#]+)#[^\s]+", r"\1", text)
    return text


def extract_auth(message: str, remembered_header: str = "") -> tuple[str | None, str | None]:
    """Extract credentials only from unambiguous header or labelled-value syntax."""
    authz = re.search(r"(?i)\bAuthorization\s*:\s*((?:Bearer|Basic)\s+[^\s,;]+|[^\s,;&]+)", message)
    if authz:
        return "Authorization", authz.group(1).strip().rstrip(".,;)")
    header_match = re.search(
        r"(?i)\b(X-[A-Za-z0-9_-]*(?:key|token|secret)|[A-Za-z][A-Za-z0-9_-]*(?:key|token|secret|password|passwd)|api[-_ ]?key)\s*[:=]\s*([A-Za-z0-9._~+/=-]+)",
        message,
    )
    if header_match:
        return header_match.group(1).strip(), header_match.group(2).strip().rstrip(".,;)")
    return None, None

def safe_url_for_display(url: str) -> str:
    """Redact URL userinfo and credential-like query values for UI/state/history."""
    from urllib.parse import parse_qsl, urlencode, urlunparse
    parsed = urlparse(url)
    try:
        host = parsed.hostname or ""
        if parsed.port:
            host = f"{host}:{parsed.port}"
        netloc = host
    except ValueError:
        netloc = parsed.netloc.split("@")[ -1]
    sensitive = {"token", "access_token", "api_key", "apikey", "key", "secret", "password", "authorization", "signature", "client_secret"}
    params = []
    for key, value in parse_qsl(parsed.query, keep_blank_values=True):
        if key.lower() in sensitive or any(part in key.lower() for part in ("token", "secret", "password")):
            params.append((key, "[REDACTED]"))
        else:
            params.append((key, value))
    return urlunparse((parsed.scheme, netloc, parsed.path, parsed.params, urlencode(params), ""))


def _validate_probe_url(url: str) -> str | None:
    """Allow local targets plus public TLS endpoints; block metadata and unsafe plain HTTP."""
    parsed = urlparse(url)
    if parsed.scheme not in {"http", "https", "ws", "wss"} or not parsed.hostname:
        return "URL must use http(s):// or ws(s):// and include a hostname."
    if parsed.username or parsed.password:
        return "Credentials embedded in URLs are not accepted. Use an authentication header instead."
    from urllib.parse import parse_qsl
    sensitive_query_names = {"token", "access_token", "api_key", "apikey", "key", "secret", "password", "authorization", "signature", "client_secret"}
    if any(k.lower() in sensitive_query_names or any(part in k.lower() for part in ("token", "secret", "password")) for k, _ in parse_qsl(parsed.query, keep_blank_values=True)):
        return "Credential-like query parameters are blocked. Put API keys/tokens in a header instead."
    host = parsed.hostname.lower()
    if host in {"169.254.169.254", "metadata.google.internal", "metadata.azure.internal"}:
        return "Cloud metadata endpoints are blocked."
    try:
        infos = socket.getaddrinfo(host, parsed.port or (443 if parsed.scheme in {"https", "wss"} else 80), type=socket.SOCK_STREAM)
    except socket.gaierror:
        return "Hostname did not resolve. Check the address and DNS before probing."
    addresses = {str(info[4][0]) for info in infos}
    return _address_policy_error(parsed.scheme, addresses)


def _address_policy_error(scheme: str, addresses: set[str]) -> str | None:
    """Apply the same address policy to initial and repeated DNS resolutions."""
    import ipaddress
    parsed_addresses = set()
    for raw in addresses:
        try:
            parsed_addresses.add(ipaddress.ip_address(raw))
        except ValueError:
            return "DNS returned an invalid IP address; probe blocked."
    if not parsed_addresses:
        return "Hostname did not resolve to an address."
    if any(addr.is_link_local for addr in parsed_addresses):
        return "Link-local endpoints are blocked."
    if any(addr.is_multicast or addr.is_unspecified or addr.is_reserved for addr in parsed_addresses):
        return "Reserved, multicast, or unspecified DNS addresses are blocked."
    # Local intranet targets are permitted for desktop integration. Reject
    # special/reserved ranges, multicast and non-routable addresses that are
    # neither private/loopback nor global, and reject mixed trust zones.
    local = {addr for addr in parsed_addresses if addr.is_private or addr.is_loopback}
    global_ = {addr for addr in parsed_addresses if addr.is_global}
    unknown = parsed_addresses - local - global_
    if unknown:
        return "Reserved, multicast, or non-routable DNS addresses are blocked."
    if local and global_:
        return "Mixed public/private DNS results are blocked for safety."
    if global_ and scheme.lower() not in {"https", "wss"}:
        return "Public endpoints must use HTTPS/WSS. Local/private HTTP endpoints are allowed."
    return None


def _resolved_addresses(url: str) -> set[str]:
    """Resolve a probe host to canonical IP strings for DNS rebinding checks."""
    import ipaddress
    parsed = urlparse(url)
    host = parsed.hostname or ""
    port = parsed.port or (443 if parsed.scheme.lower() in {"https", "wss"} else 80)
    infos = socket.getaddrinfo(host, port, type=socket.SOCK_STREAM)
    return {str(ipaddress.ip_address(info[4][0])) for info in infos}


def extract_urls(message: str) -> list[str]:
    found = re.findall(r"(?i)\b(?:https?|wss?)://[^\s<>\"']+", message)
    cleaned: list[str] = []
    for url in found:
        url = url.rstrip(".,);]}")
        if url and url not in cleaned:
            cleaned.append(url)
    return cleaned


async def probe_endpoint(url: str, method: str = "GET", headers: dict[str, str] | None = None, payload: dict[str, Any] | None = None) -> dict[str, Any]:
    """Probe HTTP endpoints safely; WebSocket probes only test the handshake."""
    problem = _validate_probe_url(url)
    if problem:
        return {"url": safe_url_for_display(url), "verified": False, "status_code": None, "reason": problem}
    parsed = urlparse(url)
    try:
        first_addresses = _resolved_addresses(url)
        first_policy_error = _address_policy_error(parsed.scheme, first_addresses)
        if first_policy_error:
            return {"url": safe_url_for_display(url), "verified": False, "status_code": None, "reason": first_policy_error}
        # Re-resolve and re-apply policy to narrow DNS-rebinding windows. Probes
        # bypass environment proxies; a changed address set fails closed.
        second_addresses = _resolved_addresses(url)
        second_policy_error = _address_policy_error(parsed.scheme, second_addresses)
        if second_policy_error:
            return {"url": safe_url_for_display(url), "verified": False, "status_code": None, "reason": second_policy_error}
        if first_addresses != second_addresses:
            return {"url": safe_url_for_display(url), "verified": False, "status_code": None, "reason": "Hostname resolved to different addresses between validation and probe; request blocked."}
    except Exception as exc:
        return {"url": safe_url_for_display(url), "verified": False, "status_code": None, "reason": f"Host resolution could not be revalidated: {type(exc).__name__}."}
    if parsed.scheme in {"ws", "wss"}:
        try:
            import websockets
            try:
                connector = websockets.connect(url, open_timeout=4, close_timeout=1, additional_headers=headers or {})
            except TypeError:
                connector = websockets.connect(url, open_timeout=4, close_timeout=1, extra_headers=headers or {})
            async with connector as ws:
                try:
                    await ws.send("ping")
                except Exception:
                    pass
            return {"url": safe_url_for_display(url), "verified": True, "status_code": None, "reason": "WebSocket handshake succeeded."}
        except Exception as exc:
            return {"url": safe_url_for_display(url), "verified": False, "status_code": None, "reason": f"WebSocket connection failed: {type(exc).__name__}. Check host, port, and path."}
    method = method.upper()
    if method not in {"GET", "HEAD", "OPTIONS"}:
        return {"url": safe_url_for_display(url), "verified": False, "status_code": None, "reason": "Endpoint probes are read-only (GET, HEAD, OPTIONS). Verify state-changing routes through OpenAPI instead."}
    try:
        async with httpx.AsyncClient(timeout=httpx.Timeout(5, connect=3), follow_redirects=False, trust_env=False) as client:
            response = await client.request(method, url, headers=headers or {}, json=payload if method == "POST" else None)
        code = response.status_code
        if code in {401, 403}:
            reason = f"Authentication failed (HTTP {code}). Check the configured header name/value."
            verified = False
        elif code == 404:
            reason = "Endpoint not found (HTTP 404). Verify the URL path."
            verified = False
        elif code >= 500:
            reason = f"Server error (HTTP {code})."
            verified = False
        elif code in {301, 302, 303, 307, 308}:
            reason = f"Redirect returned (HTTP {code}); redirect target was not followed."
            verified = False
        elif code in {405, 422}:
            reason = f"Server is reachable (HTTP {code}), but this probe method/payload is not accepted; authentication may not have been verified. Use a documented read-only verification endpoint, or explicitly test a sandbox endpoint with a harmless payload."
            verified = False
        elif 200 <= code < 300:
            reason = f"Endpoint reachable; HTTP {code}."
            verified = True
        else:
            reason = f"Endpoint responded with HTTP {code}; not considered verified."
            verified = False
        return {"url": safe_url_for_display(url), "verified": verified, "status_code": code, "reason": reason}
    except Exception as exc:
        return {"url": safe_url_for_display(url), "verified": False, "status_code": None, "reason": f"Connection failed: {type(exc).__name__}. Check the local service and port."}


def _strip_code_fence(content: str, language: str = "xml") -> str:
    text = content.strip()
    text = re.sub(rf"^```(?:{language})?\s*", "", text, flags=re.I)
    text = re.sub(r"\s*```$", "", text)
    return text.strip()


async def _openai_json(system: str, user: str, model: str | None = None) -> dict[str, Any]:
    api_key = env("OPENAI_API_KEY")
    if not api_key:
        raise RuntimeError("OPENAI_API_KEY is missing. Add it to processos_studio/.env and restart ProcessOS.")
    from openai import AsyncOpenAI
    client = AsyncOpenAI(api_key=api_key)
    try:
        response = await client.chat.completions.create(
            model=model or DEFAULT_MODEL,
            messages=[{"role": "system", "content": system}, {"role": "user", "content": user}],
            response_format={"type": "json_object"},
            temperature=0.1,
        )
        content = response.choices[0].message.content or "{}"
        try:
            return json.loads(content)
        except json.JSONDecodeError as exc:
            raise RuntimeError(f"Model response was not valid JSON: {exc}") from exc
    finally:
        await client.close()


def _dialogue_blueprint(spec: dict[str, Any]) -> dict[str, Any]:
    """Expose only useful discovery facts, not implementation defaults, to the model."""
    hidden = {
        "rainbow_stack_dir", "integration_contract", "camunda_base_url", "camunda_auth_mode",
        "integration_header_name", "action_header_name", "process_id", "refund_threshold",
    }
    result: dict[str, Any] = {}
    for key, value in spec.items():
        if key in hidden or value in (None, "", [], {}):
            continue
        result[key] = value
    return result


async def conversational_reply(message: str, spec: dict[str, Any], probe_result: dict[str, Any] | None = None, history: list[dict[str, str]] | None = None) -> dict[str, Any]:
    """Ask the model for dialogue and a tightly allowlisted blueprint patch.

    The caller must redact secrets before passing `message`; credential values are
    intentionally excluded from `spec`, `probe_result`, and history.
    """
    safe_message = redact_secrets(message)
    sys_prompt = """You are the conversational workflow-discovery agent for Shubham Singh ProcessOS. You are not attached to any assumed company, product, codebase, or API. Never assume that the target is Rainbow Corp or name any specific system unless the user mentions it. Do not ask for a project folder path as an opening question. Start by understanding the process in plain language: what triggers it, what outcome the user wants, its steps and decisions, and what exceptions need handling. Ask ONE concise, natural follow-up question at a time. If the user says they want to automate a chatbot, first ask how the intended workflow should behave; do not jump directly to folder paths, endpoint inventory, tokens, or implementation details. Gather technical connection details after the business flow is understood, or immediately probe any URL the user volunteers. Ask for a local project path only if the user says the target is an existing local project or the selected deployment path actually requires its source folder; describe it generically unless the user named the project. Do not treat built-in fallback values in the blueprint as user-confirmed rules or decisions; confirm important thresholds and routing policies with the user instead of silently assuming them. The only startup secret is OPENAI_API_KEY. Do not ask the user to put target endpoints or target credentials in environment variables. The backend extracts and probes URLs locally; token values are held only in local process memory and are never provided to you. Never invent a verified probe result or claim an endpoint is verified unless the supplied probe result says verified=true. Never tell the user to modify or overwrite an existing app, bridge, database, BPMN, or .env file. The current deployment adapter supports a specific local refund-flow contract; discuss compatibility only when deployment target details become relevant, and do not present that adapter as the user's assumed target. Return JSON only: {"reply": string, "spec_patch": object}. Allowed patch keys: process_id, refund_threshold, business_rules, app_base_url, integration_poll_endpoint, integration_status_endpoint, integration_health_endpoint, integration_header_name, action_api_url, action_health_url, action_verify_url, action_header_name, websocket_url. Do not include, infer, or repeat credentials."""
    context = {"discovery_facts": _dialogue_blueprint(spec), "latest_probe_result": probe_result, "recent_conversation": (history or [])[-8:]}
    result = await _openai_json(sys_prompt, f"Current context (credentials excluded):\n{json.dumps(context, ensure_ascii=False)}\n\nLatest user message (credentials redacted):\n{safe_message}")
    reply = str(result.get("reply", "I understood. Please provide the next business requirement."))
    patch = result.get("spec_patch", {})
    if not isinstance(patch, dict):
        patch = {}
    allowed = {
        "process_id", "refund_threshold", "business_rules", "app_base_url",
        "integration_poll_endpoint", "integration_status_endpoint", "integration_health_endpoint",
        "integration_header_name", "action_api_url", "action_health_url", "action_verify_url",
        "action_header_name", "websocket_url", 
    }
    return {"reply": reply, "spec_patch": {k: v for k, v in patch.items() if k in allowed}}


def threshold_text(value: Any) -> str:
    """Format decimal thresholds without rounding or scientific notation."""
    from decimal import Decimal, InvalidOperation
    try:
        number = Decimal(str(value))
    except (InvalidOperation, ValueError, TypeError) as exc:
        raise ValueError("refund_threshold must be a finite decimal number") from exc
    if not number.is_finite():
        raise ValueError("refund_threshold must be a finite decimal number")
    text = format(number, "f")
    if "." in text:
        text = text.rstrip("0").rstrip(".")
    return text or "0"


def _build_contract_bpmn(spec: dict[str, Any]) -> str:
    """Build the known Rainbow refund BPMN contract deterministically.

    The model may propose a draft, but the exact executable contract is safer to
    repair from this template than to repeatedly trust malformed generated XML.
    """
    from xml.sax.saxutils import quoteattr

    process_id = str(spec.get("process_id", ""))
    if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_.-]*", process_id):
        raise ValueError("process_id must start with a letter/underscore and contain only letters, digits, '.', '_' or '-'.")
    from decimal import Decimal, InvalidOperation
    try:
        threshold = Decimal(str(spec["refund_threshold"]))
    except (InvalidOperation, ValueError, TypeError) as exc:
        raise ValueError("refund_threshold must be a finite decimal number") from exc
    if not threshold.is_finite():
        raise ValueError("refund_threshold must be a finite decimal number")
    if threshold < 0:
        raise ValueError("refund_threshold must be zero or greater.")
    threshold_text_value = threshold_text(threshold)
    pid = quoteattr(process_id)
    return f"""<?xml version="1.0" encoding="UTF-8"?>
<bpmn:definitions xmlns:bpmn="http://www.omg.org/spec/BPMN/20100524/MODEL"
                  xmlns:zeebe="http://camunda.org/schema/zeebe/1.0"
                  xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
                  id="Definitions_ProcessOS" targetNamespace="https://processos.local/bpmn">
  <bpmn:process id={pid} isExecutable="true">
    <bpmn:startEvent id="StartEvent_Refund" />
    <bpmn:sequenceFlow id="Flow_Start_Route" sourceRef="StartEvent_Refund" targetRef="Gateway_Amount" />
    <bpmn:exclusiveGateway id="Gateway_Amount" default="Flow_Auto" />
    <bpmn:sequenceFlow id="Flow_Human" sourceRef="Gateway_Amount" targetRef="Task_RegisterReview">
      <bpmn:conditionExpression xsi:type="bpmn:tFormalExpression">= refundAmount &gt; {threshold_text_value}</bpmn:conditionExpression>
    </bpmn:sequenceFlow>
    <bpmn:sequenceFlow id="Flow_Auto" sourceRef="Gateway_Amount" targetRef="Task_ExecuteRefund" />
    <bpmn:serviceTask id="Task_RegisterReview">
      <bpmn:extensionElements><zeebe:taskDefinition type="register-human-review" /></bpmn:extensionElements>
    </bpmn:serviceTask>
    <bpmn:sequenceFlow id="Flow_Register_To_UserTask" sourceRef="Task_RegisterReview" targetRef="Task_HumanReview" />
    <bpmn:userTask id="Task_HumanReview">
      <bpmn:extensionElements><zeebe:userTask /></bpmn:extensionElements>
    </bpmn:userTask>
    <bpmn:sequenceFlow id="Flow_UserTask_To_Decision" sourceRef="Task_HumanReview" targetRef="Gateway_Approved" />
    <bpmn:exclusiveGateway id="Gateway_Approved" default="Flow_Rejected" />
    <bpmn:sequenceFlow id="Flow_Approved" sourceRef="Gateway_Approved" targetRef="Task_ExecuteRefund">
      <bpmn:conditionExpression xsi:type="bpmn:tFormalExpression">= humanApproved = true</bpmn:conditionExpression>
    </bpmn:sequenceFlow>
    <bpmn:sequenceFlow id="Flow_Rejected" sourceRef="Gateway_Approved" targetRef="Task_RecordRejection" />
    <bpmn:serviceTask id="Task_ExecuteRefund">
      <bpmn:extensionElements><zeebe:taskDefinition type="execute-demo-refund" /></bpmn:extensionElements>
    </bpmn:serviceTask>
    <bpmn:sequenceFlow id="Flow_Execute_To_Sync" sourceRef="Task_ExecuteRefund" targetRef="Task_SyncResult" />
    <bpmn:serviceTask id="Task_SyncResult">
      <bpmn:extensionElements><zeebe:taskDefinition type="sync-refund-result" /></bpmn:extensionElements>
    </bpmn:serviceTask>
    <bpmn:sequenceFlow id="Flow_Sync_To_Result" sourceRef="Task_SyncResult" targetRef="Gateway_RefundResult" />
    <bpmn:exclusiveGateway id="Gateway_RefundResult" default="Flow_RefundFailed" />
    <bpmn:sequenceFlow id="Flow_RefundSuccess" sourceRef="Gateway_RefundResult" targetRef="EndEvent_Completed">
      <bpmn:conditionExpression xsi:type="bpmn:tFormalExpression">= refundApiStatus = &quot;SUCCESS&quot;</bpmn:conditionExpression>
    </bpmn:sequenceFlow>
    <bpmn:sequenceFlow id="Flow_RefundFailed" sourceRef="Gateway_RefundResult" targetRef="EndEvent_Failed" />
    <bpmn:serviceTask id="Task_RecordRejection">
      <bpmn:extensionElements><zeebe:taskDefinition type="record-refund-rejection" /></bpmn:extensionElements>
    </bpmn:serviceTask>
    <bpmn:sequenceFlow id="Flow_Rejection_To_End" sourceRef="Task_RecordRejection" targetRef="EndEvent_Rejected" />
    <bpmn:endEvent id="EndEvent_Completed" />
    <bpmn:endEvent id="EndEvent_Failed" />
    <bpmn:endEvent id="EndEvent_Rejected" />
  </bpmn:process>
</bpmn:definitions>
"""


def bpmn_prompt(spec: dict[str, Any], feedback: str) -> str:
    template = _build_contract_bpmn(spec)
    return f"""Generate complete well-formed executable Camunda 8 BPMN 2.0 XML only, as JSON key `bpmn_xml`. Do not generate code. Reuse the exact node IDs and flow IDs from this compatible contract: StartEvent_Refund, Gateway_Amount, Task_RegisterReview, Task_HumanReview, Gateway_Approved, Task_ExecuteRefund, Task_SyncResult, Gateway_RefundResult, Task_RecordRejection, EndEvent_Completed, EndEvent_Failed, EndEvent_Rejected; sequence flows Flow_Start_Route, Flow_Human, Flow_Auto, Flow_Register_To_UserTask, Flow_UserTask_To_Decision, Flow_Approved, Flow_Rejected, Flow_Execute_To_Sync, Flow_Sync_To_Result, Flow_RefundSuccess, Flow_RefundFailed, Flow_Rejection_To_End. The amount gateway default must be Flow_Auto, approval gateway default must be Flow_Rejected, and result gateway default must be Flow_RefundFailed. Do not add script tasks, call activities, extra service tasks, extra sequence flows, external task types, or hidden side effects. The process id MUST be {spec['process_id']!r}. Refund threshold MUST be {threshold_text(spec['refund_threshold'])} INR. Must include expression `= refundAmount > {threshold_text(spec['refund_threshold'])}` on the human review path and a default automatic path for amounts at or below threshold. Human path must include user task and an approval gateway with `= humanApproved = true`; rejected path must use `record-refund-rejection` and must not reach execute-demo-refund. Required Zeebe job types exactly: register-human-review, execute-demo-refund, sync-refund-result, record-refund-rejection. Preserve variables requestId, orderId, customerEmail, productId, productName, refundAmount, reason, humanApproved, reviewerId, reviewerComments, refundApiStatus, refundTransactionId, refundApiMessage. The four task worker types must align with the already-installed Rainbow Corp bridge. The human review task must contain a zeebe:userTask extension. Use xsi:type="bpmn:tFormalExpression" for each conditionExpression. Add Camunda/Zeebe/xsi namespaces. Include a simple valid BPMN process with start/end events, sequence flows, gateways, service tasks and a user task. BPMN DI is optional.

Structural XML template to follow:
{template}

User requirements: {json.dumps(spec.get('business_rules', []), ensure_ascii=False)}. Prior validation feedback: {feedback or 'None.'}. Return JSON only: {{\"bpmn_xml\": \"...\"}}."""


def _generate_cli_shim(out_dir: Path) -> str:
    # The generated CLI is a reviewed control surface, not arbitrary model code.
    # Secret-bearing execution is brokered by the active local ProcessOS session.
    return '''"""Generated ProcessOS CLI entrypoint; local execution is brokered by ProcessOS."""
from __future__ import annotations
import argparse
import json
import sys
from pathlib import Path
import urllib.error
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_SESSION = "processos-local-session"

def main() -> int:
    parser = argparse.ArgumentParser(description="Shubham Singh ProcessOS workflow CLI")
    parser.add_argument("--self-test", action="store_true", help="Offline BPMN and CLI validation only")
    parser.add_argument("--run", action="store_true", help="Request the active local ProcessOS session to deploy and start the workflow")
    parser.add_argument("--confirm", action="store_true", help="Explicitly authorize deployment and bridge startup")
    parser.add_argument("--session-id", default=DEFAULT_SESSION)
    args = parser.parse_args()
    if args.self_test:
        import subprocess
        return subprocess.call([sys.executable, str(ROOT / "processos_runtime.py"), "--self-test", "--workflow-dir", str(Path(__file__).resolve().parent)])
    if not args.run:
        parser.print_help()
        return 2
    if not args.confirm:
        print("Blocked: pass --confirm to authorize deployment and bridge startup.", file=sys.stderr)
        return 2
    payload = json.dumps({"session_id": args.session_id, "confirmed": True}).encode("utf-8")
    request = urllib.request.Request("http://127.0.0.1:8090/api/cli/run", data=payload, headers={"Content-Type": "application/json"}, method="POST")
    try:
        with urllib.request.urlopen(request, timeout=1200) as response:
            result = json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")
        print(f"ProcessOS rejected CLI run (HTTP {exc.code}): {detail}", file=sys.stderr)
        return 2
    except Exception as exc:
        print(f"Could not reach ProcessOS at 127.0.0.1:8090: {type(exc).__name__}. Start ProcessOS and keep the discovery session active.", file=sys.stderr)
        return 2
    print(result.get("stdout", ""), end="")
    if result.get("stderr"):
        print(result["stderr"], file=sys.stderr, end="")
    return int(result.get("exit_code", 1))

if __name__ == "__main__":
    raise SystemExit(main())
'''


def deterministic_checks(bpmn_xml: str, python_code: str, spec: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    try:
        ast.parse(python_code)
    except SyntaxError as exc:
        errors.append(f"Python AST parse failed at line {exc.lineno}: {exc.msg}")
    try:
        root = ET.fromstring(bpmn_xml)
        if not root.tag.endswith("definitions"):
            errors.append("XML root element must be BPMN definitions.")
        processes = root.findall("bpmn:process", BPMN_NS)
        if len(processes) != 1:
            errors.append("Definitions must contain exactly one BPMN process.")
        proc = next((p for p in processes if p.get("id") == spec["process_id"]), None)
        if proc is None:
            errors.append(f"Required process id {spec['process_id']!r} was not found.")
        if not root.tag.startswith("{" + BPMN_NS["bpmn"] + "}"):
            errors.append("BPMN 2.0 model namespace is missing.")
        xml_flat = " ".join(root.itertext())
        required_expr = f"= refundAmount > {threshold_text(spec['refund_threshold'])}"
        # Compare textContent; XML entities are decoded by ElementTree.
        if required_expr not in xml_flat:
            errors.append(f"Missing exact threshold expression: {required_expr}")
        if "= humanApproved = true" not in xml_flat:
            errors.append("Missing human approval FEEL expression `= humanApproved = true`.")
        task_types = {node.get("type") for node in root.findall(".//zeebe:taskDefinition", BPMN_NS)}
        missing = REQUIRED_JOB_TYPES - task_types
        extra = task_types - REQUIRED_JOB_TYPES
        if missing:
            errors.append("Missing required Zeebe worker type(s): " + ", ".join(sorted(missing)))
        if extra:
            errors.append("Unapproved Zeebe worker type(s): " + ", ".join(sorted(str(x) for x in extra)))
        if task_types != REQUIRED_JOB_TYPES:
            errors.append("The process must use exactly the four supported worker types and no others.")
        task_tags = {node.tag.split("}")[-1] for node in root.iter()}
        if "userTask" not in task_tags:
            errors.append("BPMN must include a user task for human review.")
        if "exclusiveGateway" not in task_tags:
            errors.append("BPMN must include an exclusive gateway for routing/approval.")
        if proc is None or proc.get("isExecutable", "").lower() != "true":
            errors.append("Target BPMN process must have isExecutable=true.")
        if "<!DOCTYPE" in bpmn_xml.upper() or "<!ENTITY" in bpmn_xml.upper():
            errors.append("DOCTYPE/ENTITY declarations are not allowed in generated BPMN.")
        if proc is not None:
            identified_nodes = [node for node in proc.iter() if node.get("id")]
            id_values = [node.get("id") for node in identified_nodes]
            duplicate_ids = sorted({value for value in id_values if id_values.count(value) > 1})
            if duplicate_ids:
                errors.append("Duplicate BPMN IDs detected: " + ", ".join(str(value) for value in duplicate_ids))
            by_id = {node.get("id"): node for node in identified_nodes}
            expected_flows = {
                "Flow_Start_Route": ("StartEvent_Refund", "Gateway_Amount"),
                "Flow_Human": ("Gateway_Amount", "Task_RegisterReview"),
                "Flow_Auto": ("Gateway_Amount", "Task_ExecuteRefund"),
                "Flow_Register_To_UserTask": ("Task_RegisterReview", "Task_HumanReview"),
                "Flow_UserTask_To_Decision": ("Task_HumanReview", "Gateway_Approved"),
                "Flow_Approved": ("Gateway_Approved", "Task_ExecuteRefund"),
                "Flow_Rejected": ("Gateway_Approved", "Task_RecordRejection"),
                "Flow_Execute_To_Sync": ("Task_ExecuteRefund", "Task_SyncResult"),
                "Flow_Sync_To_Result": ("Task_SyncResult", "Gateway_RefundResult"),
                "Flow_RefundSuccess": ("Gateway_RefundResult", "EndEvent_Completed"),
                "Flow_RefundFailed": ("Gateway_RefundResult", "EndEvent_Failed"),
                "Flow_Rejection_To_End": ("Task_RecordRejection", "EndEvent_Rejected"),
            }
            actual_flows = {f.get("id") for f in proc.findall("bpmn:sequenceFlow", BPMN_NS)}
            if actual_flows != set(expected_flows):
                errors.append("Sequence-flow set must exactly match the approved Rainbow refund route; extra/missing flow IDs detected.")
            for flow_id, (source, target) in expected_flows.items():
                flow = by_id.get(flow_id)
                if flow is None or flow.get("sourceRef") != source or flow.get("targetRef") != target:
                    errors.append(f"Routing defect in {flow_id}: expected {source} -> {target}.")
            expected_defaults = {"Gateway_Amount": "Flow_Auto", "Gateway_Approved": "Flow_Rejected", "Gateway_RefundResult": "Flow_RefundFailed"}
            for gateway_id, default_flow in expected_defaults.items():
                gateway = by_id.get(gateway_id)
                if gateway is None or gateway.get("default") != default_flow:
                    errors.append(f"Gateway {gateway_id} must default to {default_flow}.")
            expected_conditions = {
                "Flow_Human": f"= refundAmount > {threshold_text(spec['refund_threshold'])}",
                "Flow_Approved": "= humanApproved = true",
                "Flow_RefundSuccess": '= refundApiStatus = "SUCCESS"',
            }
            for flow_id, expression in expected_conditions.items():
                flow = by_id.get(flow_id)
                conds = flow.findall("bpmn:conditionExpression", BPMN_NS) if flow is not None else []
                xsi_type = "{" + "http://www.w3.org/2001/XMLSchema-instance" + "}type"
                if len(conds) != 1 or (conds[0].text or "").strip() != expression or conds[0].get(xsi_type) != "bpmn:tFormalExpression":
                    errors.append(f"{flow_id} must contain the formal expression {expression!r} with xsi:type=bpmn:tFormalExpression.")
            for flow in proc.findall("bpmn:sequenceFlow", BPMN_NS):
                flow_id = flow.get("id", "<unknown>")
                if flow_id not in expected_conditions and flow.findall("bpmn:conditionExpression", BPMN_NS):
                    errors.append(f"{flow_id} must not have a condition expression; that route is defined by the approved default flow.")
            expected_exec_ids = set(expected_flows) | {
                "StartEvent_Refund", "Gateway_Amount", "Task_RegisterReview", "Task_HumanReview",
                "Gateway_Approved", "Task_ExecuteRefund", "Task_SyncResult", "Gateway_RefundResult",
                "Task_RecordRejection", "EndEvent_Completed", "EndEvent_Failed", "EndEvent_Rejected",
            }
            executable_names = {"startEvent", "endEvent", "exclusiveGateway", "serviceTask", "userTask", "sequenceFlow", "scriptTask", "callActivity", "sendTask", "receiveTask", "businessRuleTask", "manualTask", "subProcess", "transaction", "adHocSubProcess", "parallelGateway", "inclusiveGateway", "eventBasedGateway", "intermediateCatchEvent", "intermediateThrowEvent", "boundaryEvent"}
            actual_exec_ids = {node.get("id") for node in proc.iter() if node.tag.startswith("{" + BPMN_NS["bpmn"] + "}") and node.tag.split("}")[-1] in executable_names}
            if actual_exec_ids != expected_exec_ids:
                errors.append("Executable BPMN node IDs must exactly match the approved refund process; extra/missing executable elements detected.")
            allowed_bpmn_tags = {"process", "documentation", "startEvent", "endEvent", "exclusiveGateway", "sequenceFlow", "conditionExpression", "serviceTask", "userTask", "incoming", "outgoing", "extensionElements"}
            unexpected_tags = sorted({node.tag.split("}")[-1] for node in proc.iter() if node.tag.startswith("{" + BPMN_NS["bpmn"] + "}") and node.tag.split("}")[-1] not in allowed_bpmn_tags})
            if unexpected_tags:
                errors.append("Unapproved BPMN elements detected: " + ", ".join(unexpected_tags))
            expected_types = {
                "Task_RegisterReview": "register-human-review",
                "Task_ExecuteRefund": "execute-demo-refund",
                "Task_SyncResult": "sync-refund-result",
                "Task_RecordRejection": "record-refund-rejection",
            }
            for task_id, job_type in expected_types.items():
                task = by_id.get(task_id)
                if task is None or task.tag != "{" + BPMN_NS["bpmn"] + "}serviceTask":
                    errors.append(f"{task_id} must be a BPMN serviceTask.")
                defs = task.findall(".//zeebe:taskDefinition", BPMN_NS) if task is not None else []
                if len(defs) != 1 or defs[0].get("type") != job_type:
                    errors.append(f"{task_id} must have exactly one Zeebe job type {job_type!r}.")
            expected_node_tags = {
                "StartEvent_Refund": "startEvent", "Gateway_Amount": "exclusiveGateway",
                "Task_RegisterReview": "serviceTask", "Task_HumanReview": "userTask",
                "Gateway_Approved": "exclusiveGateway", "Task_ExecuteRefund": "serviceTask",
                "Task_SyncResult": "serviceTask", "Gateway_RefundResult": "exclusiveGateway",
                "Task_RecordRejection": "serviceTask", "EndEvent_Completed": "endEvent",
                "EndEvent_Failed": "endEvent", "EndEvent_Rejected": "endEvent",
            }
            for node_id, local_tag in expected_node_tags.items():
                node = by_id.get(node_id)
                if node is None or node.tag != "{" + BPMN_NS["bpmn"] + "}" + local_tag:
                    errors.append(f"{node_id} must be a BPMN {local_tag}.")
            user_task = by_id.get("Task_HumanReview")
            zeebe_user_tasks = user_task.findall(".//zeebe:userTask", BPMN_NS) if user_task is not None else []
            if len(zeebe_user_tasks) != 1:
                errors.append("Task_HumanReview must include exactly one zeebe:userTask extension.")
            executable_types = {"startEvent", "endEvent", "exclusiveGateway", "serviceTask", "userTask", "sequenceFlow"}
            actual_executable = {node.tag.split("}")[-1] for node in proc.iter() if node.tag.startswith("{" + BPMN_NS["bpmn"] + "}") and node.tag.split("}")[-1] in executable_types}
            if not {"startEvent", "endEvent", "exclusiveGateway", "serviceTask", "userTask", "sequenceFlow"}.issubset(actual_executable):
                errors.append("Required BPMN task/event/gateway elements are incomplete.")
            executable_nodes = [node for node in proc.iter() if node.tag.startswith("{" + BPMN_NS["bpmn"] + "}") and node.tag.split("}")[-1] in {"scriptTask", "callActivity", "sendTask", "receiveTask", "businessRuleTask", "manualTask", "subProcess", "transaction", "adHocSubProcess"}]
            if executable_nodes:
                errors.append("Unsafe/unapproved BPMN executable element(s) detected: " + ", ".join(sorted({node.tag.split("}")[-1] for node in executable_nodes})))
    except ET.ParseError as exc:
        errors.append(f"BPMN XML parse failed: {exc}")
    # The CLI is generated from a fixed template, not LLM-produced source.
    required_cli_terms = ("--self-test", "--run", "--confirm", "processos_runtime.py", "--workflow-dir", "127.0.0.1:8090")
    for term in required_cli_terms:
        if term not in python_code:
            errors.append(f"CLI entrypoint is missing required integration term {term!r}.")
    return errors


async def coder_tester_loop(spec: dict[str, Any], out_dir: Path) -> dict[str, Any]:
    """Coder/Tester loop, capped at three model iterations; no model-generated Python is executed."""
    out_dir.mkdir(parents=True, exist_ok=True)
    feedback = ""
    history: list[dict[str, Any]] = []
    cli_code = _generate_cli_shim(out_dir)
    for attempt in range(1, MAX_REACT_ITERATIONS + 1):
        coder = await _openai_json(
            "You are the ProcessOS Coder Agent. Return JSON only. Generate BPMN XML only; never generate executable code. Make a complete attempt, following the user's verified workflow contract.",
            bpmn_prompt(spec, feedback),
        )
        bpmn_xml = _strip_code_fence(str(coder.get("bpmn_xml", "")), "xml")
        # Validate the model draft. If it violates the fixed existing-bridge contract,
        # repair the BPMN from a deterministic template instead of repeatedly trusting
        # malformed XML from unconstrained generations.
        draft_errors = deterministic_checks(bpmn_xml, cli_code, spec)
        repaired_from_template = False
        if draft_errors:
            bpmn_xml = _build_contract_bpmn(spec)
            repaired_from_template = True
        (out_dir / "workflow.bpmn").write_text(bpmn_xml, encoding="utf-8")
        (out_dir / "cli_orchestrator.py").write_text(cli_code, encoding="utf-8")
        technical_errors = deterministic_checks(bpmn_xml, cli_code, spec)

        # The CLI's --self-test is deterministic, offline, and uses fixed trusted runtime code.
        if not technical_errors:
            import subprocess, sys
            try:
                proc = subprocess.run([sys.executable, str(out_dir / "cli_orchestrator.py"), "--self-test"], cwd=BASE_DIR, capture_output=True, text=True, timeout=15)
                if proc.returncode != 0:
                    technical_errors.append(f"CLI --self-test failed (exit {proc.returncode}): {(proc.stderr or proc.stdout)[-1200:]}")
            except Exception as exc:
                technical_errors.append(f"Could not run CLI self-test: {type(exc).__name__}: {exc}")

        tester_payload = {
            "spec": spec,
            "coder_draft_rejected_errors": [] if repaired_from_template else draft_errors,
            "deterministic_template_repair_applied": repaired_from_template,
            "technical_errors": technical_errors,
            "bpmn_xml": bpmn_xml,
            "cli_entrypoint": cli_code,
        }
        tester = await _openai_json(
            "You are the ProcessOS Tester Agent. Audit the FINAL BPMN artifact (bpmn_xml) and CLI against all user demands. Treat non-empty technical_errors as an automatic fail. If technical_errors is empty, bpmn_xml satisfies the process_id, threshold expression, human review user task, approval gateway, and the four required Zeebe job types (register-human-review, execute-demo-refund, sync-refund-result, record-refund-rejection), and the CLI self-test passed, approve with passed=true. Return JSON only with keys passed (boolean), audit_summary (string), feedback_for_coder (string).",
            json.dumps(tester_payload, ensure_ascii=False),
        )
        semantic_pass = bool(tester.get("passed", False))
        passed = not technical_errors and semantic_pass
        audit = str(tester.get("audit_summary", "Tester did not provide an audit summary."))
        notes = technical_errors or ([] if semantic_pass else [str(tester.get("feedback_for_coder", "Tester rejected the artifacts."))])
        history.append({"iteration": attempt, "passed": passed, "coder_draft_rejected_errors": draft_errors, "deterministic_template_repair_applied": repaired_from_template, "technical_errors": technical_errors, "audit_summary": audit, "feedback": notes})
        if passed:
            # Write a compact gate report inside the new companion's output directory.
            (out_dir / "tester_report.json").write_text(json.dumps({"build_id": BUILD_ID, "passed": True, "iteration": attempt, "audit_summary": audit, "checks": history}, indent=2), encoding="utf-8")
            return {"build_id": BUILD_ID, "passed": True, "iteration": attempt, "audit_summary": audit, "history": history, "artifacts": ["workflow.bpmn", "cli_orchestrator.py", "tester_report.json"]}
        feedback = "\n".join(notes) + "\nTester audit: " + audit
    (out_dir / "tester_report.json").write_text(json.dumps({"build_id": BUILD_ID, "passed": False, "iteration": MAX_REACT_ITERATIONS, "checks": history}, indent=2), encoding="utf-8")
    return {"build_id": BUILD_ID, "passed": False, "iteration": MAX_REACT_ITERATIONS, "audit_summary": "ReAct gate failed; CLI deployment is blocked.", "history": history, "artifacts": ["workflow.bpmn", "cli_orchestrator.py", "tester_report.json"]}
