"""Local Camunda 8 lifecycle checks through the official c8ctl CLI.

This module never touches the separate Rainbow Corp project's source or .env files.
It only installs the CLI package (when explicitly ensured) and starts/stops the
local Camunda Run cluster using c8ctl.
"""
from __future__ import annotations

import os
import re
import shutil
import subprocess
import time
from typing import Any
from urllib.request import urlopen

MIN_NODE = (22, 18, 0)
CAMUNDA_LOCAL_URL = "http://127.0.0.1:8080/v2/topology"


def _find_java() -> str | None:
    found = shutil.which("java")
    if found:
        return found
    java_home = os.environ.get("JAVA_HOME")
    if java_home:
        candidate = os.path.join(java_home, "bin", "java.exe" if os.name == "nt" else "java")
        if os.path.isfile(candidate):
            os.environ["PATH"] = os.path.dirname(candidate) + os.pathsep + os.environ.get("PATH", "")
            return candidate
    cached = os.path.expanduser(r"~\AppData\Local\c8run\cache\jdk21\jdk-21.0.12.1+1\bin\java.exe")
    if os.path.isfile(cached):
        home_dir = os.path.dirname(os.path.dirname(cached))
        os.environ["JAVA_HOME"] = home_dir
        os.environ["PATH"] = os.path.dirname(cached) + os.pathsep + os.environ.get("PATH", "")
        return cached
    return None


def _run(args: list[str], timeout: int = 30) -> subprocess.CompletedProcess[str]:
    """Run known, fixed commands correctly on Windows (.cmd) and POSIX hosts."""
    _find_java()
    if os.name == "nt":
        command = subprocess.list2cmdline(args)
        return subprocess.run(command, shell=True, capture_output=True, text=True, timeout=timeout, env=os.environ)
    return subprocess.run(args, capture_output=True, text=True, timeout=timeout, env=os.environ)


def _which_cli() -> str | None:
    for candidate in ("c8ctl", "c8"):
        found = shutil.which(candidate)
        if found:
            return found
    return None


def _version_tuple(value: str) -> tuple[int, int, int] | None:
    match = re.search(r"v?(\d+)\.(\d+)\.(\d+)", value or "")
    if not match:
        return None
    return tuple(int(part) for part in match.groups())  # type: ignore[return-value]


def _version_command(command: str) -> str:
    try:
        proc = _run([command, "--version"], timeout=10)
        return ((proc.stdout or proc.stderr).strip().splitlines() or [""])[0]
    except Exception as exc:
        return f"unavailable ({type(exc).__name__})"


def _local_api_ready(timeout: float = 1.5) -> bool:
    try:
        with urlopen(CAMUNDA_LOCAL_URL, timeout=timeout) as response:
            return 200 <= int(response.status) < 300
    except Exception:
        return False


def status() -> dict[str, Any]:
    java_path = _find_java()
    node_path = shutil.which("node")
    npm_path = shutil.which("npm")
    node_version = _version_command(node_path) if node_path else "not installed"
    node_tuple = _version_tuple(node_version)
    node_ok = bool(node_tuple and node_tuple >= MIN_NODE)
    cli_path = _which_cli()
    cli_installed = bool(cli_path)
    cli_version = _version_command(cli_path) if cli_path else "not installed"
    api_ready = _local_api_ready()
    cluster_status: dict[str, Any] = {"available": False, "message": "CLI not installed"}
    if cli_installed and node_ok:
        try:
            proc = _run([cli_path, "cluster", "status"], timeout=20)
            output = ((proc.stdout or "") + "\n" + (proc.stderr or "")).strip()
            cluster_status = {
                "available": proc.returncode == 0,
                "exit_code": proc.returncode,
                "message": output[-1800:] or ("Cluster status command completed." if proc.returncode == 0 else "Cluster status command failed."),
            }
        except Exception as exc:
            cluster_status = {"available": False, "message": f"Status check failed: {type(exc).__name__}"}
    return {
        "cli_installed": cli_installed,
        "cli_path": cli_path or "",
        "cli_version": cli_version,
        "node_installed": bool(node_path),
        "node_version": node_version,
        "node_supported": node_ok,
        "node_required": ">= 22.18.0 (per current c8ctl documentation)",
        "npm_installed": bool(npm_path),
        "java_installed": bool(java_path),
        "java_note": "c8ctl-managed Camunda Run normally includes a bundled Java runtime; a system JDK may be used as a fallback.",
        "java_version": _version_command(java_path) if java_path else "not installed",
        "local_api_ready": api_ready,
        "local_rest_url": "http://127.0.0.1:8080/v2",
        "cluster_status": cluster_status,
        "ready": cli_installed and node_ok and api_ready,
    }


def ensure_camunda(start: bool = True) -> dict[str, Any]:
    """Install the official CLI if absent; start the local cluster when requested.

    Prerequisite runtimes (Node and Java) are not installed silently. If absent,
    return actionable guidance instead of changing machine-wide toolchains.
    """
    before = status()
    if before["local_api_ready"]:
        return {"ok": True, "already_running": True, "started": False, "status": before, "install_output": ""}
    if not before["node_installed"] or not before["node_supported"] or not before["npm_installed"]:
        raise RuntimeError(
            "Camunda CLI prerequisites are not ready. Install Node.js >= 22.18.0 and npm, "
            "reopen PowerShell, and retry. ProcessOS will install the Camunda CLI once prerequisites are present. "
            f"Detected Node: {before['node_version']}"
        )
    install_output = ""
    if not before["cli_installed"]:
        npm = shutil.which("npm")
        assert npm
        install = _run([npm, "install", "-g", "@camunda8/cli"], timeout=900)
        install_output = ((install.stdout or "") + "\n" + (install.stderr or "")).strip()[-4000:]
        if install.returncode != 0:
            raise RuntimeError("Could not install @camunda8/cli.\n" + install_output)
        after_install = status()
        if not after_install["cli_installed"]:
            raise RuntimeError("CLI installation command completed, but c8ctl/c8 was not found on PATH. Close and reopen PowerShell, then retry.\n" + install_output)

    current = status()
    if current["local_api_ready"] or not start:
        return {"ok": True, "already_running": bool(current["local_api_ready"]), "started": False, "status": current, "install_output": install_output}

    cli = current.get("cli_path") or _which_cli()
    if not cli:
        raise RuntimeError("Camunda CLI was not found after installation.")
    try:
        start_proc = _run([cli, "cluster", "start"], timeout=900)
    except subprocess.TimeoutExpired as exc:
        raise RuntimeError("c8ctl cluster start timed out. Check `c8ctl cluster status` and local runtime logs.") from exc
    start_output = ((start_proc.stdout or "") + "\n" + (start_proc.stderr or "")).strip()[-5000:]
    if start_proc.returncode != 0 and not _local_api_ready():
        raise RuntimeError("Camunda cluster start failed.\n" + start_output)

    deadline = time.time() + 150
    while time.time() < deadline:
        if _local_api_ready(timeout=2):
            final = status()
            return {"ok": True, "already_running": False, "started": True, "status": final, "install_output": install_output, "start_output": start_output}
        time.sleep(3)
    raise RuntimeError(
        "c8ctl returned but the Camunda REST API at http://127.0.0.1:8080/v2/topology did not become healthy within 150 seconds.\n"
        + start_output
        + "\nCheck `c8ctl cluster status` and your Java runtime."
    )
