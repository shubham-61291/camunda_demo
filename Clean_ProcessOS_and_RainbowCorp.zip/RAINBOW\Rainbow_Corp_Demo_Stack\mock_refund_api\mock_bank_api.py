"""Local-only mock refund API for the Rainbow Corp portfolio demo.

This service records fake refund transactions and never interacts with a real bank or payment rail.
"""
from __future__ import annotations

import os
import hmac
import sqlite3
import uuid
from contextlib import contextmanager, asynccontextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel, Field

BASE_DIR = Path(__file__).resolve().parent
try:
    from dotenv import load_dotenv
    load_dotenv(BASE_DIR / ".env")
except ImportError:
    pass
DB_PATH = Path(os.getenv("MOCK_BANK_DB_PATH", str(BASE_DIR / "mock_refund_api.sqlite3"))).expanduser()
DEMO_API_KEY = os.getenv("DEMO_REFUND_API_KEY", "").strip()
FORCED_REFUND_STATUS = os.getenv("MOCK_REFUND_FORCE_STATUS", "SUCCESS").strip().upper()
if FORCED_REFUND_STATUS not in {"SUCCESS", "FAILED"}:
    FORCED_REFUND_STATUS = "SUCCESS"


@asynccontextmanager
async def app_lifespan(_app: FastAPI):
    init_db()
    yield


app = FastAPI(title="Rainbow Corp Mock Refund API", version="1.1.0-demo", lifespan=app_lifespan)


def require_demo_api_key(candidate: str) -> None:
    if not DEMO_API_KEY:
        raise HTTPException(status_code=503, detail="Mock refund API authentication is not configured. Set DEMO_REFUND_API_KEY in mock_refund_api/.env and local_bridge/.env.")
    if not hmac.compare_digest(str(candidate or ""), DEMO_API_KEY):
        raise HTTPException(status_code=401, detail="Invalid demo API key.")


def now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


@contextmanager
def db_connection():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH, timeout=15)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_db() -> None:
    with db_connection() as conn:
        conn.execute("""CREATE TABLE IF NOT EXISTS demo_refund_transactions (
            transaction_id TEXT PRIMARY KEY,
            request_id TEXT NOT NULL UNIQUE,
            order_id TEXT NOT NULL,
            product_id TEXT NOT NULL DEFAULT '',
            product_name TEXT NOT NULL,
            amount_inr REAL NOT NULL,
            customer_email TEXT NOT NULL,
            reason TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'SUCCESS',
            created_at TEXT NOT NULL,
            idempotency_key TEXT NOT NULL UNIQUE
        )""")


class RefundPayload(BaseModel):
    request_id: str = Field(min_length=1, max_length=100)
    order_id: str = Field(min_length=1, max_length=100)
    product_id: str = Field(default="", max_length=50)
    product_name: str = Field(min_length=1, max_length=150)
    amount_inr: float = Field(gt=0, le=10_000_000)
    customer_email: str = Field(min_length=3, max_length=254)
    reason: str = Field(min_length=3, max_length=2000)


@app.get("/health")
def health() -> dict[str, Any]:
    return {"service": "Rainbow Corp Mock Refund API", "status": "ok", "mode": "demo_only", "real_money_moved": False}


@app.post("/api/v1/refunds")
def initiate_refund(
    payload: RefundPayload,
    x_demo_api_key: str = Header(default="", alias="X-Demo-API-Key"),
    idempotency_key: str = Header(default="", alias="Idempotency-Key"),
) -> dict[str, Any]:
    require_demo_api_key(x_demo_api_key)
    key = idempotency_key.strip() or payload.request_id
    timestamp = now_iso()
    with db_connection() as conn:
        existing = conn.execute(
            "SELECT * FROM demo_refund_transactions WHERE request_id = ? OR idempotency_key = ?",
            (payload.request_id, key),
        ).fetchone()
        if existing:
            return {
                "status": existing["status"],
                "transaction_id": existing["transaction_id"],
                "request_id": existing["request_id"],
                "amount_inr": float(existing["amount_inr"]),
                "message": f"Mock refund API returned {existing['status']} (idempotent replay). Demo only; no real money moved.",
                "idempotent_replay": True,
                "real_money_moved": False,
            }
        transaction_id = "DEMO-TXN-" + uuid.uuid4().hex[:12].upper()
        conn.execute(
            """INSERT INTO demo_refund_transactions
               (transaction_id, request_id, order_id, product_id, product_name, amount_inr,
                customer_email, reason, status, created_at, idempotency_key)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (transaction_id, payload.request_id, payload.order_id, payload.product_id,
             payload.product_name, round(payload.amount_inr, 2), payload.customer_email.lower(),
             payload.reason, FORCED_REFUND_STATUS, timestamp, key),
        )
    return {
        "status": FORCED_REFUND_STATUS,
        "transaction_id": transaction_id,
        "request_id": payload.request_id,
        "amount_inr": round(payload.amount_inr, 2),
        "message": f"Mock refund API returned {FORCED_REFUND_STATUS}. Demo only; no real money moved.",
        "idempotent_replay": False,
        "real_money_moved": False,
    }


@app.get("/api/v1/transactions")
def list_demo_transactions(x_demo_api_key: str = Header(default="", alias="X-Demo-API-Key")) -> dict[str, Any]:
    require_demo_api_key(x_demo_api_key)
    with db_connection() as conn:
        rows = conn.execute("SELECT * FROM demo_refund_transactions ORDER BY created_at DESC LIMIT 500").fetchall()
    return {"records": [dict(row) for row in rows], "count": len(rows), "real_money_moved": False}
