from __future__ import annotations

import sys
from pathlib import Path

from fastapi.testclient import TestClient
import pytest

MOCK_DIR = Path(__file__).resolve().parents[1] / "mock_refund_api"
sys.path.insert(0, str(MOCK_DIR))
import mock_bank_api as mock_module  # noqa: E402


@pytest.fixture()
def mock_client(tmp_path, monkeypatch):
    monkeypatch.setattr(mock_module, "DB_PATH", tmp_path / "mock-api-test.sqlite3")
    monkeypatch.setattr(mock_module, "DEMO_API_KEY", "test-demo-key")
    monkeypatch.setattr(mock_module, "FORCED_REFUND_STATUS", "SUCCESS")
    with TestClient(mock_module.app) as client:
        yield client


def payload(request_id: str = "REQ-MOCK-1") -> dict[str, object]:
    return {
        "request_id": request_id,
        "order_id": "ORD-MOCK-1",
        "product_id": "PROD-001",
        "product_name": "Wireless Mouse",
        "amount_inr": 1299,
        "customer_email": "buyer@example.com",
        "reason": "Damaged item",
    }


def test_mock_refund_api_fails_closed_without_key(mock_client, monkeypatch):
    monkeypatch.setattr(mock_module, "DEMO_API_KEY", "")
    response = mock_client.post("/api/v1/refunds", json=payload(), headers={"Idempotency-Key": "REQ-MOCK-1"})
    assert response.status_code == 503


def test_mock_refund_api_rejects_wrong_key(mock_client):
    response = mock_client.get("/api/v1/transactions", headers={"X-Demo-API-Key": "wrong"})
    assert response.status_code == 401


def test_mock_refund_failure_is_persisted_and_idempotent(mock_client, monkeypatch):
    monkeypatch.setattr(mock_module, "FORCED_REFUND_STATUS", "FAILED")
    headers = {"X-Demo-API-Key": "test-demo-key", "Idempotency-Key": "REQ-MOCK-FAIL"}
    first = mock_client.post("/api/v1/refunds", json=payload("REQ-MOCK-FAIL"), headers=headers)
    replay = mock_client.post("/api/v1/refunds", json=payload("REQ-MOCK-FAIL"), headers=headers)
    assert first.status_code == 200
    assert first.json()["status"] == "FAILED"
    assert first.json()["real_money_moved"] is False
    assert replay.status_code == 200
    assert replay.json()["status"] == "FAILED"
    assert replay.json()["idempotent_replay"] is True
    assert replay.json()["transaction_id"] == first.json()["transaction_id"]
    ledger = mock_client.get("/api/v1/transactions", headers={"X-Demo-API-Key": "test-demo-key"})
    assert ledger.status_code == 200
    assert ledger.json()["count"] == 1


def test_mock_refund_success_is_synthetic(mock_client):
    response = mock_client.post(
        "/api/v1/refunds",
        json=payload("REQ-MOCK-SUCCESS"),
        headers={"X-Demo-API-Key": "test-demo-key", "Idempotency-Key": "REQ-MOCK-SUCCESS"},
    )
    assert response.status_code == 200
    assert response.json()["status"] == "SUCCESS"
    assert response.json()["real_money_moved"] is False
    assert response.json()["transaction_id"].startswith("DEMO-TXN-")
