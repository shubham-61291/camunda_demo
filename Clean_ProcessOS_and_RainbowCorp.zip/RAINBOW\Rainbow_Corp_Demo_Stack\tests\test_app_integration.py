from __future__ import annotations
import sys
from pathlib import Path
import pytest
from fastapi.testclient import TestClient

APP_DIR = Path(__file__).resolve().parents[1] / "rainbow_corp_app"
sys.path.insert(0, str(APP_DIR))
import main as app_module  # noqa: E402

TOKEN = "test-integration-token"
HEADERS = {"X-Integration-Key": TOKEN}
PRODUCTS = {"PROD-001": ("Wireless Mouse", 1299.0), "PROD-002": ("Office Keyboard", 2499.0), "PROD-003": ("Studio Headphones", 4499.0), "PROD-004": ("24-inch Monitor", 12999.0), "PROD-005": ("Smartphone Pro", 24999.0)}

@pytest.fixture()
def client(tmp_path, monkeypatch):
    monkeypatch.setattr(app_module, "DB_PATH", tmp_path / "rainbow_test.sqlite3")
    monkeypatch.setattr(app_module, "INTEGRATION_API_TOKEN", TOKEN)
    # One TestClient startup initializes an isolated local database for each test.
    with TestClient(app_module.app) as test_client:
        yield test_client


def create_request(client, product_id="PROD-001", order_id="ORD-TEST-1", email="person@example.com"):
    # Customer refund claims must be backed by an active master order record.
    product_name, purchase_amount = PRODUCTS[product_id]
    existing = client.get("/api/admin/master-records", params={"q": order_id}).json()["records"]
    if not any(r["order_id"].strip().lower() == order_id.strip().lower() and r["customer_email"].strip().lower() == email.strip().lower() for r in existing):
        client.post("/api/admin/master-records", json={
            "order_id": order_id.strip(), "customer_name": "Demo Person", "customer_email": email.strip().lower(),
            "product_id": product_id, "product_name": product_name, "purchase_amount_inr": purchase_amount,
            "record_status": "Active",
        })
    return client.post("/api/requests", json={
        "customer_name": "Demo Person",
        "customer_email": email,
        "order_id": order_id,
        "product_id": product_id,
        "reason": "Demo refund reason",
    })


def test_catalogue_has_five_products_and_expected_price_distribution(client):
    response = client.get("/api/products")
    assert response.status_code == 200
    products = response.json()["products"]
    assert len(products) == 5
    costs = [p["standard_cost_inr"] for p in products]
    assert sum(cost <= 5000 for cost in costs) == 3
    assert sum(cost > 5000 for cost in costs) == 2
    assert all("routing" not in p for p in products)


def test_request_is_stored_but_not_routed_or_refunded_by_app(client):
    response = create_request(client)
    assert response.status_code == 201
    payload = response.json()
    assert payload["request"]["status"] == "Queued for Workflow"
    assert payload["request"]["workflow_dispatch_status"] == "Queued"
    assert payload["request"]["refund_transaction_id"] == ""
    assert "refund_api" not in payload
    assert payload["workflow"]["queued"] is True


def test_duplicate_order_email_and_amount_is_blocked(client):
    first = create_request(client, order_id="ORD-TEST-2", email="Person@Example.com")
    duplicate = create_request(client, order_id=" ord-test-2 ", email="person@example.com")
    assert first.status_code == 201
    assert duplicate.status_code == 200
    assert duplicate.json()["duplicate"] is True
    assert duplicate.json()["request"]["request_id"] == first.json()["request"]["request_id"]
    assert client.get("/api/admin/requests").json()["count"] == 1


def test_integration_endpoints_require_token(client):
    assert client.get("/api/integration/requests/pending").status_code == 401
    assert client.get("/api/integration/requests/pending", headers={"X-Integration-Key": "wrong"}).status_code == 401


def test_bridge_can_claim_and_attach_workflow_reference(client):
    request_id = create_request(client, order_id="ORD-TEST-3").json()["request"]["request_id"]
    pending = client.get("/api/integration/requests/pending", headers=HEADERS).json()
    assert pending["count"] == 1
    assert pending["records"][0]["request_id"] == request_id
    claim = client.post(f"/api/integration/requests/{request_id}/claim", headers=HEADERS)
    assert claim.status_code == 200 and claim.json()["claimed"] is True
    dispatch = client.post(f"/api/integration/requests/{request_id}/dispatch-result", headers=HEADERS, json={
        "outcome": "STARTED", "workflow_reference": "process-123"
    })
    assert dispatch.status_code == 200
    assert dispatch.json()["request"]["status"] == "Workflow Running"
    assert dispatch.json()["request"]["workflow_reference"] == "process-123"
    assert client.get("/api/integration/requests/pending", headers=HEADERS).json()["count"] == 0


def test_workflow_routes_high_value_request_to_review_and_decision_is_queued(client):
    request_id = create_request(client, product_id="PROD-004", order_id="ORD-TEST-4").json()["request"]["request_id"]
    claim = client.post(f"/api/integration/requests/{request_id}/claim", headers=HEADERS)
    assert claim.status_code == 200
    client.post(f"/api/integration/requests/{request_id}/dispatch-result", headers=HEADERS,
                json={"outcome": "STARTED", "workflow_reference": "process-high-4"})
    routed = client.post(f"/api/integration/requests/{request_id}/review-required", headers=HEADERS,
                         json={"review_reason": "Workflow amount gateway selected human review"})
    assert routed.status_code == 200
    assert routed.json()["request"]["human_review_required"] is True
    review_id = routed.json()["review"]["review_id"]
    decision = client.patch(f"/api/admin/review-queue/{review_id}", json={
        "decision": "approve", "reviewer_id": "reviewer-1", "comments": "Approved for demo"
    })
    assert decision.status_code == 200
    assert decision.json()["workflow_event_queued"] is True
    assert decision.json()["request"]["status"] == "Human Approval Recorded - Awaiting Workflow"
    assert decision.json()["request"]["refund_transaction_id"] == ""
    pending = client.get("/api/integration/review-decisions/pending", headers=HEADERS).json()
    assert pending["count"] == 1
    assert pending["records"][0]["review_id"] == review_id
    assert pending["records"][0]["workflow_reference"] == "process-high-4"
    ack = client.post(f"/api/integration/review-decisions/{review_id}/ack", headers=HEADERS)
    assert ack.status_code == 200 and ack.json()["acknowledged"] is True
    assert client.get("/api/integration/review-decisions/pending", headers=HEADERS).json()["count"] == 0


def test_external_workflow_success_updates_database_only_via_result_callback(client):
    request_id = create_request(client, order_id="ORD-TEST-5").json()["request"]["request_id"]
    response = client.post(f"/api/integration/requests/{request_id}/workflow-result", headers=HEADERS, json={
        "status": "SUCCESS", "transaction_id": "DEMO-TXN-123", "message": "Synthetic API success"
    })
    assert response.status_code == 200
    row = response.json()["request"]
    assert row["status"] == "Refund Completed (Demo)"
    assert row["refund_transaction_id"] == "DEMO-TXN-123"
    assert row["final_outcome"].startswith("SUCCESS")


def test_failed_or_unknown_dispatch_does_not_claim_success(client):
    request_id = create_request(client, order_id="ORD-TEST-6").json()["request"]["request_id"]
    response = client.post(f"/api/integration/requests/{request_id}/dispatch-result", headers=HEADERS, json={
        "outcome": "UNKNOWN", "error": "Timed out after the start request"
    })
    assert response.status_code == 200
    assert response.json()["request"]["status"] == "Workflow Start Outcome Unknown"
    assert response.json()["request"]["refund_transaction_id"] == ""


def test_websocket_pushes_live_database_changes(client):
    with client.websocket_connect("/ws/updates") as websocket:
        response = create_request(client, order_id="ORD-TEST-7")
        assert response.status_code == 201
        first_event = websocket.receive_json()  # master order is registered before the refund request
        event = websocket.receive_json()
        assert first_event["action"] == "MASTER_RECORD_CREATED"
        assert event["type"] == "data_changed"
        assert event["action"] == "REQUEST_CREATED"
        assert event["entity_id"] == response.json()["request"]["request_id"]


def test_unconfigured_integration_token_fails_closed(client, monkeypatch):
    monkeypatch.setattr(app_module, "INTEGRATION_API_TOKEN", "")
    response = client.get("/api/integration/health", headers=HEADERS)
    assert response.status_code == 503


def test_request_requires_matching_registered_order_and_email(client):
    client.post("/api/admin/master-records", json={
        "order_id": "ORD-VERIFIED", "customer_name": "Real Customer", "customer_email": "real@example.com",
        "product_id": "PROD-001", "product_name": "Wireless Mouse", "purchase_amount_inr": 1299, "record_status": "Active",
    })
    response = client.post("/api/requests", json={
        "customer_name": "Someone Else", "customer_email": "wrong@example.com", "order_id": "ORD-VERIFIED",
        "product_id": "PROD-001", "reason": "Damaged package",
    })
    assert response.status_code == 422


def test_failed_refund_can_be_resubmitted(client):
    first = create_request(client, order_id="ORD-FAILED-RETRY")
    request_id = first.json()["request"]["request_id"]
    failed = client.post(f"/api/integration/requests/{request_id}/workflow-result", headers=HEADERS, json={
        "status": "FAILED", "message": "Synthetic transient failure"
    })
    assert failed.status_code == 200
    again = create_request(client, order_id="ORD-FAILED-RETRY")
    assert again.status_code == 201
    assert again.json()["duplicate"] is False
    assert again.json()["request"]["request_id"] != request_id


def test_failed_dispatch_stops_after_three_claimed_attempts(client):
    request_id = create_request(client, order_id="ORD-DISPATCH-RETRY").json()["request"]["request_id"]
    for attempt in range(1, 4):
        claimed = client.post(f"/api/integration/requests/{request_id}/claim", headers=HEADERS)
        assert claimed.status_code == 200 and claimed.json()["claimed"] is True
        result = client.post(f"/api/integration/requests/{request_id}/dispatch-result", headers=HEADERS, json={
            "outcome": "FAILED", "error": f"known failure {attempt}"
        })
        assert result.status_code == 200
    final_request = result.json()["request"]
    assert final_request["workflow_dispatch_status"] == "Failed"
    assert final_request["workflow_dispatch_attempts"] == 3
    assert final_request["status"] == "Workflow Dispatch Permanently Failed"
    assert client.get("/api/integration/requests/pending", headers=HEADERS).json()["count"] == 0


def test_unknown_dispatch_never_auto_requeues_and_requires_explicit_confirmation(client):
    request_id = create_request(client, order_id="ORD-UNKNOWN-REQUEUE").json()["request"]["request_id"]
    unknown = client.post(f"/api/integration/requests/{request_id}/dispatch-result", headers=HEADERS, json={
        "outcome": "UNKNOWN", "error": "start outcome could not be confirmed"
    })
    assert unknown.status_code == 200
    assert client.get("/api/integration/requests/pending", headers=HEADERS).json()["count"] == 0
    bad = client.post(f"/api/admin/requests/{request_id}/requeue-start", json={"confirmation": "yes"})
    assert bad.status_code == 422
    good = client.post(f"/api/admin/requests/{request_id}/requeue-start", json={"confirmation": "I VERIFIED NO PROCESS STARTED"})
    assert good.status_code == 200
    assert good.json()["request"]["workflow_dispatch_status"] == "Queued"
    assert client.get("/api/integration/requests/pending", headers=HEADERS).json()["count"] == 1


def test_dispatched_review_cannot_be_reset_to_pending(client):
    request_id = create_request(client, product_id="PROD-004", order_id="ORD-REVIEW-LOCK").json()["request"]["request_id"]
    client.post(f"/api/integration/requests/{request_id}/claim", headers=HEADERS)
    client.post(f"/api/integration/requests/{request_id}/dispatch-result", headers=HEADERS, json={
        "outcome": "STARTED", "workflow_reference": "PI-REVIEW-LOCK"
    })
    review = client.post(f"/api/integration/requests/{request_id}/review-required", headers=HEADERS, json={
        "review_reason": "Above threshold"
    }).json()["review"]
    review_id = review["review_id"]
    decision = client.patch(f"/api/admin/review-queue/{review_id}", json={
        "decision": "reject", "reviewer_id": "reviewer-test", "comments": "Rejected for demo"
    })
    assert decision.status_code == 200
    assert client.post(f"/api/integration/review-decisions/{review_id}/ack", headers=HEADERS).status_code == 200
    reset = client.patch(f"/api/admin/review-queue/{review_id}", json={
        "decision": "pending", "reviewer_id": "reviewer-test", "comments": "try reset"
    })
    assert reset.status_code == 409
