@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (echo Install Python 3.11+ first.& pause & exit /b 1)
if not exist ".env" (
  copy ".env.example" ".env" >nul
  echo Created local_bridge\.env. Fill the workflow REST address and credentials first.
  pause
  exit /b 1
)
if not exist ".venv\Scripts\python.exe" (py -3 -m venv .venv)
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 (pause & exit /b 1)
".venv\Scripts\python.exe" deploy_process.py
pause
