"""Trusted offline validator and runtime for ProcessOS.

Generated CLI files are thin, trusted entrypoints. Conversation secrets are
injected for the duration of one direct-run subprocess and are never persisted.
The existing Rainbow Corp bridge is imported/launched unmodified.
"""
from __future__ import annotations

import argparse
import asyncio
import json
import os
import subprocess
import sys
from pathlib import Path
from typing import Any
from urllib.parse import urlparse
import xml.etree.ElementTree as ET

import httpx
from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parent
load_dotenv(ROOT / ".env")
BPMN_NS = {"bpmn": "http://www.omg.org/spec/BPMN/20100524/MODEL", "zeebe": "http://camunda.org/schema/zeebe/1.0"}
INTEGRATION_HEADER = "X-Integration-Key"
ACTION_HEADER = "X-Demo-API-Key"


def _read_runtime_context() -> dict[str, Any]:
    raw = os.getenv("PROCESSOS_RUNTIME_CONTEXT_JSON", "")
    if not raw:
        raise RuntimeError("No active ProcessOS conversation context is available. Keep ProcessOS running and run the CLI for the active session.")
    try:
        context = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise RuntimeError("The in-memory session context could not be decoded.") from exc
    if not isinstance(context, dict) or not isinstance(context.get("blueprint"), dict):
        raise RuntimeError("The active session context is incomplete.")
    return context


def validate_workflow(workflow_dir: Path) -> list[str]:
    errors: list[str] = []
    bpmn_path = workflow_dir / "workflow.bpmn"
    cli_path = workflow_dir / "cli_orchestrator.py"
    blueprint_path = workflow_dir / "blueprint.json"
    if not bpmn_path.is_file():
        errors.append(f"Missing BPMN file: {bpmn_path}")
    if not cli_path.is_file():
        errors.append(f"Missing CLI entrypoint: {cli_path}")
    if not blueprint_path.is_file():
        errors.append(f"Missing saved credential-free blueprint: {blueprint_path}")
    if errors:
        return errors
    try:
        blueprint = json.loads(blueprint_path.read_text(encoding="utf-8"))
        bpmn_xml = bpmn_path.read_text(encoding="utf-8")
        cli_code = cli_path.read_text(encoding="utf-8")
        from processos_studio_agent import deterministic_checks
        errors.extend(deterministic_checks(bpmn_xml, cli_code, blueprint))
        root = ET.fromstring(bpmn_xml)
        process_ids = [p.get("id") for p in root.findall("bpmn:process", BPMN_NS)]
        if blueprint.get("process_id") not in process_ids:
            errors.append(f"BPMN process ID does not match blueprint process_id={blueprint.get('process_id')!r}.")
        # Only permit the reviewed, generated CLI shim shape. This prevents a
        # Coder response or edited artifact from becoming arbitrary local Python.
        expected_cli = _trusted_cli_shim()
        if cli_code != expected_cli:
            errors.append("cli_orchestrator.py differs from the trusted ProcessOS CLI shim; refusing execution.")
    except Exception as exc:
        errors.append(f"Workflow validation failed: {type(exc).__name__}: {exc}")
    return errors


def _trusted_cli_shim() -> str:
    return '''"""Generated ProcessOS CLI entrypoint; local execution is brokered by ProcessOS."""\nfrom __future__ import annotations\nimport argparse\nimport json\nimport sys\nfrom pathlib import Path\nimport urllib.error\nimport urllib.request\n\nROOT = Path(__file__).resolve().parents[1]\nDEFAULT_SESSION = "processos-local-session"\n\ndef main() -> int:\n    parser = argparse.ArgumentParser(description="Shubham Singh ProcessOS workflow CLI")\n    parser.add_argument("--self-test", action="store_true", help="Offline BPMN and CLI validation only")\n    parser.add_argument("--run", action="store_true", help="Request the active local ProcessOS session to deploy and start the workflow")\n    parser.add_argument("--confirm", action="store_true", help="Explicitly authorize deployment and bridge startup")\n    parser.add_argument("--session-id", default=DEFAULT_SESSION)\n    args = parser.parse_args()\n    if args.self_test:\n        import subprocess\n        return subprocess.call([sys.executable, str(ROOT / "processos_runtime.py"), "--self-test", "--workflow-dir", str(Path(__file__).resolve().parent)])\n    if not args.run:\n        parser.print_help()\n        return 2\n    if not args.confirm:\n        print("Blocked: pass --confirm to authorize deployment and bridge startup.", file=sys.stderr)\n        return 2\n    payload = json.dumps({"session_id": args.session_id, "confirmed": True}).encode("utf-8")\n    request = urllib.request.Request("http://127.0.0.1:8090/api/cli/run", data=payload, headers={"Content-Type": "application/json"}, method="POST")\n    try:\n        with urllib.request.urlopen(request, timeout=1200) as response:\n            result = json.loads(response.read().decode("utf-8"))\n    except urllib.error.HTTPError as exc:\n        detail = exc.read().decode("utf-8", errors="replace")\n        print(f"ProcessOS rejected CLI run (HTTP {exc.code}): {detail}", file=sys.stderr)\n        return 2\n    except Exception as exc:\n        print(f"Could not reach ProcessOS at 127.0.0.1:8090: {type(exc).__name__}. Start ProcessOS and keep the discovery session active.", file=sys.stderr)\n        return 2\n    print(result.get("stdout", ""), end="")\n    if result.get("stderr"):\n        print(result["stderr"], file=sys.stderr, end="")\n    return int(result.get("exit_code", 1))\n\nif __name__ == "__main__":\n    raise SystemExit(main())\n'''


async def _probe_checked(url: str, headers: dict[str, str] | None = None) -> dict[str, Any]:
    from processos_studio_agent import probe_endpoint
    return await probe_endpoint(url, headers=headers or {})


async def _check_openapi(base_url: str, path: str, method: str, label: str) -> dict[str, Any]:
    from processos_studio_agent import probe_endpoint, safe_url_for_display
    if not base_url:
        return {"label": label, "verified": False, "reason": "Base URL is missing.", "url": ""}
    base = base_url.rstrip("/")
    openapi_url = f"{base}/openapi.json"
    probe = await probe_endpoint(openapi_url)
    if not probe.get("verified"):
        return {**probe, "label": label, "reason": f"OpenAPI check failed: {probe.get('reason', '')}"}
    try:
        async with httpx.AsyncClient(timeout=5, follow_redirects=False) as client:
            response = await client.get(openapi_url)
            response.raise_for_status()
            methods = response.json().get("paths", {}).get(path, {})
        ok = isinstance(methods, dict) and method.lower() in methods
        return {
            "url": safe_url_for_display(openapi_url), "label": label, "verified": ok, "status_code": 200,
            "reason": f"{path} is declared as {method.upper()} in OpenAPI." if ok else f"{path} is not declared as {method.upper()} in OpenAPI.",
        }
    except Exception as exc:
        return {"url": safe_url_for_display(openapi_url), "label": label, "verified": False, "status_code": None, "reason": f"OpenAPI inspection failed: {type(exc).__name__}."}



def _origin_key(url: str) -> tuple[str, int] | None:
    try:
        parsed = urlparse(url)
        if not parsed.hostname:
            return None
        port = parsed.port
        if port is None:
            port = 443 if parsed.scheme.lower() in {"https", "wss"} else 80
        return parsed.hostname.lower(), port
    except ValueError:
        return None


def _check_target_contract(bp: dict[str, Any], secrets: dict[str, Any]) -> tuple[str, str, str, str, str, str, str]:
    integration_header = str(bp.get("integration_header_name") or INTEGRATION_HEADER)
    action_header = str(bp.get("action_header_name") or ACTION_HEADER)
    if integration_header.lower() != INTEGRATION_HEADER.lower():
        raise RuntimeError(f"The installed, unmodified Rainbow bridge hard-codes {INTEGRATION_HEADER}. It cannot safely use the supplied {integration_header} header without changing the original app, which ProcessOS will not do.")
    if action_header.lower() != ACTION_HEADER.lower():
        raise RuntimeError(f"The installed, unmodified Rainbow bridge hard-codes {ACTION_HEADER}. It cannot use {action_header} without changing the original bridge, which ProcessOS will not do.")
    action_url = str(bp.get("action_api_url") or "").rstrip("/")
    if not action_url.endswith("/api/v1/refunds"):
        raise RuntimeError("The existing Rainbow bridge supports the action endpoint contract `/api/v1/refunds` only. ProcessOS will not rewrite the existing bridge to adapt an unrelated action API.")
    int_secret = secrets.get(INTEGRATION_HEADER.lower(), {}).get("value", "")
    action_secret = secrets.get(ACTION_HEADER.lower(), {}).get("value", "")
    if not int_secret:
        raise RuntimeError(f"The conversation has not supplied a value for the required {INTEGRATION_HEADER} header.")
    if not action_secret:
        raise RuntimeError(f"The conversation has not supplied a value for the required {ACTION_HEADER} header.")
    app_base = str(bp.get("app_base_url") or "").rstrip("/")
    int_origin = secrets.get(INTEGRATION_HEADER.lower(), {}).get("origin")
    action_origin = secrets.get(ACTION_HEADER.lower(), {}).get("origin")
    int_urls = [app_base, str(bp.get("integration_health_endpoint") or ""), str(bp.get("integration_poll_endpoint") or ""), str(bp.get("integration_status_endpoint") or "")]
    action_urls = [str(bp.get("action_api_url") or ""), str(bp.get("action_health_url") or ""), str(bp.get("action_verify_url") or "")]
    if not int_origin:
        raise RuntimeError(f"The stored {INTEGRATION_HEADER} has no verified origin. Re-enter it in the conversation alongside the Rainbow application URL.")
    if any(url and _origin_key(url) != tuple(int_origin) for url in int_urls):
        raise RuntimeError(f"The stored {INTEGRATION_HEADER} belongs to a different host/port than the configured Rainbow application endpoints. Re-enter it beside the correct application URL.")
    if not action_origin:
        raise RuntimeError(f"The stored {ACTION_HEADER} has no verified origin. Re-enter it in the conversation alongside the action API URL.")
    if any(url and _origin_key(url) != tuple(action_origin) for url in action_urls):
        raise RuntimeError(f"The stored {ACTION_HEADER} belongs to a different host/port than the configured action API endpoints. Re-enter it beside the correct action API URL.")
    int_health = str(bp.get("integration_health_endpoint") or "")
    int_poll = str(bp.get("integration_poll_endpoint") or "")
    int_status = str(bp.get("integration_status_endpoint") or "")
    action_health = str(bp.get("action_health_url") or "")
    action_verify = str(bp.get("action_verify_url") or "")
    ws_url = str(bp.get("websocket_url") or "")
    required = {
        "app_base_url": app_base, "integration_health_endpoint": int_health,
        "integration_poll_endpoint": int_poll, "integration_status_endpoint": int_status,
        "action_api_url": action_url, "action_health_url": action_health,
        "action_verify_url": action_verify, "websocket_url": ws_url,
    }
    missing = [key for key, value in required.items() if not value]
    if missing:
        raise RuntimeError("Missing verified blueprint fields: " + ", ".join(missing) + ". Provide those URLs in the conversation and probe them before execution.")
    return app_base, int_secret, action_url, action_health, action_verify, action_secret, ws_url


async def _runtime_preflight(bp: dict[str, Any], secrets: dict[str, Any]) -> list[dict[str, Any]]:
    from processos_studio_agent import probe_endpoint
    app_base, int_secret, action_url, action_health, action_verify, action_secret, ws_url = _check_target_contract(bp, secrets)
    int_header = {INTEGRATION_HEADER: int_secret}
    action_header = {ACTION_HEADER: action_secret}
    pending = str(bp["integration_poll_endpoint"])
    pending += ("&" if "?" in pending else "?") + "limit=1"
    endpoint_tasks = [
        probe_endpoint(str(bp["integration_health_endpoint"]), headers=int_header),
        probe_endpoint(pending, headers=int_header),
        probe_endpoint(action_health),
        probe_endpoint(action_verify, headers=action_header),
        probe_endpoint(ws_url),
    ]
    checks = list(await asyncio.gather(*endpoint_tasks))
    labels = ["integration health", "pending queue", "action API health", "action API authentication", "WebSocket"]
    for result, label in zip(checks, labels):
        result["label"] = label
    app_route = await _check_openapi(app_base, "/api/integration/requests/{request_id}/workflow-result", "post", "result endpoint declared")
    action_parsed = urlparse(action_url)
    action_base = f"{action_parsed.scheme}://{action_parsed.netloc}"
    action_route = await _check_openapi(action_base, action_parsed.path.rstrip("/"), "post", "action endpoint declared")
    checks += [app_route, action_route]
    return checks


def _bridge_process_running(bridge_file: Path) -> bool:
    try:
        import psutil
        target = str(bridge_file.resolve()).lower()
        for process in psutil.process_iter(["pid", "cmdline"]):
            try:
                if process.info.get("pid") == os.getpid():
                    continue
                command = " ".join(process.info.get("cmdline") or []).lower()
                if target in command or ("local_bridge" in command and "bridge.py" in command):
                    return True
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                continue
    except Exception:
        pass
    return False


def _deploy_using_existing_bridge(bpmn_path: Path, bridge_dir: Path, bp: dict[str, Any], secrets: dict[str, Any]) -> dict[str, Any]:
    """Import the existing bridge with session values overriding its .env in memory only."""
    import importlib
    app_base, int_secret, action_url, _health, _verify, action_secret, _ws = _check_target_contract(bp, secrets)
    process_id = str(bp.get("process_id") or "rainbow-refund-process")
    os.environ.update({
        "APP_BASE_URL": app_base,
        "INTEGRATION_API_TOKEN": int_secret,
        "DEMO_REFUND_API_URL": action_url,
        "DEMO_REFUND_API_KEY": action_secret,
        "CAMUNDA_REST_ADDRESS": "http://127.0.0.1:8080",
        "CAMUNDA_AUTH_MODE": "none",
        "CAMUNDA_PROCESS_DEFINITION_ID": process_id,
        "CAMUNDA_CLIENT_ID": "",
        "CAMUNDA_CLIENT_SECRET": "",
        "CAMUNDA_OAUTH_URL": "",
        "CAMUNDA_TOKEN_AUDIENCE": "",
    })
    bridge_path = str(bridge_dir.resolve())
    if bridge_path not in sys.path:
        sys.path.insert(0, bridge_path)
    try:
        # The runtime is its own process; this import path will not modify files.
        sys.modules.pop("bridge", None)
        bridge = importlib.import_module("bridge")
        expected_process_id = str(bridge.CAMUNDA_PROCESS_DEFINITION_ID)
        root = ET.fromstring(bpmn_path.read_text(encoding="utf-8"))
        ids = [node.get("id") for node in root.findall("bpmn:process", BPMN_NS)]
        if expected_process_id not in ids:
            raise RuntimeError(f"Generated process ID {ids!r} does not match the runtime bridge process ID {expected_process_id!r}.")

        async def deploy() -> dict[str, Any]:
            client = bridge.WorkflowRestClient()
            try:
                return await client.request("POST", "/deployments", files={"resources": (bpmn_path.name, bpmn_path.read_bytes(), "application/xml")})
            finally:
                await client.close()
        result = asyncio.run(deploy())
        return {"process_id": expected_process_id, "deployment_response": result}
    finally:
        try:
            sys.path.remove(bridge_path)
        except ValueError:
            pass


def _start_existing_bridge(bridge_dir: Path, bp: dict[str, Any], secrets: dict[str, Any]) -> dict[str, Any]:
    bridge_file = bridge_dir / "bridge.py"
    if _bridge_process_running(bridge_file):
        raise RuntimeError(
            "An existing Rainbow bridge process is already running. ProcessOS will not start a duplicate or silently change its runtime. "
            "Stop that bridge manually, then rerun the CLI so it can inherit the verified conversation credentials and local Camunda target."
        )
    # Do not pass ProcessOS/OpenAI or the entire session-context JSON to the bridge.
    child_env = {key: value for key, value in os.environ.items() if key not in {"OPENAI_API_KEY", "PROCESSOS_RUNTIME_CONTEXT_JSON"}}
    child_env.update({
        "APP_BASE_URL": str(bp["app_base_url"]).rstrip("/"),
        "INTEGRATION_API_TOKEN": str(secrets[INTEGRATION_HEADER.lower()]["value"]),
        "DEMO_REFUND_API_URL": str(bp["action_api_url"]),
        "DEMO_REFUND_API_KEY": str(secrets[ACTION_HEADER.lower()]["value"]),
        "CAMUNDA_REST_ADDRESS": "http://127.0.0.1:8080",
        "CAMUNDA_AUTH_MODE": "none",
        "CAMUNDA_PROCESS_DEFINITION_ID": str(bp["process_id"]),
        "CAMUNDA_CLIENT_ID": "",
        "CAMUNDA_CLIENT_SECRET": "",
        "CAMUNDA_OAUTH_URL": "",
        "CAMUNDA_TOKEN_AUDIENCE": "",
    })
    logs = ROOT / "logs"
    logs.mkdir(parents=True, exist_ok=True)
    log_file = logs / "rainbow_bridge.log"
    handle = open(log_file, "a", encoding="utf-8")
    flags = 0
    if os.name == "nt":
        flags = getattr(subprocess, "DETACHED_PROCESS", 0) | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
    proc = subprocess.Popen(
        [sys.executable, str(bridge_file)], cwd=str(bridge_dir), env=child_env,
        stdin=subprocess.DEVNULL, stdout=handle, stderr=subprocess.STDOUT,
        creationflags=flags, close_fds=True,
    )
    handle.close()
    return {"started": True, "pid": proc.pid, "log_file": str(log_file)}


def run_direct(workflow_dir: Path) -> int:
    try:
        context = _read_runtime_context()
        bp = context["blueprint"]
        secrets = context.get("secrets") or {}
        errors = validate_workflow(workflow_dir)
        if errors:
            print("SELF-TEST FAIL")
            for error in errors:
                print(" - " + error)
            return 1
        print("SELF-TEST PASS: BPMN contract, process ID, worker types, and trusted CLI shim validated.")

        # Validate the target stack and APIs before any potentially expensive
        # Camunda download/start. A wrong path or stopped service must not trigger
        # a background cluster installation.
        stack = Path(str(bp.get("rainbow_stack_dir") or "")).expanduser().resolve()
        bridge_dir = stack / "local_bridge"
        bridge_file = bridge_dir / "bridge.py"
        if not bridge_file.is_file():
            raise RuntimeError(f"The path from discovery does not contain local_bridge/bridge.py: {bridge_file}")
        if _bridge_process_running(bridge_file):
            raise RuntimeError("An existing Rainbow bridge process is already running. Stop it manually before ProcessOS starts the same bridge with this session's local Camunda settings.")

        print("PREFLIGHT: checking all supplied endpoints and credentials…", flush=True)
        checks = asyncio.run(_runtime_preflight(bp, secrets))
        for check in checks:
            print(f"{'PASS' if check.get('verified') else 'FAIL'} [{check.get('label', 'endpoint')}] {check.get('url', '')} — {check.get('reason', '')}")
        failed = [check for check in checks if not check.get("verified")]
        if failed:
            print("LIVE PREFLIGHT FAILED; Camunda was not started, BPMN was not deployed, and the bridge was not started.", file=sys.stderr)
            return 2

        from camunda_manager import ensure_camunda
        print("CAMUNDA: checking CLI, prerequisites, and local cluster…", flush=True)
        camunda = ensure_camunda(start=True)
        print("CAMUNDA: local cluster ready at http://127.0.0.1:8080/v2", flush=True)
        print(json.dumps({"already_running": camunda.get("already_running"), "started": camunda.get("started"), "cli_version": camunda.get("status", {}).get("cli_version")}, indent=2))

        bpmn_file = workflow_dir / "workflow.bpmn"
        print("DEPLOY: submitting BPMN to the local Camunda REST API…", flush=True)
        deployment = _deploy_using_existing_bridge(bpmn_file, bridge_dir, bp, secrets)
        print("DEPLOY: successful response received.")
        print(json.dumps(deployment, indent=2, ensure_ascii=False, default=str))

        print("BRIDGE: starting the existing bridge without editing its source or .env…", flush=True)
        bridge_started = _start_existing_bridge(bridge_dir, bp, secrets)
        print(json.dumps(bridge_started, indent=2))
        print("RUN COMPLETE. Check the original Rainbow customer/admin UI. Bridge logs: " + str(ROOT / "logs" / "rainbow_bridge.log"))
        return 0
    except Exception as exc:
        print(f"RUN FAILED: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 2


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="ProcessOS trusted local workflow runtime")
    parser.add_argument("--self-test", action="store_true", help="Offline validation; does not contact Camunda or target APIs")
    parser.add_argument("--direct-run", action="store_true", help=argparse.SUPPRESS)
    parser.add_argument("--workflow-dir", type=Path, default=ROOT / "generated_workflow")
    args = parser.parse_args(argv)
    errors = validate_workflow(args.workflow_dir)
    if errors:
        print("SELF-TEST FAIL")
        for error in errors:
            print(" - " + error)
        return 1
    print("SELF-TEST PASS: BPMN parses, route/threshold/approval contract and CLI shim are valid.")
    if args.self_test:
        print("Offline validation only; no Camunda installation, network probe, deployment, or bridge startup was performed.")
        return 0
    if args.direct_run:
        return run_direct(args.workflow_dir)
    parser.print_help()
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
