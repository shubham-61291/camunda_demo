from __future__ import annotations
import asyncio
from pathlib import Path
from dotenv import load_dotenv
from bridge import WorkflowRestClient

BASE_DIR = Path(__file__).resolve().parent
PROJECT_DIR = BASE_DIR.parent
BPMN_PATH = PROJECT_DIR / "workflow_assets" / "rainbow-refund-process.bpmn"

async def main() -> None:
    if not BPMN_PATH.exists():
        raise SystemExit(f"BPMN file not found: {BPMN_PATH}")
    content = BPMN_PATH.read_bytes()
    client = WorkflowRestClient()
    try:
        result = await client.request(
            "POST",
            "/deployments",
            files={"resources": (BPMN_PATH.name, content, "application/xml")},
        )
        print("Deployment request succeeded.")
        print(result)
    finally:
        await client.close()

if __name__ == "__main__":
    load_dotenv(BASE_DIR / ".env")
    try:
        asyncio.run(main())
    except Exception as exc:
        raise SystemExit(f"Deployment failed: {type(exc).__name__}: {exc}")
