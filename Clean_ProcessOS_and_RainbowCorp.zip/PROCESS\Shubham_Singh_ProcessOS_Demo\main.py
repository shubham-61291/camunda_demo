from __future__ import annotations

import asyncio
import hashlib
import json
import os
import re
import subprocess
import sys
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

import httpx
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")

from camunda_manager import ensure_camunda, status as camunda_status  # noqa: E402
from processos_studio_agent import (  # noqa: E402
    BUILD_ID,
    DEFAULT_MODEL,
    coder_tester_loop,
    conversational_reply,
    env,
    extract_auth,
    extract_urls,
    initial_blueprint,
    probe_endpoint,
    redact_secrets,
    safe_url_for_display,
)

app = FastAPI(title="Shubham Singh ProcessOS Demo", version=BUILD_ID)
app.mount("/static", StaticFiles(directory=BASE_DIR / "static"), name="static")
SESSIONS: dict[str, dict[str, Any]] = {}
INTEGRATION_HEADER = "X-Integration-Key"
ACTION_HEADER = "X-Demo-API-Key"


def _default_demo_secrets() -> dict[str, Any]:
    secrets: dict[str, Any] = {}
    int_token = env("INTEGRATION_API_TOKEN")
    demo_key = env("DEMO_REFUND_API_KEY")
    rainbow_dir = BASE_DIR.parent.parent / "RAINBOW" / "Rainbow_Corp_Demo_Stack"
    if not int_token:
        candidate = rainbow_dir / "rainbow_corp_app" / ".env"
        if candidate.is_file():
            try:
                for line in candidate.read_text(encoding="utf-8").splitlines():
                    if line.strip().startswith("INTEGRATION_API_TOKEN="):
                        int_token = line.split("=", 1)[1].strip().strip('"').strip("'")
            except Exception:
                pass
    if not demo_key:
        candidate = rainbow_dir / "mock_refund_api" / ".env"
        if candidate.is_file():
            try:
                for line in candidate.read_text(encoding="utf-8").splitlines():
                    if line.strip().startswith("DEMO_REFUND_API_KEY="):
                        demo_key = line.split("=", 1)[1].strip().strip('"').strip("'")
            except Exception:
                pass
    if int_token:
        secrets[INTEGRATION_HEADER.lower()] = {"name": INTEGRATION_HEADER, "value": int_token, "origin": ("127.0.0.1", 8000)}
    if demo_key:
        secrets[ACTION_HEADER.lower()] = {"name": ACTION_HEADER, "value": demo_key, "origin": ("127.0.0.1", 8001)}
    return secrets


def session_state(session_id: str) -> dict[str, Any]:
    sid = session_id.strip() or "default"
    if sid not in SESSIONS:
        SESSIONS[sid] = {
            "blueprint": initial_blueprint(),
            "secrets": _default_demo_secrets(),
            "probes": {},
            "last_build": None,
            "chat": [],
            "last_probe_target": None,
            "verified_probe_signature": None,
        }
    return SESSIONS[sid]


def _origin_key(url: str) -> tuple[str, int] | None:
    """Normalize an HTTP/WS origin for credential scoping, independent of scheme aliases."""
    try:
        parsed = urlparse(url)
        if not parsed.hostname:
            return None
        scheme = parsed.scheme.lower()
        port = parsed.port
        if port is None:
            port = 443 if scheme in {"https", "wss"} else 80
        host = parsed.hostname.lower()
        if host in {"localhost", "127.0.0.1"}:
            host = "127.0.0.1"
        return host, port
    except ValueError:
        return None


def _secret_value(state: dict[str, Any], header_name: str, url: str = "") -> str:
    found = state.get("secrets", {}).get(header_name.lower())
    if not found:
        defaults = _default_demo_secrets()
        found = defaults.get(header_name.lower())
        if found:
            state.setdefault("secrets", {})[header_name.lower()] = found
    if not found:
        for k, v in {**_default_demo_secrets(), **state.get("secrets", {})}.items():
            if str(v.get("name", "")).lower() == header_name.lower() or k.lower() == header_name.lower():
                found = v
                break
    if not found:
        return ""
    origin = found.get("origin")
    # Secrets without an explicit origin are never eligible for network use.
    if url and (not origin or _origin_key(url) != tuple(origin)):
        return ""
    return str(found.get("value", ""))


def _headers_for_url(state: dict[str, Any], url: str, explicit_name: str = "", explicit_value: str = "") -> dict[str, str]:
    # Explicit credentials are passed only by the handler that associates them
    # with this exact origin. Never spray stored keys across arbitrary URLs/WS.
    if explicit_name and explicit_value:
        return {explicit_name: explicit_value}
    if urlparse(url).scheme.lower() in {"ws", "wss"}:
        return {}
    secrets = state.get("secrets", {})
    if not secrets:
        secrets = _default_demo_secrets()
        state["secrets"] = secrets
    for key, item in secrets.items():
        origin = item.get("origin")
        if origin and _origin_key(url) == tuple(origin):
            return {str(item.get("name") or key): str(item.get("value") or "")}
    for key, item in _default_demo_secrets().items():
        origin = item.get("origin")
        if origin and _origin_key(url) == tuple(origin):
            return {str(item.get("name") or key): str(item.get("value") or "")}
    return {}


def _normalize_blueprint_url(state: dict[str, Any], url: str, verified: bool) -> None:
    """Infer sibling routes only from the known, supplied Rainbow demo API contract."""
    bp = state["blueprint"]
    parsed = urlparse(url)
    origin = f"{parsed.scheme}://{parsed.netloc}"
    path = parsed.path.rstrip("/") or "/"
    lower = path.lower()
    if parsed.scheme in {"ws", "wss"}:
        bp["websocket_url"] = safe_url_for_display(url)
        return
    if "/api/integration/" in lower:
        bp["app_base_url"] = origin
        bp["integration_health_endpoint"] = f"{origin}/api/integration/health"
        bp["integration_poll_endpoint"] = f"{origin}/api/integration/requests/pending"
        bp["integration_status_endpoint"] = f"{origin}/api/integration/requests/{{request_id}}/workflow-result"
        bp["integration_header_name"] = INTEGRATION_HEADER
    if lower.endswith("/api/v1/refunds"):
        bp["action_api_url"] = f"{origin}{path}"
        prefix = path[:-len("/api/v1/refunds")].rstrip("/")
        bp["action_health_url"] = f"{origin}{prefix}/health"
        bp["action_verify_url"] = f"{origin}{prefix}/api/v1/transactions"
        bp["action_header_name"] = ACTION_HEADER
    elif lower.endswith("/api/v1/transactions"):
        prefix = path[:-len("/api/v1/transactions")].rstrip("/")
        bp["action_api_url"] = f"{origin}{prefix}/api/v1/refunds"
        bp["action_health_url"] = f"{origin}{prefix}/health"
        bp["action_verify_url"] = f"{origin}{path}"
        bp["action_header_name"] = ACTION_HEADER
    elif lower.endswith("/health") and "/api/integration/" not in lower:
        # This route is an action API health URL only when on the same host as
        # the already-discovered action API, or when the action API was supplied
        # in the same message. The caller fills remaining siblings if possible.
        if bp.get("action_api_url") and urlparse(str(bp["action_api_url"])).netloc == parsed.netloc:
            bp["action_health_url"] = f"{origin}{path}"


def _extract_project_path(message: str) -> str | None:
    patterns = [
        r"(?is)(?:rainbow(?:\s+corp)?|project|stack|application)?\s*(?:folder|directory|path)\s*(?:is|at|:|=)\s*['\"]([^'\"]{3,500})['\"]",
        r"(?i)([A-Z]:\\[^\r\n\"']{3,500})",
    ]
    for pattern in patterns:
        match = re.search(pattern, message)
        if not match:
            continue
        candidate = match.group(1).strip().rstrip(" .;,)")
        if "http://" not in candidate.lower() and "https://" not in candidate.lower() and ("\\" in candidate or candidate.startswith("/")):
            return candidate
    return None


def _probe_signature(state: dict[str, Any]) -> str:
    bp = state["blueprint"]
    public_fields = {
        key: bp.get(key)
        for key in (
            "rainbow_stack_dir", "app_base_url", "integration_health_endpoint",
            "integration_poll_endpoint", "integration_status_endpoint", "integration_header_name",
            "action_api_url", "action_health_url", "action_verify_url", "action_header_name", "websocket_url",
            "process_id", "refund_threshold", "business_rules",
        )
    }
    secret_fingerprints = {
        name: hashlib.sha256(str(value.get("value", "")).encode("utf-8")).hexdigest()
        for name, value in sorted(state["secrets"].items())
    }
    material = json.dumps({"blueprint": public_fields, "secret_fingerprints": secret_fingerprints}, sort_keys=True, ensure_ascii=False)
    return hashlib.sha256(material.encode("utf-8")).hexdigest()


class ChatBody(BaseModel):
    session_id: str = Field(default="default", max_length=120)
    message: str = Field(min_length=1, max_length=10000)


class ProbeBody(BaseModel):
    session_id: str = Field(default="default", max_length=120)
    url: str = Field(min_length=1, max_length=3000)
    method: str = "GET"
    header_name: str = ""
    header_value: str = ""
    payload: dict[str, Any] | None = None


class BlueprintBody(BaseModel):
    session_id: str = Field(default="default", max_length=120)
    blueprint: dict[str, Any]


class BuildBody(BaseModel):
    session_id: str = Field(default="default", max_length=120)
    blueprint: dict[str, Any] | None = None


class RunBody(BaseModel):
    session_id: str = Field(default="default", max_length=120)
    confirmed: bool = False


@app.get("/")
def home() -> FileResponse:
    return FileResponse(BASE_DIR / "static" / "studio.html")


@app.get("/api/status")
def status() -> dict[str, Any]:
    return {
        "app": "Shubham Singh ProcessOS Demo",
        "build_id": BUILD_ID,
        "bpmn_template_repair_enabled": True,
        "openai_key_configured": bool(env("OPENAI_API_KEY")),
        "model": DEFAULT_MODEL,
        "max_react_iterations": 3,
        "required_environment_variables": ["OPENAI_API_KEY"],
    }


@app.get("/api/camunda/status")
def get_camunda_status() -> dict[str, Any]:
    return camunda_status()


@app.post("/api/camunda/ensure")
async def ensure_local_camunda() -> dict[str, Any]:
    """Install the official CLI if needed and start local Camunda after user action."""
    try:
        return await asyncio.to_thread(ensure_camunda, True)
    except Exception as exc:
        raise HTTPException(503, f"Camunda setup did not complete: {exc}") from exc


@app.get("/api/blueprint")
def get_blueprint(session_id: str = "default") -> dict[str, Any]:
    state = session_state(session_id)
    return {
        "blueprint": state["blueprint"],
        "probes": list(state["probes"].values()),
        "build": state["last_build"],
        "verified": state["verified_probe_signature"] == _probe_signature(state) and bool(state["verified_probe_signature"]),
    }


@app.post("/api/blueprint")
def save_blueprint(body: BlueprintBody) -> dict[str, Any]:
    state = session_state(body.session_id)
    allowed = set(initial_blueprint().keys())
    bp = {key: value for key, value in body.blueprint.items() if key in allowed}
    process_id = str(bp.get("process_id", state["blueprint"].get("process_id", ""))).strip()
    if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_.-]{0,119}", process_id):
        raise HTTPException(400, "process_id must be a valid BPMN identifier.")
    bp["process_id"] = process_id
    try:
        threshold = float(bp.get("refund_threshold", state["blueprint"].get("refund_threshold", 5000)))
        if threshold <= 0 or threshold > 10_000_000:
            raise ValueError
        bp["refund_threshold"] = threshold
    except (TypeError, ValueError):
        raise HTTPException(400, "refund_threshold must be a positive number no greater than 10000000.")
    if not isinstance(bp.get("business_rules", state["blueprint"].get("business_rules")), list):
        raise HTTPException(400, "business_rules must be a list of strings.")
    merged = {**state["blueprint"], **bp}
    if any(not isinstance(rule, str) or len(rule) > 1000 for rule in merged["business_rules"]):
        raise HTTPException(400, "Each business rule must be a string up to 1000 characters.")
    state["blueprint"] = merged
    state["verified_probe_signature"] = None
    return {"saved": True, "blueprint": merged}


async def _run_probe(url: str, headers: dict[str, str] | None = None, method: str = "GET", payload: dict[str, Any] | None = None) -> dict[str, Any]:
    """Safe GET probes; POST requires explicit user intent in the manual form."""
    parsed = urlparse(url)
    if parsed.path.rstrip("/").lower().endswith("/api/v1/refunds") and method.upper() == "GET":
        # A refund route is action-oriented. Never POST a refund just to probe it;
        # inspect OpenAPI plus read-only transactions endpoint in the configured set.
        origin = f"{parsed.scheme}://{parsed.netloc}"
        openapi_url = f"{origin}/openapi.json"
        doc = await probe_endpoint(openapi_url)
        if doc.get("verified"):
            try:
                async with httpx.AsyncClient(timeout=4.0, follow_redirects=False) as client:
                    response = await client.get(openapi_url)
                    path_methods = response.json().get("paths", {}).get(parsed.path.rstrip("/"), {})
                doc["verified"] = isinstance(path_methods, dict) and "post" in path_methods
                doc["reason"] = "Refund POST route exists in OpenAPI. No refund request was sent; token auth is checked separately through the read-only verification endpoint." if doc["verified"] else "Refund POST route was not found in the API's OpenAPI document."
                doc["url"] = safe_url_for_display(url)
                doc["label"] = "action endpoint declared"
                return doc
            except Exception:
                pass
    return await probe_endpoint(url, method, headers, payload)


def _label_url(url: str) -> str:
    lower = url.lower()
    if lower.startswith(("ws://", "wss://")):
        return "WebSocket"
    if "/api/integration/health" in lower:
        return "integration health"
    if "/api/integration/requests/pending" in lower:
        return "pending queue"
    if "/workflow-result" in lower:
        return "result endpoint"
    if lower.endswith("/api/v1/refunds"):
        return "action endpoint declared"
    if lower.endswith("/api/v1/transactions"):
        return "action API authentication"
    if lower.endswith("/health"):
        return "action API health"
    return "endpoint"


@app.post("/api/probe")
async def manual_probe(body: ProbeBody) -> dict[str, Any]:
    state = session_state(body.session_id)
    method = body.method.upper()
    if method not in {"GET", "HEAD", "OPTIONS"}:
        raise HTTPException(400, "Endpoint probes are read-only (GET, HEAD, OPTIONS). For action endpoints, verify the route through OpenAPI and use a safe read-only authentication endpoint.")
    header_name, header_value = body.header_name.strip(), body.header_value
    if header_name and header_value:
        state["secrets"][header_name.lower()] = {"name": header_name, "value": header_value, "origin": _origin_key(body.url)}
    headers = {header_name: header_value} if header_name and header_value else _headers_for_url(state, body.url)
    result = await _run_probe(body.url, headers, method, body.payload)
    result["label"] = _label_url(body.url)
    state["probes"][result["url"]] = result
    state["last_probe_target"] = {"url": body.url, "header_name": header_name or _label_header(body.url), "method": method}
    _normalize_blueprint_url(state, body.url, bool(result.get("verified")))
    state["verified_probe_signature"] = None
    return {"result": result, "blueprint": state["blueprint"]}


def _label_header(url: str) -> str:
    lower = url.lower()
    if "/api/integration/" in lower:
        return INTEGRATION_HEADER
    if "/api/v1/" in lower or lower.endswith("/health"):
        return ACTION_HEADER
    return ""


async def _verify_openapi_route(base_url: str, route_path: str, method: str, label: str) -> dict[str, Any]:
    if not base_url:
        return {"url": "", "verified": False, "status_code": None, "label": label, "reason": "Endpoint URL has not been supplied in the conversation yet."}
    base = base_url.rstrip("/")
    openapi_url = f"{base}/openapi.json"
    doc_probe = await probe_endpoint(openapi_url)
    if not doc_probe.get("verified"):
        return {**doc_probe, "label": label, "reason": f"Could not read OpenAPI at {safe_url_for_display(openapi_url)}: {doc_probe.get('reason', '')}"}
    try:
        async with httpx.AsyncClient(timeout=4.0, follow_redirects=False) as client:
            response = await client.get(openapi_url)
            response.raise_for_status()
            path_methods = response.json().get("paths", {}).get(route_path, {})
        verified = isinstance(path_methods, dict) and method.lower() in path_methods
        return {
            "url": safe_url_for_display(openapi_url),
            "verified": verified,
            "status_code": 200,
            "label": label,
            "reason": f"{route_path} is declared as {method.upper()} in OpenAPI." if verified else f"{route_path} is not declared as {method.upper()} in OpenAPI.",
        }
    except Exception as exc:
        return {"url": safe_url_for_display(openapi_url), "verified": False, "status_code": None, "label": label, "reason": f"Could not inspect OpenAPI ({type(exc).__name__})."}


@app.post("/api/probe-configured")
async def probe_configured(session_id: str = "default") -> dict[str, Any]:
    state = session_state(session_id)
    bp = state["blueprint"]
    integration_secret = _secret_value(state, str(bp.get("integration_header_name") or INTEGRATION_HEADER), str(bp.get("integration_health_endpoint") or bp.get("integration_poll_endpoint") or ""))
    action_secret = _secret_value(state, str(bp.get("action_header_name") or ACTION_HEADER), str(bp.get("action_verify_url") or bp.get("action_api_url") or ""))
    integration_headers = {str(bp.get("integration_header_name") or INTEGRATION_HEADER): integration_secret} if integration_secret else {}
    action_headers = {str(bp.get("action_header_name") or ACTION_HEADER): action_secret} if action_secret else {}

    checks_plan = [
        (str(bp.get("integration_health_endpoint") or ""), integration_headers, "integration health"),
        (str(bp.get("integration_poll_endpoint") or ""), integration_headers, "pending queue"),
        (str(bp.get("action_health_url") or ""), {}, "action API health"),
        (str(bp.get("action_verify_url") or ""), action_headers, "action API authentication"),
        (str(bp.get("websocket_url") or ""), {}, "WebSocket"),
    ]

    async def check_one(url: str, headers: dict[str, str], label: str) -> dict[str, Any]:
        if not url:
            return {"url": "", "verified": False, "status_code": None, "label": label, "reason": "This endpoint has not been supplied during discovery yet."}
        probe_url = url
        if label == "pending queue":
            probe_url += ("&" if "?" in probe_url else "?") + "limit=1"
        result = await probe_endpoint(probe_url, headers=headers)
        result["label"] = label
        return result

    endpoint_checks = await asyncio.gather(*(check_one(url, headers, label) for url, headers, label in checks_plan))
    app_base = str(bp.get("app_base_url") or "").rstrip("/")
    action_url = urlparse(str(bp.get("action_api_url") or ""))
    action_base = f"{action_url.scheme}://{action_url.netloc}" if action_url.scheme and action_url.netloc else ""
    result_endpoint = await _verify_openapi_route(app_base, "/api/integration/requests/{request_id}/workflow-result", "post", "result endpoint declared") if app_base else {
        "url": "", "verified": False, "status_code": None, "label": "result endpoint declared", "reason": "Application base URL has not been discovered yet."
    }
    action_endpoint = await _verify_openapi_route(action_base, action_url.path.rstrip("/"), "post", "action endpoint declared") if action_base and action_url.path else {
        "url": "", "verified": False, "status_code": None, "label": "action endpoint declared", "reason": "Action API URL has not been discovered yet."
    }
    checks = endpoint_checks + [result_endpoint, action_endpoint]
    for result in checks:
        if result.get("url"):
            state["probes"][f"{result.get('label', 'endpoint')}|{result['url']}"] = result
    required_labels = {"integration health", "pending queue", "action API health", "action API authentication", "WebSocket", "result endpoint declared", "action endpoint declared"}
    verified_labels = {r.get("label") for r in checks if r.get("verified")}
    all_verified = required_labels.issubset(verified_labels)
    state["verified_probe_signature"] = _probe_signature(state) if all_verified else None
    return {"checks": checks, "all_verified": all_verified, "missing_or_failed": [r.get("label") for r in checks if not r.get("verified")]}


def _secret_header_for_url(state: dict[str, Any], url: str, detected_name: str = "", detected_value: str = "") -> tuple[str, str]:
    lower = url.lower()
    if detected_name and detected_value:
        name = detected_name
        if name.lower() in {"token", "key", "secret", "api key", "api-key"}:
            name = ACTION_HEADER if "/api/v1/" in lower else INTEGRATION_HEADER if "/api/integration/" in lower else "Authorization"
        return name, detected_value
    if "/api/integration/" in lower:
        return INTEGRATION_HEADER, _secret_value(state, INTEGRATION_HEADER, url)
    if "/api/v1/" in lower or lower.endswith("/health"):
        return ACTION_HEADER, _secret_value(state, ACTION_HEADER, url)
    return "", ""


@app.post("/api/chat")
async def chat(body: ChatBody) -> dict[str, Any]:
    state = session_state(body.session_id)
    message = body.message
    safe_message = redact_secrets(message)
    state["chat"].append({"role": "user", "message": safe_message})

    provided_path = _extract_project_path(message)
    if provided_path:
        state["blueprint"]["rainbow_stack_dir"] = provided_path
        state["verified_probe_signature"] = None

    candidate_urls = extract_urls(message)
    last_target = state.get("last_probe_target") or {}
    last_url = str(last_target.get("url") or "")
    if candidate_urls:
        default_remembered = _label_header(candidate_urls[0]) or str(last_target.get("header_name") or INTEGRATION_HEADER)
    else:
        default_remembered = str(last_target.get("header_name") or INTEGRATION_HEADER)
    detected_name, detected_value = extract_auth(message, default_remembered)
    if detected_name and detected_value:
        url_hint = candidate_urls[0] if candidate_urls else last_url
        detected_name, _ = _secret_header_for_url(state, url_hint, detected_name, detected_value)
        state["secrets"][detected_name.lower()] = {"name": detected_name, "value": detected_value, "origin": _origin_key(url_hint) if url_hint else None}
        state["verified_probe_signature"] = None

    urls = extract_urls(message)
    # A corrected token without a repeated URL retries the last failed endpoint.
    if not urls and detected_name and detected_value and state.get("last_probe_target"):
        retry_url = str(state["last_probe_target"].get("url") or "")
        if retry_url:
            urls = [retry_url]

    probe_results: list[dict[str, Any]] = []
    last_result: dict[str, Any] | None = None
    for url in urls:
        parsed = urlparse(url)
        is_action_post_route = parsed.path.rstrip("/").lower().endswith("/api/v1/refunds")
        credential_origin = _origin_key((extract_urls(message) or [str((state.get("last_probe_target") or {}).get("url") or "")])[0])
        explicit_name, explicit_value = (detected_name, detected_value) if detected_value and _origin_key(url) == credential_origin else ("", "")
        header_name, header_value = _secret_header_for_url(state, url, explicit_name, explicit_value)
        headers = {header_name: header_value} if header_name and header_value else _headers_for_url(state, url)
        if is_action_post_route:
            # Never GET/POST the action route as a health probe. Verify the POST
            # declaration through OpenAPI, then verify its token on the read-only
            # transactions endpoint below.
            result = await _verify_openapi_route(
                f"{parsed.scheme}://{parsed.netloc}", parsed.path.rstrip("/"), "post", "action endpoint declared"
            )
        else:
            result = await probe_endpoint(url, headers=headers)
        result["label"] = _label_url(url) if not is_action_post_route else "action endpoint declared"
        result["url"] = safe_url_for_display(url)
        probe_results.append(result)
        last_result = result
        state["probes"][f"{result['label']}|{result['url']}"] = result
        state["last_probe_target"] = {"url": url, "header_name": header_name or _label_header(url), "method": "GET"}
        _normalize_blueprint_url(state, url, bool(result.get("verified")))
        # The refund route itself must never be POSTed just to test a key. If a
        # key was supplied, verify it immediately against the safe read-only
        # transactions endpoint while OpenAPI confirms the POST route exists.
        if is_action_post_route:
            token_name = header_name or ACTION_HEADER
            token_value = header_value or _secret_value(state, token_name, url)
            if token_value:
                verify_url = str(state["blueprint"].get("action_verify_url") or "")
                auth_result = await probe_endpoint(verify_url, headers={token_name: token_value}) if verify_url and _origin_key(verify_url) == _origin_key(url) else {
                    "url": "", "verified": False, "status_code": None, "reason": "Could not derive the read-only action API verification endpoint."
                }
                auth_result["label"] = "action API authentication"
                probe_results.append(auth_result)
                last_result = auth_result
                if auth_result.get("url"):
                    state["probes"][f"action API authentication|{auth_result['url']}"] = auth_result
                state["last_probe_target"] = {"url": verify_url or url, "header_name": token_name, "method": "GET"}

    if urls:
        state["verified_probe_signature"] = None

    failed_probe = next((item for item in probe_results if not item.get("verified")), None)
    if failed_probe:
        code = failed_probe.get("status_code")
        if code in {401, 403}:
            reply = f"I probed the endpoint immediately. It returned HTTP {code}; authentication failed. The token was kept locally and not sent to OpenAI. Send the corrected header value and I will retry this endpoint."
        elif code == 404:
            reply = "I probed the endpoint immediately. It returned HTTP 404, so the path is not verified. Please correct the endpoint URL."
        elif code in {405, 422}:
            reply = "The endpoint responded, but the chosen probe method did not verify the contract. No state-changing action was sent. Provide a documented read-only verification endpoint if needed."
        else:
            reply = "I probed the endpoint immediately, but it is not verified yet. See the probe result for the HTTP status or connection failure."
        state["chat"].append({"role": "assistant", "message": reply})
        return {"reply": reply, "probe_results": probe_results, "blueprint": state["blueprint"], "can_build": False, "display_message": safe_message}

    latest_probe = failed_probe or last_result
    try:
        response = await conversational_reply(message, state["blueprint"], latest_probe, state["chat"][:-1])
        merged = {**state["blueprint"], **response.get("spec_patch", {})}
        try:
            raw_threshold = merged.get("refund_threshold", 5000)
            if isinstance(raw_threshold, str):
                match = re.search(r"(\d+(?:\.\d+)?)", raw_threshold)
                raw_threshold = match.group(1) if match else "5000"
            merged["refund_threshold"] = float(raw_threshold)
            if not (0 < merged["refund_threshold"] <= 10_000_000):
                raise ValueError
            if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_.-]{0,119}", str(merged.get("process_id", ""))):
                raise ValueError
            raw_rules = merged.get("business_rules", [])
            if isinstance(raw_rules, str):
                raw_rules = [raw_rules]
            elif isinstance(raw_rules, list):
                raw_rules = [str(r) if not isinstance(r, str) else r for r in raw_rules]
            else:
                raw_rules = []
            merged["business_rules"] = raw_rules
            if merged.get("rainbow_stack_dir"):
                merged["rainbow_stack_dir"] = str(merged["rainbow_stack_dir"]).strip().strip('"')
            state["blueprint"] = merged
            reply = response.get("reply", "Understood.")
        except (TypeError, ValueError):
            reply = "One proposed blueprint value failed validation. Please check the process ID, threshold, and business rules."
    except Exception as exc:
        reply = "Endpoint probing completed. " + ("Set OPENAI_API_KEY in ProcessOS/.env to enable conversational discovery and the Coder/Tester agents." if "OPENAI_API_KEY" in str(exc) else f"Conversational agent unavailable ({type(exc).__name__}).")
    state["chat"].append({"role": "assistant", "message": reply})
    return {"reply": reply, "probe_results": probe_results, "blueprint": state["blueprint"], "can_build": False, "display_message": safe_message}


@app.post("/api/build")
async def build(body: BuildBody) -> dict[str, Any]:
    state = session_state(body.session_id)
    if body.blueprint:
        allowed = set(initial_blueprint().keys())
        patch = {k: v for k, v in body.blueprint.items() if k in allowed}
        merged = {**state["blueprint"], **patch}
        if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_.-]{0,119}", str(merged.get("process_id", "")).strip()):
            raise HTTPException(400, "Blueprint process_id is not a valid BPMN identifier.")
        try:
            merged["refund_threshold"] = float(merged.get("refund_threshold", 5000))
            if not (0 < merged["refund_threshold"] <= 10_000_000):
                raise ValueError
        except (TypeError, ValueError):
            raise HTTPException(400, "Blueprint refund_threshold must be a positive number no greater than 10000000.")
        if not isinstance(merged.get("business_rules"), list) or any(not isinstance(rule, str) for rule in merged["business_rules"]):
            raise HTTPException(400, "Blueprint business_rules must be a list of strings.")
        state["blueprint"] = merged

    if not env("OPENAI_API_KEY"):
        raise HTTPException(400, "OPENAI_API_KEY is missing. Add it to ProcessOS/.env and restart.")
    if state.get("verified_probe_signature") != _probe_signature(state):
        raise HTTPException(409, "Build blocked: verify all configured endpoints successfully again after the last blueprint or credential change.")
    checks = list(state["probes"].values())
    required_labels = {"integration health", "pending queue", "action API health", "action API authentication", "WebSocket", "result endpoint declared", "action endpoint declared"}
    verified_labels = {r.get("label") for r in checks if r.get("verified")}
    if not required_labels.issubset(verified_labels):
        raise HTTPException(409, "Build blocked: click Probe configured endpoints and resolve every failed or missing check first.")
    spec = state["blueprint"]
    stack_path = str(spec.get("rainbow_stack_dir", "")).strip().strip('"')
    if not stack_path:
        raise HTTPException(409, "This deployment adapter requires the local folder for its compatible refund-flow bridge. Provide the folder path only if this is the integration target you selected; the folder must contain local_bridge/bridge.py.")
    stack = Path(stack_path).expanduser().resolve()
    if not (stack / "local_bridge" / "bridge.py").is_file():
        raise HTTPException(409, "The supplied project path does not contain local_bridge/bridge.py, which this deployment adapter requires. Choose a compatible target or stop deployment; ProcessOS will not modify your original project.")
    spec["rainbow_stack_dir"] = str(stack)

    # All generated artifacts stay inside ProcessOS. Only non-secret configuration is persisted.
    out_dir = BASE_DIR / "generated_workflow"
    out_dir.mkdir(exist_ok=True)
    (out_dir / "blueprint.json").write_text(json.dumps(spec, indent=2, ensure_ascii=False), encoding="utf-8")
    try:
        result = await coder_tester_loop(spec, out_dir)
    except Exception as exc:
        raise HTTPException(502, f"Coder/Tester agent failed: {type(exc).__name__}: {exc}") from exc
    state["last_build"] = result
    state["verified_probe_signature"] = _probe_signature(state) if result.get("passed") else None
    return result


def _runtime_environment(state: dict[str, Any]) -> dict[str, str]:
    """Pass short-lived conversation secrets to a single child process only."""
    context = {
        "blueprint": state["blueprint"],
        "secrets": {
            name: {"name": item.get("name", name), "value": item.get("value", ""), "origin": item.get("origin")}
            for name, item in state["secrets"].items()
        },
    }
    return {"PROCESSOS_RUNTIME_CONTEXT_JSON": json.dumps(context, ensure_ascii=False)}


def _run_runtime_cli(state: dict[str, Any], args: list[str], timeout: int) -> dict[str, Any]:
    child_env = os.environ.copy()
    child_env.update(_runtime_environment(state))
    runtime_script = BASE_DIR / "processos_runtime.py"
    try:
        proc = subprocess.run([sys.executable, str(runtime_script), *args], cwd=BASE_DIR, env=child_env, capture_output=True, text=True, timeout=timeout)
        return {"exit_code": proc.returncode, "passed": proc.returncode == 0, "stdout": proc.stdout, "stderr": proc.stderr}
    except subprocess.TimeoutExpired as exc:
        return {
            "exit_code": 124,
            "passed": False,
            "stdout": exc.stdout or "",
            "stderr": f"Timed out after {timeout} seconds. Check Camunda and bridge status before retrying.",
        }


@app.post("/api/cli/self-test")
def cli_self_test(session_id: str = "default") -> dict[str, Any]:
    # Offline-only validation; never starts Camunda, probes endpoints, or uses secrets.
    workflow_dir = BASE_DIR / "generated_workflow"
    script = workflow_dir / "cli_orchestrator.py"
    if not script.exists():
        raise HTTPException(404, "CLI entrypoint has not been generated. Pass Build & Verify first.")
    proc = subprocess.run([sys.executable, str(script), "--self-test"], cwd=BASE_DIR, capture_output=True, text=True, timeout=25)
    return {"exit_code": proc.returncode, "passed": proc.returncode == 0, "stdout": proc.stdout, "stderr": proc.stderr}


@app.post("/api/cli/run")
def cli_run(body: RunBody) -> dict[str, Any]:
    state = session_state(body.session_id)
    if not (state.get("last_build") or {}).get("passed"):
        raise HTTPException(409, "Execution blocked: the latest Coder/Tester gate did not pass.")
    if not body.confirmed:
        raise HTTPException(400, "Explicit confirmation is required before deployment and bridge startup.")
    if state.get("verified_probe_signature") != _probe_signature(state):
        raise HTTPException(409, "Execution blocked: endpoint or credential verification is stale. Run Probe configured endpoints again.")
    # Runtime calls c8ctl to install/start local Camunda if needed, then deploys
    # via the existing bridge's REST client and launches the original bridge.
    return _run_runtime_cli(state, ["--direct-run", "--workflow-dir", str(BASE_DIR / "generated_workflow")], timeout=1200)


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="127.0.0.1", port=8090, reload=False)
