const messagesEl = document.getElementById('messages');
const interactionEl = document.getElementById('interaction-area');
const connectionBadge = document.getElementById('connection-badge');
const connectionLabel = document.getElementById('connection-label');
const todayLabel = document.getElementById('today-label');

const state = { flow: null, step: 0, values: {}, busy: false, products: [], activeRequests: {}, requestSnapshots: {}, statusSocket: null };
const today = new Intl.DateTimeFormat(undefined, { weekday: 'short', month: 'short', day: 'numeric' }).format(new Date());
todayLabel.textContent = today.toUpperCase();

function escapeHTML(value) {
  return String(value ?? '').replace(/[&<>"']/g, (char) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[char]));
}

function scrollMessages() {
  messagesEl.scrollTop = messagesEl.scrollHeight;
}

function addMessage(text, sender = 'bot', options = {}) {
  const row = document.createElement('div');
  row.className = `message-row ${sender}`;
  if (sender === 'bot') {
    const avatar = document.createElement('div');
    avatar.className = 'mini-avatar';
    avatar.setAttribute('aria-hidden', 'true');
    avatar.textContent = 'R';
    row.appendChild(avatar);
  }
  const bubble = document.createElement('div');
  bubble.className = `bubble ${sender}`;
  if (options.html) bubble.innerHTML = text;
  else bubble.textContent = text;
  row.appendChild(bubble);
  messagesEl.appendChild(row);
  scrollMessages();
  return bubble;
}

function clearInteraction() {
  interactionEl.innerHTML = '';
}

function addQuickActions(actions) {
  clearInteraction();
  const container = document.createElement('div');
  container.className = 'quick-actions';
  actions.forEach((action) => {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'quick-button';
    button.innerHTML = `<span class="quick-icon" aria-hidden="true">${action.icon}</span><span class="quick-copy">${escapeHTML(action.title)}<small>${escapeHTML(action.subtitle)}</small></span>`;
    button.addEventListener('click', () => action.run());
    container.appendChild(button);
  });
  interactionEl.appendChild(container);
}

function addForm({ title, subtitle, fields, submitText = 'Continue', onSubmit, onCancel = showMainMenu }) {
  clearInteraction();
  const form = document.createElement('form');
  form.className = 'form-card';
  form.noValidate = true;
  form.innerHTML = `<div class="form-title">${escapeHTML(title)}</div><div class="form-subtitle">${escapeHTML(subtitle || '')}</div>`;

  for (const field of fields) {
    const id = `field-${field.name}-${Math.random().toString(36).slice(2, 8)}`;
    const label = document.createElement('label');
    label.className = 'field-label';
    label.htmlFor = id;
    label.textContent = field.label;
    form.appendChild(label);
    let input;
    if (field.type === 'textarea') {
      input = document.createElement('textarea');
      input.rows = field.rows || 3;
      input.className = 'text-area';
    } else if (field.type === 'select') {
      input = document.createElement('select');
      input.className = 'text-input select-input';
      const placeholder = document.createElement('option');
      placeholder.value = '';
      placeholder.textContent = field.placeholder || 'Choose an option';
      input.appendChild(placeholder);
      (field.options || []).forEach((option) => {
        const element = document.createElement('option');
        element.value = option.value;
        element.textContent = option.label;
        input.appendChild(element);
      });
    } else {
      input = document.createElement('input');
      input.type = field.type || 'text';
      input.className = 'text-input';
      if (field.type === 'number') {
        input.min = '0.01';
        input.step = '0.01';
      }
      if (field.type === 'email') input.autocomplete = 'email';
    }
    input.id = id;
    input.name = field.name;
    input.placeholder = field.placeholder || '';
    input.required = field.required !== false;
    if (field.maxLength) input.maxLength = field.maxLength;
    if (field.type === 'number') input.inputMode = 'decimal';
    form.appendChild(input);
  }

  const error = document.createElement('div');
  error.className = 'error-text';
  error.setAttribute('role', 'alert');
  form.appendChild(error);

  const buttons = document.createElement('div');
  buttons.className = 'form-actions';
  buttons.innerHTML = `<button class="primary-button" type="submit">${escapeHTML(submitText)} <span class="button-arrow" aria-hidden="true">→</span></button><button class="secondary-button" type="button">Back</button>`;
  buttons.querySelector('.secondary-button').addEventListener('click', () => {
    clearInteraction();
    onCancel();
  });
  form.appendChild(buttons);
  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    error.classList.remove('visible');
    const values = {};
    let invalid = false;
    for (const field of fields) {
      const input = form.elements[field.name];
      const value = String(input.value || '').trim();
      if (field.required !== false && !value) {
        error.textContent = `Please enter ${field.label.toLowerCase()}.`;
        error.classList.add('visible'); input.focus(); invalid = true; break;
      }
      if (field.type === 'email' && value && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
        error.textContent = 'Please enter a valid email address.';
        error.classList.add('visible'); input.focus(); invalid = true; break;
      }
      if (field.type === 'number' && value && (!Number.isFinite(Number(value)) || Number(value) <= 0)) {
        error.textContent = 'Please enter an amount greater than zero.';
        error.classList.add('visible'); input.focus(); invalid = true; break;
      }
      values[field.name] = value;
    }
    if (invalid) return;
    await onSubmit(values, form, error);
  });
  interactionEl.appendChild(form);
  const firstInput = form.querySelector('input, textarea');
  if (firstInput) setTimeout(() => firstInput.focus(), 30);
}

async function apiRequest(url, options = {}) {
  let response;
  try {
    response = await fetch(url, {
      ...options,
      headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
    });
  } catch (error) {
    throw new Error('Could not reach the local server. Check that Rainbow Corp Refund Assistant is running.');
  }
  const body = await response.json().catch(() => ({}));
  if (!response.ok) {
    let detail = body.detail;
    if (Array.isArray(detail)) detail = detail.map((item) => item.msg).join(' ');
    throw new Error(detail || `Request failed (HTTP ${response.status}).`);
  }
  return body;
}

async function checkHealth() {
  try {
    const health = await apiRequest('/api/health', { method: 'GET', headers: {} });
    if (health.storage_mode === 'local_sqlite') {
      connectionBadge.className = 'connection-badge connected';
      connectionLabel.textContent = 'Local DB · API ready';
      connectionBadge.title = 'Rainbow Corp local database and generic integration API are available. A separate workflow bridge is required; this chatbot does not initiate refunds.';
    } else {
      connectionBadge.className = 'connection-badge offline';
      connectionLabel.textContent = 'Database unavailable';
      connectionBadge.title = 'The local database is unavailable';
    }
  } catch (_) {
    connectionBadge.className = 'connection-badge offline';
    connectionLabel.textContent = 'Server unavailable';
    connectionBadge.title = 'Start the local FastAPI server';
  }
}

function formatAmount(amount) {
  return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 2 }).format(Number(amount));
}

function showMainMenu(withGreeting = false) {
  state.flow = null;
  state.step = 0;
  state.values = {};
  if (withGreeting) {
    addMessage('Welcome to Rainbow Corp support. What would you like to do today?');
  }
  addQuickActions([
    { icon: '＋', title: 'Submit a refund request', subtitle: 'Create a new support request', run: startNewRequest },
    { icon: '↻', title: 'Check an existing request', subtitle: 'View the latest request status', run: startLookup },
    { icon: '✎', title: 'Add information to a request', subtitle: 'Send additional details to support', run: startAddInformation },
  ]);
}

async function startNewRequest() {
  clearInteraction();
  state.flow = 'new';
  state.values = {};
  addMessage('Submit a refund request');
  addMessage('Choose one of Rainbow Corp’s five standard products. The refund amount is taken from the product catalogue and cannot be edited in the chat. Products over ₹5,000 need human approval. This is a local demo and never moves real money.');
  try {
    const result = await apiRequest('/api/products', { method: 'GET', headers: {} });
    state.products = result.products || [];
    if (state.products.length !== 5) {
      addMessage('The standard product catalogue is not ready. Open the Data Console or restart the local application.');
      finishWithMenu();
      return;
    }
    askForNewRequestStep(0);
  } catch (error) {
    addMessage(`I couldn’t load the product catalogue: ${error.message}`);
    finishWithMenu();
  }
}

function getNewRequestFields() {
  const productOptions = state.products.map((product) => ({
    value: product.product_id,
    label: `${product.product_name} — ${formatAmount(product.standard_cost_inr)} · ${product.standard_cost_inr > 5000 ? 'Human approval' : 'Auto refund demo'}`,
  }));
  return [
    { name: 'customer_name', label: 'Your full name', type: 'text', placeholder: 'e.g. Priya Sharma', maxLength: 120 },
    { name: 'customer_email', label: 'Email address', type: 'email', placeholder: 'you@example.com', maxLength: 254 },
    { name: 'order_id', label: 'Order ID', type: 'text', placeholder: 'e.g. ORD-10482', maxLength: 100 },
    { name: 'product_id', label: 'Choose a product', type: 'select', placeholder: 'Select one of five products', options: productOptions },
    { name: 'reason', label: 'Reason for the refund', type: 'textarea', placeholder: 'Briefly explain what happened.', maxLength: 2000 },
  ];
}

function askForNewRequestStep(index) {
  const newRequestFields = getNewRequestFields();
  state.step = index;
  if (index >= newRequestFields.length) return showNewRequestConfirmation();
  const field = newRequestFields[index];
  const stepPrompts = [
    'First, what name should we use for this request?',
    'What email address is associated with this request?',
    'What is your order ID?',
    'Which standard product is this request about? The catalogue determines the fixed refund amount.',
    'What is the reason for the refund?',
  ];
  addMessage(stepPrompts[index]);
  addForm({
    title: `Step ${index + 1} of ${newRequestFields.length}`,
    subtitle: field.name === 'product_id' ? 'Choose the product for this request. The separate workflow will evaluate the amount and decide the next step.' : 'Your information will be used to register and track this request.',
    fields: [field],
    submitText: index === newRequestFields.length - 1 ? 'Review request' : 'Continue',
    onSubmit: async (values) => {
      if (field.name === 'product_id') {
        const selected = state.products.find((product) => product.product_id === values.product_id);
        if (!selected) return;
        state.values.product_id = selected.product_id;
        state.values.product = selected.product_name;
        state.values.refund_amount = Number(selected.standard_cost_inr);
        addMessage(`${selected.product_name} · ${formatAmount(selected.standard_cost_inr)}`, 'user');
      } else {
        state.values[field.name] = values[field.name];
        addMessage(values[field.name], 'user');
      }
      clearInteraction();
      askForNewRequestStep(index + 1);
    },
    onCancel: () => showMainMenu(true),
  });
}

function showNewRequestConfirmation() {
  const v = state.values;
  addMessage('Please check the details before I submit your request.');
  const safe = (x) => escapeHTML(x);
  const html = `
    <span class="result-label">Request summary</span>
    <ul class="detail-list">
      <li><span>Name</span><span>${safe(v.customer_name)}</span></li>
      <li><span>Email</span><span>${safe(v.customer_email)}</span></li>
      <li><span>Order ID</span><span>${safe(v.order_id)}</span></li>
      <li><span>Product</span><span>${safe(v.product)}</span></li>
      <li><span>Standard cost</span><span>${safe(formatAmount(v.refund_amount))}</span></li>
      <li><span>Processing</span><span>Workflow assessment after submission</span></li>
      <li><span>Reason</span><span>${safe(v.reason)}</span></li>
    </ul>`;
  addMessage(html, 'bot', { html: true });
  clearInteraction();
  const container = document.createElement('div');
  container.className = 'quick-actions';
  const confirm = document.createElement('button');
  confirm.className = 'primary-button';
  confirm.type = 'button';
  confirm.innerHTML = 'Confirm and submit <span class="button-arrow" aria-hidden="true">→</span>';
  const edit = document.createElement('button');
  edit.className = 'secondary-button';
  edit.type = 'button';
  edit.textContent = 'Start again';
  confirm.addEventListener('click', submitNewRequest);
  edit.addEventListener('click', () => startNewRequest());
  container.append(confirm, edit);
  interactionEl.appendChild(container);
}

async function submitNewRequest() {
  clearInteraction();
  addMessage('Confirm and submit', 'user');
  const typing = addMessage('<span class="typing"><span></span><span></span><span></span></span>', 'bot', { html: true });
  try {
    const result = await apiRequest('/api/requests', { method: 'POST', body: JSON.stringify(state.values) });
    typing.closest('.message-row').remove();
    const request = result.request;
    if (result.duplicate) {
      addMessage(`A refund request already exists for this order ID, registered email, and amount. <strong>No duplicate was created.</strong> Existing reference: <span class="request-ref">${escapeHTML(request.request_id)}</span>.`, 'bot', { html: true });
      addRequestStatus(request);
      finishWithMenu();
      checkHealth();
      return;
    }
    addMessage(`Your refund request has been saved. You can check its status using order ID <strong>${escapeHTML(request.order_id)}</strong> and your registered email.`, 'bot', { html: true });
    addRequestStatus(request);
    addMessage('The request is queued for the separate workflow service. This chatbot only records the request; routing, human approval and the mock refund API are handled outside this application.');
    addMessage('You can follow status changes in the local Data Console. Demo data only; no real money moves.');
    finishWithMenu();
    checkHealth();
  } catch (error) {
    typing.closest('.message-row').remove();
    addMessage(`I couldn’t submit the request: ${error.message}`);
    addQuickActions([
      { icon: '↻', title: 'Try submission again', subtitle: 'Retry using the same details', run: submitNewRequest },
      { icon: '⌂', title: 'Main menu', subtitle: 'Choose another action', run: () => showMainMenu(true) },
    ]);
  }
}

function startLookup() {
  state.flow = 'lookup';
  addMessage('Check an existing request');
  addMessage('Enter your order ID and the email address registered with the request. You do not need a separate refund request ID.');
  addForm({
    title: 'Find your refund request',
    subtitle: 'Use the order ID from your purchase and the email registered with the refund request.',
    fields: [
      { name: 'order_id', label: 'Order ID', placeholder: 'e.g. 12345 or ORD-1001', maxLength: 100 },
      { name: 'customer_email', label: 'Registered email address', type: 'email', placeholder: 'you@example.com', maxLength: 254 },
    ],
    submitText: 'Check status',
    onSubmit: async (values, form) => {
      addMessage(`${values.order_id} · ${values.customer_email}`, 'user');
      clearInteraction();
      const typing = addMessage('<span class="typing"><span></span><span></span><span></span></span>', 'bot', { html: true });
      try {
        const result = await apiRequest('/api/requests/lookup', {
          method: 'POST',
          body: JSON.stringify({ order_id: values.order_id, customer_email: values.customer_email }),
        });
        typing.closest('.message-row').remove();
        if (result.count === 1) {
          addMessage(`Found the refund request for order <strong>${escapeHTML(values.order_id)}</strong>.`, 'bot', { html: true });
        } else {
          addMessage(`Found ${result.count} refund requests for order <strong>${escapeHTML(values.order_id)}</strong>. Here are their latest statuses.`, 'bot', { html: true });
        }
        result.requests.forEach((request) => addRequestStatus(request));
        addMessage('These statuses were retrieved from Rainbow Corp’s local application database.');
        finishWithMenu();
      } catch (error) {
        typing.closest('.message-row').remove();
        addMessage(error.message);
        addQuickActions([
          { icon: '↻', title: 'Try again', subtitle: 'Check order ID and registered email', run: startLookup },
          { icon: '⌂', title: 'Main menu', subtitle: 'Choose another action', run: () => showMainMenu(true) },
        ]);
      }
    },
    onCancel: () => showMainMenu(true),
  });
}

function startAddInformation() {
  state.flow = 'information';
  addMessage('Add information to a request');
  addMessage('I’ll verify the request ID and registered email before attaching your update to an open request.');
  addForm({
    title: 'Add supporting information',
    subtitle: 'Your message will be timestamped and appended to the request record.',
    fields: [
      { name: 'request_id', label: 'Request ID', placeholder: 'e.g. RBC-1A2B3C4D5E', maxLength: 40 },
      { name: 'customer_email', label: 'Registered email address', type: 'email', placeholder: 'you@example.com', maxLength: 254 },
      { name: 'message', label: 'Additional information', type: 'textarea', placeholder: 'Enter the details you want to add.', maxLength: 2000 },
    ],
    submitText: 'Send information',
    onSubmit: async (values) => {
      addMessage(`Update for ${values.request_id}: ${values.message}`, 'user');
      clearInteraction();
      const typing = addMessage('<span class="typing"><span></span><span></span><span></span></span>', 'bot', { html: true });
      try {
        const result = await apiRequest(`/api/requests/${encodeURIComponent(values.request_id)}/information`, { method: 'POST', body: JSON.stringify({ customer_email: values.customer_email, message: values.message }) });
        typing.closest('.message-row').remove();
        addMessage(`Your information has been added to request <strong>${escapeHTML(result.request.request_id)}</strong>.`, 'bot', { html: true });
        addRequestStatus(result.request);
        addMessage('The local database record has been updated. The Data Console shows this change in the activity log.');
        finishWithMenu();
      } catch (error) {
        typing.closest('.message-row').remove();
        addMessage(`I couldn’t update the request: ${error.message}`);
        addQuickActions([
          { icon: '↻', title: 'Try again', subtitle: 'Check the details and retry', run: startAddInformation },
          { icon: '⌂', title: 'Main menu', subtitle: 'Choose another action', run: () => showMainMenu(true) },
        ]);
      }
    },
    onCancel: () => showMainMenu(true),
  });
}

function addRequestStatus(request) {
  if (request && request.request_id) {
    state.activeRequests[request.request_id] = {
      order_id: request.order_id,
      customer_email: request.customer_email,
    };
    state.requestSnapshots[request.request_id] = `${request.status}|${request.updated_at}|${request.refund_transaction_id || ''}|${request.status_notes || ''}`;
  }
  const safe = escapeHTML;
  const html = `
    <span class="result-label">Request details</span>
    <div><span class="status-chip">${safe(request.status || 'Submitted')}</span></div>
    ${request.status_notes ? `<p>${safe(request.status_notes)}</p>` : ''}
    <ul class="detail-list">
      <li><span>Request ID</span><span>${safe(request.request_id)}</span></li>
      <li><span>Order ID</span><span>${safe(request.order_id)}</span></li>
      <li><span>Requested amount</span><span>${safe(formatAmount(request.refund_amount))}</span></li>
      ${request.refund_transaction_id ? `<li><span>Demo transaction</span><span>${safe(request.refund_transaction_id)}</span></li>` : ''}
      <li><span>Last updated</span><span>${safe(formatDate(request.updated_at))}</span></li>
      ${request.latest_customer_update ? `<li><span>Your latest update</span><span>${safe(request.latest_customer_update)}</span></li>` : ''}
    </ul>`;
  addMessage(html, 'bot', { html: true });
}

function formatDate(value) {
  if (!value) return 'Not available';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return new Intl.DateTimeFormat(undefined, { dateStyle: 'medium', timeStyle: 'short' }).format(date);
}

function finishWithMenu() {
  addQuickActions([
    { icon: '⌂', title: 'Back to main menu', subtitle: 'Start another action', run: () => showMainMenu(true) },
    { icon: '↻', title: 'Check another request', subtitle: 'Look up the latest status', run: startLookup },
  ]);
}

async function refreshTrackedRequest(requestId) {
  const identity = state.activeRequests[requestId];
  if (!identity) return;
  try {
    const result = await apiRequest(`/api/requests/${encodeURIComponent(requestId)}/lookup`, {
      method: 'POST',
      body: JSON.stringify({ customer_email: identity.customer_email }),
    });
    const request = result.request;
    const nextSnapshot = `${request.status}|${request.updated_at}|${request.refund_transaction_id || ''}|${request.status_notes || ''}`;
    const previous = state.requestSnapshots[requestId];
    if (previous && previous !== nextSnapshot) {
      addMessage(`Live update for order <strong>${escapeHTML(request.order_id)}</strong>: <strong>${escapeHTML(request.status)}</strong>.`, 'bot', { html: true });
      addRequestStatus(request);
    }
  } catch (_) {
    // A record may have been wiped or is no longer accessible; do not interrupt the chat.
  }
}

function connectStatusUpdates() {
  const scheme = window.location.protocol === 'https:' ? 'wss' : 'ws';
  const socket = new WebSocket(`${scheme}://${window.location.host}/ws/updates`);
  state.statusSocket = socket;
  socket.addEventListener('message', (event) => {
    try {
      const payload = JSON.parse(event.data);
      if (payload.type === 'data_changed' && payload.entity === 'refund_requests' && state.activeRequests[payload.entity_id]) {
        refreshTrackedRequest(payload.entity_id);
      }
    } catch (_) { /* ignore malformed event */ }
  });
  socket.addEventListener('close', () => setTimeout(connectStatusUpdates, 2500));
  socket.addEventListener('error', () => socket.close());
}

addMessage('Welcome to Rainbow Corp support. I can register a refund request, look up its latest status, or add information to an existing request.');
showMainMenu();
connectStatusUpdates();
checkHealth();
