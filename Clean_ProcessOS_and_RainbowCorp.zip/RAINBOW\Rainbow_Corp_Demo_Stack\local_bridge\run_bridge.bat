@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (echo Install Python 3.11+ first.& pause & exit /b 1)
if not exist ".env" (
  copy ".env.example" ".env" >nul
  echo Created local_bridge\.env from .env.example.
  echo Edit it with the workflow cluster address and credentials, then run this file again.
  pause
  exit /b 1
)
if not exist ".venv\Scripts\python.exe" (py -3 -m venv .venv)
echo Installing separate local bridge requirements...
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 (pause & exit /b 1)
echo Starting separate workflow integration bridge...
".venv\Scripts\python.exe" bridge.py
if errorlevel 1 (echo Bridge exited. Check the error above.)
pause
