"""Generated ProcessOS CLI entrypoint; local execution is brokered by ProcessOS."""
from __future__ import annotations
import argparse
import json
import sys
from pathlib import Path
import urllib.error
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_SESSION = "processos-local-session"

def main() -> int:
    parser = argparse.ArgumentParser(description="Shubham Singh ProcessOS workflow CLI")
    parser.add_argument("--self-test", action="store_true", help="Offline BPMN and CLI validation only")
    parser.add_argument("--run", action="store_true", help="Request the active local ProcessOS session to deploy and start the workflow")
    parser.add_argument("--confirm", action="store_true", help="Explicitly authorize deployment and bridge startup")
    parser.add_argument("--session-id", default=DEFAULT_SESSION)
    args = parser.parse_args()
    if args.self_test:
        import subprocess
        return subprocess.call([sys.executable, str(ROOT / "processos_runtime.py"), "--self-test", "--workflow-dir", str(Path(__file__).resolve().parent)])
    if not args.run:
        parser.print_help()
        return 2
    if not args.confirm:
        print("Blocked: pass --confirm to authorize deployment and bridge startup.", file=sys.stderr)
        return 2
    payload = json.dumps({"session_id": args.session_id, "confirmed": True}).encode("utf-8")
    request = urllib.request.Request("http://127.0.0.1:8090/api/cli/run", data=payload, headers={"Content-Type": "application/json"}, method="POST")
    try:
        with urllib.request.urlopen(request, timeout=1200) as response:
            result = json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")
        print(f"ProcessOS rejected CLI run (HTTP {exc.code}): {detail}", file=sys.stderr)
        return 2
    except Exception as exc:
        print(f"Could not reach ProcessOS at 127.0.0.1:8090: {type(exc).__name__}. Start ProcessOS and keep the discovery session active.", file=sys.stderr)
        return 2
    print(result.get("stdout", ""), end="")
    if result.get("stderr"):
        print(result["stderr"], file=sys.stderr, end="")
    return int(result.get("exit_code", 1))

if __name__ == "__main__":
    raise SystemExit(main())
