const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => Array.from(document.querySelectorAll(selector));
const state = { requests: [], products: [], master: [], reviews: [], activity: [] };
const requestStatuses = ['Submitted', 'Pending Human Review', 'Human Approved - Ready for Processing', 'Rejected by Human', 'Under Review', 'Cancelled', 'Failed', 'Refund API Failed - Retry Required'];
let toastTimer;

function esc(value) {
  return String(value ?? '').replace(/[&<>"']/g, (ch) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));
}
function amount(value) {
  return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 2 }).format(Number(value || 0));
}
function date(value) {
  if (!value) return '—';
  const d = new Date(value);
  return Number.isNaN(d.getTime()) ? esc(value) : new Intl.DateTimeFormat(undefined, { dateStyle: 'medium', timeStyle: 'short' }).format(d);
}
function shortDate(value) {
  if (!value) return '—';
  const d = new Date(value);
  return Number.isNaN(d.getTime()) ? esc(value) : new Intl.DateTimeFormat(undefined, { dateStyle: 'medium' }).format(d);
}
function pillClass(status) {
  const s = String(status || '').toLowerCase();
  if (s.includes('approved') || s.includes('active') || s.includes('completed')) return 'good';
  if (s.includes('pending') || s.includes('review') || s.includes('submitted') || s.includes('verification')) return 'pending';
  if (s.includes('reject') || s.includes('failed') || s.includes('cancel')) return 'bad';
  return 'info';
}
function pill(status) { return `<span class="status-pill ${pillClass(status)}">${esc(status || 'Unknown')}</span>`; }
function toast(message, isError = false) {
  const element = $('#toast');
  element.textContent = message;
  element.className = `toast show${isError ? ' error' : ''}`;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { element.className = 'toast'; }, 3600);
}
async function api(path, options = {}) {
  let response;
  try {
    response = await fetch(path, { ...options, headers: { 'Content-Type': 'application/json', ...(options.headers || {}) } });
  } catch (_) {
    throw new Error('Cannot reach the local application. Check that the server is running.');
  }
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    let detail = data.detail;
    if (Array.isArray(detail)) detail = detail.map((e) => e.msg).join(' ');
    throw new Error(detail || `Request failed with HTTP ${response.status}.`);
  }
  return data;
}
function setMetric(id, value) { $(id).textContent = value; }

async function loadSummary() {
  const s = await api('/api/admin/summary');
  setMetric('#metric-requests', s.requests_total);
  setMetric('#metric-review', s.pending_review);
  setMetric('#metric-ready', s.ready_for_processing);
  setMetric('#metric-api-success', s.demo_refunds_succeeded || 0);
  setMetric('#metric-master', s.master_records);
  setMetric('#metric-value', amount(s.total_requested_inr));
}
async function loadRequests() {
  const params = new URLSearchParams();
  const q = $('#request-search').value.trim();
  const status = $('#request-status-filter').value;
  if (q) params.set('q', q);
  if (status) params.set('status', status);
  const result = await api(`/api/admin/requests?${params.toString()}`);
  state.requests = result.records;
  $('#count-requests').textContent = result.count;
  $('#requests-foot').textContent = `${result.count} request${result.count === 1 ? '' : 's'} shown (maximum 500).`;
  const body = $('#requests-body');
  if (!state.requests.length) {
    body.innerHTML = '<tr><td colspan="8" class="empty-cell">No refund requests yet. Submit one through the chatbot to see it here.</td></tr>';
    return;
  }
  body.innerHTML = state.requests.map((r) => {
    return `<tr>
      <td><div class="cell-primary">${esc(r.request_id)}</div><div class="cell-secondary">Created ${date(r.created_at)}</div>${r.refund_transaction_id ? `<div class="cell-secondary">Txn ${esc(r.refund_transaction_id)}</div>` : ''}</td>
      <td><div class="cell-primary">${esc(r.customer_name)}</div><div class="cell-secondary">${esc(r.customer_email)}</div></td>
      <td><div class="cell-primary">${esc(r.order_id)}</div><div class="cell-secondary">${esc(r.product)} · ${esc(r.product_id || '')}</div></td>
      <td class="amount">${amount(r.refund_amount)}</td>
      <td>${r.human_review_required ? pill('Human review required') : pill('Workflow decides route')}</td>
      <td>${pill(r.status)}<div class="cell-secondary">${esc(r.status_notes || '')}</div></td>
      <td>
        <div class="cell-primary">${esc(r.workflow_dispatch_status || 'Queued')}</div>
        <div class="cell-secondary">${esc(r.workflow_reference || 'No workflow reference yet')}</div>
        ${r.workflow_error ? `<div class="cell-secondary error-text">${esc(r.workflow_error)}</div>` : ''}
        ${!r.human_review_required && !r.refund_transaction_id && !['Completed','Refund Completed (Demo)','Rejected by Human'].includes(r.status) ? `<button class="save-small send-to-review-btn" data-id="${esc(r.request_id)}" type="button" style="margin-top:5px;background:#edf2ff;color:#2f5fd3;display:block;">Send to Human Review</button>` : ''}
        ${['Unknown','Dispatching','Failed'].includes(r.workflow_dispatch_status) && !r.workflow_reference ? `<button class="save-small requeue-start" data-id="${esc(r.request_id)}" type="button">Requeue after checking Camunda</button>` : ''}
      </td>
    </tr>`;
  }).join('');
}
async function loadProducts() {
  const result = await api('/api/admin/products');
  state.products = result.records;
  $('#count-products').textContent = result.count;
  $('#products-foot').textContent = `${result.count} standard products configured.`;
  const body = $('#products-body');
  if (!state.products.length) {
    body.innerHTML = '<tr><td colspan="6" class="empty-cell">No products configured.</td></tr>';
    return;
  }
  body.innerHTML = state.products.map((p) => `<tr>
    <td><span class="cell-primary">${esc(p.product_id)}</span></td>
    <td><span class="cell-primary">${esc(p.product_name)}</span></td>
    <td class="amount">${amount(p.standard_cost_inr)}</td>
    <td>${p.routing === 'human_review' ? pill('Human approval') : pill('Auto demo refund')}</td>
    <td>${esc(p.description || '—')}</td>
    <td>${pill(p.active ? 'Active' : 'Inactive')}</td>
  </tr>`).join('');
}
async function loadMaster() {
  const q = $('#master-search').value.trim();
  const result = await api(`/api/admin/master-records?${new URLSearchParams(q ? { q } : {}).toString()}`);
  state.master = result.records;
  $('#count-master').textContent = result.count;
  $('#master-foot').textContent = `${result.count} master record${result.count === 1 ? '' : 's'} shown (maximum 500).`;
  const body = $('#master-body');
  if (!state.master.length) {
    body.innerHTML = '<tr><td colspan="8" class="empty-cell">No master records yet. Add a product/customer/order reference above.</td></tr>';
    return;
  }
  body.innerHTML = state.master.map((r) => {
    const options = ['Active', 'Needs Verification', 'Inactive'].map((s) => `<option ${r.record_status === s ? 'selected' : ''}>${esc(s)}</option>`).join('');
    return `<tr>
      <td><div class="cell-primary">${esc(r.master_record_id)}</div><div class="cell-secondary">Updated ${date(r.updated_at)}</div></td>
      <td><div class="cell-primary">${esc(r.order_id)}</div><div class="cell-secondary">${esc(r.customer_id || '')}</div></td>
      <td><div class="cell-primary">${esc(r.customer_name || '—')}</div><div class="cell-secondary">${esc(r.customer_email || '')}</div><div class="cell-secondary">${esc(r.customer_phone || '')}</div></td>
      <td><div class="cell-primary">${esc(r.product_name || '—')}</div><div class="cell-secondary">${esc(r.product_id || '')}</div>${r.product_image_url ? `<a target="_blank" rel="noopener" href="${esc(r.product_image_url)}">Image ↗</a>` : ''}</td>
      <td class="amount">${amount(r.purchase_amount_inr)}</td>
      <td><div>${esc(r.bank_account_reference || '—')}</div><div class="cell-secondary">${r.bank_account_last4 ? `•••• ${esc(r.bank_account_last4)}` : 'No last four stored'}</div></td>
      <td>${pill(r.record_status)}</td>
      <td><select class="inline-select master-status-select" data-id="${esc(r.master_record_id)}">${options}</select><button class="save-small save-master-status" data-id="${esc(r.master_record_id)}" type="button">Save</button></td>
    </tr>`;
  }).join('');
}
async function loadReviews() {
  const q = $('#review-search').value.trim();
  const result = await api(`/api/admin/review-queue?${new URLSearchParams(q ? { q } : {}).toString()}`);
  state.reviews = result.records;
  $('#count-reviews').textContent = result.count;
  $('#reviews-foot').textContent = `${result.count} review item${result.count === 1 ? '' : 's'} shown (maximum 500).`;
  const body = $('#reviews-body');
  if (!state.reviews.length) {
    body.innerHTML = '<tr><td colspan="7" class="empty-cell">No requests currently require human review. Requests above ₹5,000 are added automatically.</td></tr>';
    return;
  }
  body.innerHTML = state.reviews.map((r) => {
    const disabled = (r.workflow_event_status === 'Sent' || ['Refund Completed (Demo)', 'Rejected by Human', 'Refund API Failed - Retry Required', 'Workflow Dispatch Permanently Failed'].includes(r.request_status)) ? 'disabled' : '';
    const isApproved = r.approval_checkbox || r.review_status === 'Approved';
    const isRejected = r.review_status === 'Rejected';
    return `<tr>
      <td><div class="cell-primary">${esc(r.request_id)}</div>${pill(r.review_status)}<div class="cell-secondary">${date(r.created_at)}</div></td>
      <td><div class="cell-primary">${esc(r.customer_name)}</div><div class="cell-secondary">${esc(r.order_id)} · ${esc(r.product)}</div></td>
      <td class="amount">${amount(r.refund_amount)}</td>
      <td>${esc(r.review_reason)}<div class="cell-secondary">Request reason: ${esc(r.reason)}</div></td>
      <td>
        <div style="display:flex;align-items:center;gap:6px;">
          <input class="approval-check" type="checkbox" data-id="${esc(r.review_id)}" ${isApproved ? 'checked' : ''} ${disabled} title="Toggle approval" />
          <span class="status-pill ${isApproved ? 'good' : isRejected ? 'bad' : 'pending'}" style="font-weight:700;font-size:10px;">
            ${isApproved ? '✓ APPROVED' : isRejected ? '✗ REJECTED' : '⏳ PENDING'}
          </span>
        </div>
      </td>
      <td><textarea class="comments-input review-comments" data-id="${esc(r.review_id)}" placeholder="Optional review comments" ${disabled}>${esc(r.reviewer_comments || '')}</textarea><div class="cell-secondary">${esc(r.reviewer_id || '')}</div><div class="cell-secondary">Workflow delivery: ${esc(r.workflow_event_status || 'Not Applicable')}</div></td>
      <td><div class="review-actions">
        ${!isApproved ? `<button class="save-small approve-review" data-id="${esc(r.review_id)}" type="button" ${disabled} style="background:#eaf8f1;color:#157851;border-color:#b9e7d0;font-weight:700;">✓ Approve</button>` : ''}
        ${!isRejected ? `<button class="save-small reject-review" data-id="${esc(r.review_id)}" type="button" ${disabled} style="background:#fff1f1;color:#a63f3f;border-color:#f6d5d5;">✗ Reject</button>` : ''}
        <button class="save-small pending-review" data-id="${esc(r.review_id)}" type="button" ${disabled}>Reset</button>
      </div></td>
    </tr>`;
  }).join('');
}
async function loadActivity() {
  const result = await api('/api/admin/activity?limit=300');
  state.activity = result.records;
  $('#count-activity').textContent = result.count;
  $('#activity-total').textContent = `${result.count} latest events`;
  const body = $('#activity-body');
  if (!state.activity.length) {
    body.innerHTML = '<tr><td colspan="6" class="empty-cell">No changes recorded yet.</td></tr>';
    return;
  }
  body.innerHTML = state.activity.map((a) => `<tr>
    <td>${date(a.created_at)}</td><td>${esc(a.entity_table)}</td><td><span class="cell-primary">${esc(a.entity_id)}</span></td>
    <td>${pill(a.action)}</td><td>${esc(a.summary)}</td><td>${esc(a.changed_by)}</td>
  </tr>`).join('');
}
async function refreshAll() {
  $('#refresh-all').disabled = true;
  $('#refresh-all').textContent = 'Refreshing…';
  try {
    await Promise.all([loadSummary(), loadRequests(), loadProducts(), loadMaster(), loadReviews(), loadActivity()]);
  } catch (error) {
    toast(error.message, true);
  } finally {
    $('#refresh-all').disabled = false;
    $('#refresh-all').textContent = 'Refresh data';
  }
}
function activateTab(name) {
  $$('.tab').forEach((button) => button.classList.toggle('active', button.dataset.tab === name));
  $$('.tab-view').forEach((view) => view.classList.toggle('active', view.id === `view-${name}`));
}

$$('.tab').forEach((button) => button.addEventListener('click', () => activateTab(button.dataset.tab)));
$('#refresh-all').addEventListener('click', refreshAll);
$('#request-search').addEventListener('keydown', (e) => { if (e.key === 'Enter') loadRequests().catch((err) => toast(err.message, true)); });
$('#request-status-filter').addEventListener('change', () => loadRequests().catch((err) => toast(err.message, true)));
$('#master-search').addEventListener('keydown', (e) => { if (e.key === 'Enter') loadMaster().catch((err) => toast(err.message, true)); });
$('#review-search').addEventListener('keydown', (e) => { if (e.key === 'Enter') loadReviews().catch((err) => toast(err.message, true)); });

$('#master-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  const fd = new FormData(form);
  const payload = Object.fromEntries(fd.entries());
  payload.purchase_amount_inr = Number(payload.purchase_amount_inr || 0);
  const message = $('#master-form-message');
  message.textContent = 'Saving…';
  try {
    const result = await api('/api/admin/master-records', { method: 'POST', body: JSON.stringify(payload) });
    form.reset();
    form.elements.purchase_amount_inr.value = '0';
    message.textContent = `Saved ${result.record.master_record_id}`;
    toast('Master record saved to the local database.');
    await Promise.all([loadSummary(), loadMaster(), loadActivity()]);
  } catch (error) {
    message.textContent = error.message;
    toast(error.message, true);
  }
});

$('#master-body').addEventListener('click', async (event) => {
  const button = event.target.closest('.save-master-status');
  if (!button) return;
  const id = button.dataset.id;
  const select = $(`.master-status-select[data-id="${CSS.escape(id)}"]`);
  button.disabled = true;
  try {
    await api(`/api/admin/master-records/${encodeURIComponent(id)}/status`, {
      method: 'PATCH', body: JSON.stringify({ record_status: select.value, changed_by: 'local admin' }),
    });
    toast(`Updated master record ${id}.`);
    await Promise.all([loadSummary(), loadMaster(), loadActivity()]);
  } catch (error) { toast(error.message, true); }
  finally { button.disabled = false; }
});

async function makeReviewDecision(reviewId, decision) {
  const reviewer = $('#reviewer-name').value.trim();
  if (reviewer.length < 2) {
    toast('Enter the reviewer name before recording a decision.', true);
    $('#reviewer-name').focus();
    return;
  }
  const commentEl = $(`.review-comments[data-id="${CSS.escape(reviewId)}"]`);
  const comments = commentEl ? commentEl.value : '';
  try {
    await api(`/api/admin/review-queue/${encodeURIComponent(reviewId)}`, {
      method: 'PATCH', body: JSON.stringify({ decision, reviewer_id: reviewer, comments }),
    });
    if (decision === 'approve') toast('Approval recorded. The separate workflow bridge will deliver the decision; this app did not initiate a refund.');
    else if (decision === 'reject') toast('Rejection recorded. The separate workflow bridge will deliver the decision.');
    else toast('Review reset to pending.');
    await Promise.all([loadSummary(), loadRequests(), loadReviews(), loadActivity()]);
  } catch (error) { toast(error.message, true); await loadReviews(); }
}
$('#reviews-body').addEventListener('change', async (event) => {
  const checkbox = event.target.closest('.approval-check');
  if (!checkbox || checkbox.disabled) return;
  checkbox.disabled = true;
  await makeReviewDecision(checkbox.dataset.id, checkbox.checked ? 'approve' : 'pending');
});
$('#reviews-body').addEventListener('click', async (event) => {
  const approve = event.target.closest('.approve-review');
  const reject = event.target.closest('.reject-review');
  const pending = event.target.closest('.pending-review');
  if (approve) {
    await makeReviewDecision(approve.dataset.id, 'approve');
  } else if (reject) {
    if (confirm('Record a human rejection for this refund request?')) await makeReviewDecision(reject.dataset.id, 'reject');
  } else if (pending) {
    await makeReviewDecision(pending.dataset.id, 'pending');
  }
});

$('#requests-body').addEventListener('click', async (event) => {
  const btn = event.target.closest('.send-to-review-btn');
  if (btn) {
    btn.disabled = true;
    try {
      await api(`/api/admin/requests/${encodeURIComponent(btn.dataset.id)}/send-to-review`, { method: 'POST' });
      toast('Request sent to Human Review Queue.');
      await Promise.all([loadSummary(), loadRequests(), loadReviews(), loadActivity()]);
      activateTab('reviews');
    } catch (e) {
      toast(e.message, true);
      btn.disabled = false;
    }
    return;
  }
  const reqStart = event.target.closest('.requeue-start');
  if (reqStart) {
    reqStart.disabled = true;
    try {
      await api(`/api/admin/requests/${encodeURIComponent(reqStart.dataset.id)}/requeue-start`, { method: 'POST' });
      toast('Request reset to Queued.');
      await Promise.all([loadSummary(), loadRequests(), loadActivity()]);
    } catch (e) {
      toast(e.message, true);
      reqStart.disabled = false;
    }
  }
});

$('#wipe-data').addEventListener('click', async () => {
  const confirmed = confirm(
    'WIPE DEMO DATA?\n\nThis permanently deletes all local refund requests, product/customer master records, human-review items, and previous Activity Log entries. A single reset event will remain in Activity Log. This cannot be undone.'
  );
  if (!confirmed) return;

  const phrase = prompt('Type exactly WIPE RAINBOW CORP DATA to continue:');
  if (phrase === null) return;
  if (phrase.trim() !== 'WIPE RAINBOW CORP DATA') {
    toast('Confirmation phrase did not match. No data was deleted.', true);
    return;
  }

  const button = $('#wipe-data');
  button.disabled = true;
  button.textContent = 'Wiping…';
  try {
    const result = await api('/api/admin/wipe-data', {
      method: 'POST',
      body: JSON.stringify({ confirmation: phrase.trim(), changed_by: 'local admin' }),
    });
    toast(`Demo data wiped: ${result.deleted.refund_requests} requests, ${result.deleted.product_customer_master} master records, ${result.deleted.human_review_queue} review items.`);
    $('#request-search').value = '';
    $('#request-status-filter').value = '';
    $('#master-search').value = '';
    $('#review-search').value = '';
    await refreshAll();
  } catch (error) {
    toast(error.message, true);
  } finally {
    button.disabled = false;
    button.textContent = 'Wipe demo data';
  }
});

function connectLiveUpdates() {
  const scheme = window.location.protocol === 'https:' ? 'wss' : 'ws';
  const socket = new WebSocket(`${scheme}://${window.location.host}/ws/updates`);
  socket.addEventListener('message', (event) => {
    try {
      const payload = JSON.parse(event.data);
      if (payload.type === 'data_changed') refreshAll();
    } catch (_) { /* ignore malformed event */ }
  });
  socket.addEventListener('close', () => setTimeout(connectLiveUpdates, 2500));
  socket.addEventListener('error', () => socket.close());
}
connectLiveUpdates();
refreshAll();

document.addEventListener('click', async (event) => {
  const button = event.target.closest('.requeue-start');
  if (!button) return;
  const first = confirm('Only continue after checking Camunda and verifying that NO process instance was started for this request.');
  if (!first) return;
  const phrase = prompt('Type exactly: I VERIFIED NO PROCESS STARTED');
  if (phrase === null) return;
  button.disabled = true;
  try {
    const result = await api(`/api/admin/requests/${encodeURIComponent(button.dataset.id)}/requeue-start`, {
      method: 'POST', body: JSON.stringify({ confirmation: phrase.trim() }),
    });
    toast(`Request ${result.request.request_id} requeued. The bridge will retry it.`);
    await Promise.all([loadSummary(), loadRequests(), loadActivity()]);
  } catch (error) { toast(error.message, true); button.disabled = false; }
});
