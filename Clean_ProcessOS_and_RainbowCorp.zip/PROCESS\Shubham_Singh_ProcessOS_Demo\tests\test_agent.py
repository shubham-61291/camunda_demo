import sys
from pathlib import Path
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from processos_studio_agent import extract_urls, redact_secrets, deterministic_checks, initial_blueprint, _generate_cli_shim


def sample_bpmn(threshold=5000, process_id="chat_refund_process"):
    return f'''<?xml version="1.0"?>
<bpmn:definitions xmlns:bpmn="http://www.omg.org/spec/BPMN/20100524/MODEL" xmlns:zeebe="http://camunda.org/schema/zeebe/1.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" id="d" targetNamespace="x">
  <bpmn:process id="{process_id}" isExecutable="true">
    <bpmn:startEvent id="StartEvent_Refund" />
    <bpmn:exclusiveGateway id="Gateway_Amount" default="Flow_Auto" />
    <bpmn:sequenceFlow id="Flow_Start_Route" sourceRef="StartEvent_Refund" targetRef="Gateway_Amount" />
    <bpmn:sequenceFlow id="Flow_Human" sourceRef="Gateway_Amount" targetRef="Task_RegisterReview"><bpmn:conditionExpression xsi:type="bpmn:tFormalExpression">= refundAmount &gt; {threshold}</bpmn:conditionExpression></bpmn:sequenceFlow>
    <bpmn:sequenceFlow id="Flow_Auto" sourceRef="Gateway_Amount" targetRef="Task_ExecuteRefund" />
    <bpmn:serviceTask id="Task_RegisterReview"><bpmn:extensionElements><zeebe:taskDefinition type="register-human-review" /></bpmn:extensionElements></bpmn:serviceTask>
    <bpmn:sequenceFlow id="Flow_Register_To_UserTask" sourceRef="Task_RegisterReview" targetRef="Task_HumanReview" />
    <bpmn:userTask id="Task_HumanReview"><bpmn:extensionElements><zeebe:userTask /></bpmn:extensionElements></bpmn:userTask>
    <bpmn:sequenceFlow id="Flow_UserTask_To_Decision" sourceRef="Task_HumanReview" targetRef="Gateway_Approved" />
    <bpmn:exclusiveGateway id="Gateway_Approved" default="Flow_Rejected" />
    <bpmn:sequenceFlow id="Flow_Approved" sourceRef="Gateway_Approved" targetRef="Task_ExecuteRefund"><bpmn:conditionExpression xsi:type="bpmn:tFormalExpression">= humanApproved = true</bpmn:conditionExpression></bpmn:sequenceFlow>
    <bpmn:sequenceFlow id="Flow_Rejected" sourceRef="Gateway_Approved" targetRef="Task_RecordRejection" />
    <bpmn:serviceTask id="Task_ExecuteRefund"><bpmn:extensionElements><zeebe:taskDefinition type="execute-demo-refund" /></bpmn:extensionElements></bpmn:serviceTask>
    <bpmn:sequenceFlow id="Flow_Execute_To_Sync" sourceRef="Task_ExecuteRefund" targetRef="Task_SyncResult" />
    <bpmn:serviceTask id="Task_SyncResult"><bpmn:extensionElements><zeebe:taskDefinition type="sync-refund-result" /></bpmn:extensionElements></bpmn:serviceTask>
    <bpmn:sequenceFlow id="Flow_Sync_To_Result" sourceRef="Task_SyncResult" targetRef="Gateway_RefundResult" />
    <bpmn:exclusiveGateway id="Gateway_RefundResult" default="Flow_RefundFailed" />
    <bpmn:sequenceFlow id="Flow_RefundSuccess" sourceRef="Gateway_RefundResult" targetRef="EndEvent_Completed"><bpmn:conditionExpression xsi:type="bpmn:tFormalExpression">= refundApiStatus = "SUCCESS"</bpmn:conditionExpression></bpmn:sequenceFlow>
    <bpmn:sequenceFlow id="Flow_RefundFailed" sourceRef="Gateway_RefundResult" targetRef="EndEvent_Failed" />
    <bpmn:serviceTask id="Task_RecordRejection"><bpmn:extensionElements><zeebe:taskDefinition type="record-refund-rejection" /></bpmn:extensionElements></bpmn:serviceTask>
    <bpmn:sequenceFlow id="Flow_Rejection_To_End" sourceRef="Task_RecordRejection" targetRef="EndEvent_Rejected" />
    <bpmn:endEvent id="EndEvent_Completed" /><bpmn:endEvent id="EndEvent_Failed" /><bpmn:endEvent id="EndEvent_Rejected" />
  </bpmn:process>
</bpmn:definitions>'''


def test_extract_urls_from_chat():
    assert extract_urls("Test https://localhost:8000/api/health, and ws://127.0.0.1:8000/ws") == ["https://localhost:8000/api/health", "ws://127.0.0.1:8000/ws"]


def test_redact_secrets():
    value = redact_secrets("Use https://127.0.0.1 with header X-Integration-Key: abc123 and Authorization: Bearer xyz987")
    assert "abc123" not in value and "xyz987" not in value


def test_extract_auth_inline_header():
    from processos_studio_agent import extract_auth
    assert extract_auth("Use endpoint http://127.0.0.1 with header X-Integration-Key: wrong-key") == ("X-Integration-Key", "wrong-key")


def test_redact_secret_query_parameters():
    value = redact_secrets("Check https://api.example.test/refunds?api_key=secret123&mode=test")
    assert "secret123" not in value
    assert "mode=test" in value
    assert "fragment-secret" not in redact_secrets("https://api.example.test/health#access_token=fragment-secret")


def test_deterministic_checks_pass_for_required_contract():
    bp = initial_blueprint()
    errors = deterministic_checks(sample_bpmn(), _generate_cli_shim(ROOT), bp)
    assert errors == [], errors


def test_deterministic_checks_fail_wrong_process_id():
    bp = initial_blueprint()
    errors = deterministic_checks(sample_bpmn(process_id="wrong"), _generate_cli_shim(ROOT), bp)
    assert any("process id" in e.lower() for e in errors)


def test_deterministic_checks_fail_missing_threshold():
    bp = initial_blueprint()
    errors = deterministic_checks(sample_bpmn(threshold=8000), _generate_cli_shim(ROOT), bp)
    assert any("threshold" in e.lower() for e in errors)


def test_redact_basic_authorization_and_extract_it():
    from processos_studio_agent import extract_auth
    supplied = "Use http://127.0.0.1:8000 with Authorization: Basic dXNlcjpwYXNz and continue"
    redacted = redact_secrets(supplied)
    assert "dXNlcjpwYXNz" not in redacted
    assert extract_auth(supplied) == ("Authorization", "Basic dXNlcjpwYXNz")


def test_only_openai_key_is_documented_as_required_env():
    from pathlib import Path
    example = (Path(__file__).resolve().parents[1] / ".env.example").read_text(encoding="utf-8")
    assert "OPENAI_API_KEY=" in example
    assert "TARGET_INTEGRATION_TOKEN" not in example
    assert "TARGET_ACTION_API_KEY" not in example
    assert "RAINBOW_STACK_DIR" not in example


def test_action_route_discovery_never_calls_refund_post(monkeypatch):
    from fastapi.testclient import TestClient
    import main

    session_id = "test-action-route-safe-probe"
    main.SESSIONS.pop(session_id, None)
    calls = []

    async def fake_openapi(base_url, route_path, method, label):
        calls.append(("openapi", base_url, route_path, method, label))
        return {"url": f"{base_url}/openapi.json", "verified": True, "status_code": 200, "label": label, "reason": "route declared"}

    async def fake_probe(url, method="GET", headers=None, payload=None):
        calls.append(("probe", url, method, dict(headers or {})))
        return {"url": url, "verified": True, "status_code": 200, "reason": "read-only probe passed"}

    async def fake_reply(message, spec, probe_result=None, history=None):
        return {"reply": "Endpoint and token captured for this test.", "spec_patch": {}}

    monkeypatch.setattr(main, "_verify_openapi_route", fake_openapi)
    monkeypatch.setattr(main, "probe_endpoint", fake_probe)
    monkeypatch.setattr(main, "conversational_reply", fake_reply)

    with TestClient(main.app) as client:
        response = client.post("/api/chat", json={
            "session_id": session_id,
            "message": "Use http://127.0.0.1:8001/api/v1/refunds with header X-Demo-API-Key: test-secret-value",
        })

    assert response.status_code == 200, response.text
    assert any(c[0] == "openapi" and c[2] == "/api/v1/refunds" and c[3] == "post" for c in calls)
    assert any(c[0] == "probe" and c[1].endswith("/api/v1/transactions") and c[2] == "GET" for c in calls)
    assert not any(c[0] == "probe" and c[1].endswith("/api/v1/refunds") for c in calls)
    assert "test-secret-value" not in response.text
    assert "test-secret-value" not in str(main.SESSIONS[session_id]["chat"])
    main.SESSIONS.pop(session_id, None)


def test_initial_blueprint_does_not_assume_rainbow_target():
    bp = initial_blueprint()
    assert bp["process_id"] == "chat_refund_process"
    assert bp["business_rules"] == []
    assert "integration_contract" not in bp


def test_dialogue_prompt_starts_with_workflow_not_rainbow_path(monkeypatch):
    import asyncio
    import processos_studio_agent as agent
    captured = {}

    async def fake_openai_json(system, user, model=None):
        captured["system"] = system
        captured["user"] = user
        return {"reply": "What should happen when your chatbot receives a refund request?", "spec_patch": {}}

    monkeypatch.setattr(agent, "_openai_json", fake_openai_json)
    result = asyncio.run(agent.conversational_reply(
        "I want to automate my chat refund chatbot", initial_blueprint(), history=[]
    ))
    assert "Do not ask for a project folder path as an opening question" in captured["system"]
    assert "Ask for the full local folder path" not in captured["system"]
    assert "already-built Rainbow Corp refund demo" not in captured["system"]
    assert "rainbow_stack_dir" not in captured["user"]
    assert "Rainbow Corp local refund demo API" not in captured["user"]
    assert "folder path" not in result["reply"].lower()


def test_ui_opening_message_does_not_request_rainbow_path():
    html = (ROOT / "static" / "studio.html").read_text(encoding="utf-8")
    opening = html.split('<div id="chatlog"', 1)[1].split('</div></div>', 1)[0]
    assert "What would you like to automate?" in opening
    assert "Rainbow Corp" not in opening
    assert "folder path" not in opening.lower()


def test_deterministic_contract_bpmn_satisfies_exact_gate():
    from processos_studio_agent import _build_contract_bpmn
    bp = initial_blueprint()
    bp.update({"process_id": "rainbow_refund_process", "refund_threshold": 5000})
    bpmn = _build_contract_bpmn(bp)
    errors = deterministic_checks(bpmn, _generate_cli_shim(ROOT), bp)
    assert errors == [], errors


def test_contract_bpmn_escapes_threshold_and_rejects_invalid_process_id():
    import pytest
    from processos_studio_agent import _build_contract_bpmn
    bp = initial_blueprint()
    bp.update({"process_id": "rainbow_refund_process", "refund_threshold": 5000})
    assert "= refundAmount &gt; 5000" in _build_contract_bpmn(bp)
    bp["process_id"] = "bad id with spaces"
    with pytest.raises(ValueError):
        _build_contract_bpmn(bp)


def test_coder_draft_technical_failure_is_repaired_before_tester(monkeypatch, tmp_path):
    import asyncio
    import subprocess
    import processos_studio_agent as agent

    responses = [
        {"bpmn_xml": "<not-valid-bpmn/>"},
        {"passed": True, "audit_summary": "The final repaired BPMN satisfies the contract.", "feedback_for_coder": ""},
    ]

    async def fake_openai_json(system, user, model=None):
        return responses.pop(0)

    monkeypatch.setattr(agent, "_openai_json", fake_openai_json)
    monkeypatch.setattr(subprocess, "run", lambda *args, **kwargs: subprocess.CompletedProcess(args[0], 0, "self-test ok", ""))

    bp = initial_blueprint()
    bp.update({"process_id": "rainbow_refund_process", "refund_threshold": 5000})
    result = asyncio.run(agent.coder_tester_loop(bp, tmp_path / "generated_workflow"))

    assert result["passed"] is True, result
    assert result["iteration"] == 1
    assert result["history"][0]["deterministic_template_repair_applied"] is True
    assert result["history"][0]["technical_errors"] == []
    final_bpmn = (tmp_path / "generated_workflow" / "workflow.bpmn").read_text(encoding="utf-8")
    assert deterministic_checks(final_bpmn, _generate_cli_shim(ROOT), bp) == []


def test_generated_bpmn_rejects_duplicate_ids_and_unapproved_conditions():
    from processos_studio_agent import _build_contract_bpmn
    bp = initial_blueprint()
    bp.update({"process_id": "rainbow_refund_process", "refund_threshold": 5000})
    bpmn = _build_contract_bpmn(bp)
    duplicate = bpmn.replace('<bpmn:endEvent id="EndEvent_Failed" />', '<bpmn:endEvent id="EndEvent_Completed" />')
    assert any("duplicate bpmn ids" in err.lower() for err in deterministic_checks(duplicate, _generate_cli_shim(ROOT), bp))
    extra_condition = bpmn.replace(
        '<bpmn:sequenceFlow id="Flow_Auto" sourceRef="Gateway_Amount" targetRef="Task_ExecuteRefund" />',
        '<bpmn:sequenceFlow id="Flow_Auto" sourceRef="Gateway_Amount" targetRef="Task_ExecuteRefund"><bpmn:conditionExpression xsi:type="bpmn:tFormalExpression">= refundAmount &gt; 0</bpmn:conditionExpression></bpmn:sequenceFlow>'
    )
    assert any("must not have a condition expression" in err for err in deterministic_checks(extra_condition, _generate_cli_shim(ROOT), bp))


def test_prompt_uses_existing_bridge_refund_transaction_variable():
    from processos_studio_agent import bpmn_prompt
    prompt = bpmn_prompt(initial_blueprint(), "")
    assert "refundTransactionId" in prompt
    assert "refundApiStatus, transactionId, refundApiMessage" not in prompt


def test_status_exposes_audit_build_id_and_default_model():
    from fastapi.testclient import TestClient
    import main
    with TestClient(main.app) as client:
        result = client.get('/api/status')
    assert result.status_code == 200
    body = result.json()
    assert body['build_id'] == 'processos-2026.10.14-audit8'
    assert body['bpmn_template_repair_enabled'] is True
    assert body['required_environment_variables'] == ['OPENAI_API_KEY']


def test_runtime_does_not_start_camunda_when_target_preflight_fails(monkeypatch, tmp_path):
    import asyncio
    import processos_runtime as runtime
    import camunda_manager

    stack = tmp_path / 'stack'
    (stack / 'local_bridge').mkdir(parents=True)
    (stack / 'local_bridge' / 'bridge.py').write_text('# fixture only\n', encoding='utf-8')
    workflow = tmp_path / 'generated_workflow'
    workflow.mkdir()
    bp = {
        'process_id': 'rainbow_refund_process',
        'rainbow_stack_dir': str(stack),
        'app_base_url': 'http://127.0.0.1:8000',
        'action_api_url': 'http://127.0.0.1:8001/api/v1/refunds',
        'integration_header_name': 'X-Integration-Key',
        'action_header_name': 'X-Demo-API-Key',
    }
    context = {'blueprint': bp, 'secrets': {
        'x-integration-key': {'name': 'X-Integration-Key', 'value': 'not-a-real-key', 'origin': ('127.0.0.1', 8000)},
        'x-demo-api-key': {'name': 'X-Demo-API-Key', 'value': 'not-a-real-key', 'origin': ('127.0.0.1', 8001)},
    }}
    monkeypatch.setattr(runtime, '_read_runtime_context', lambda: context)
    monkeypatch.setattr(runtime, 'validate_workflow', lambda _path: [])
    monkeypatch.setattr(runtime, '_bridge_process_running', lambda _path: False)
    async def failed_preflight(_bp, _secrets):
        return [{'label': 'mock action API health', 'verified': False, 'url': 'http://127.0.0.1:8001/health', 'reason': 'Connection failed'}]
    monkeypatch.setattr(runtime, '_runtime_preflight', failed_preflight)
    camunda_calls = []
    monkeypatch.setattr(camunda_manager, 'ensure_camunda', lambda **kwargs: camunda_calls.append(kwargs))
    rc = runtime.run_direct(workflow)
    assert rc == 2
    assert camunda_calls == []


def test_business_words_are_not_extracted_or_redacted_as_credentials():
    from processos_studio_agent import extract_auth
    message = "The key rule is that refunds above 5000 need approval; secret sauce is part of the process."
    assert extract_auth(message) == (None, None)
    assert redact_secrets(message) == message


def test_secret_values_are_scoped_to_exact_origin():
    import main
    state = {"secrets": {"x-integration-key": {"name": "X-Integration-Key", "value": "secret-value", "origin": ("127.0.0.1", 8000)}}}
    assert main._secret_value(state, "X-Integration-Key", "http://127.0.0.1:8000/api/integration/health") == "secret-value"
    assert main._secret_value(state, "X-Integration-Key", "http://127.0.0.1:9000/api/integration/health") == ""
    state["secrets"]["x-integration-key"]["origin"] = None
    assert main._secret_value(state, "X-Integration-Key", "http://127.0.0.1:8000/api/integration/health") == ""


def test_threshold_formatting_preserves_large_decimal_values():
    from processos_studio_agent import _build_contract_bpmn, threshold_text
    assert threshold_text("12345.67") == "12345.67"
    assert threshold_text("1234567") == "1234567"
    bp = initial_blueprint()
    bp.update({"process_id": "rainbow_refund_process", "refund_threshold": "12345.67"})
    bpmn = _build_contract_bpmn(bp)
    assert "= refundAmount &gt; 12345.67" in bpmn
    assert "1.23457e+06" not in _build_contract_bpmn({**bp, "refund_threshold": "1234567"})


def test_model_cannot_patch_rainbow_stack_path(monkeypatch):
    import asyncio
    import processos_studio_agent as agent
    async def fake_openai_json(system, user, model=None):
        return {"reply": "What system should be automated?", "spec_patch": {"rainbow_stack_dir": "C:\\attacker", "process_id": "safe_process"}}
    monkeypatch.setattr(agent, "_openai_json", fake_openai_json)
    result = asyncio.run(agent.conversational_reply("Please help", initial_blueprint(), history=[]))
    assert "rainbow_stack_dir" not in result["spec_patch"]
    assert result["spec_patch"]["process_id"] == "safe_process"


def test_runtime_contract_rejects_secrets_without_origin():
    import pytest
    import processos_runtime as runtime
    bp = {
        "app_base_url": "http://127.0.0.1:8000",
        "integration_health_endpoint": "http://127.0.0.1:8000/api/integration/health",
        "integration_poll_endpoint": "http://127.0.0.1:8000/api/integration/requests/pending",
        "integration_status_endpoint": "http://127.0.0.1:8000/api/integration/requests/{request_id}/workflow-result",
        "action_api_url": "http://127.0.0.1:8001/api/v1/refunds",
        "action_health_url": "http://127.0.0.1:8001/health",
        "action_verify_url": "http://127.0.0.1:8001/api/v1/transactions",
        "websocket_url": "ws://127.0.0.1:8000/ws/updates",
    }
    secrets = {
        "x-integration-key": {"name": "X-Integration-Key", "value": "token"},
        "x-demo-api-key": {"name": "X-Demo-API-Key", "value": "token"},
    }
    with pytest.raises(RuntimeError, match="no verified origin"):
        runtime._check_target_contract(bp, secrets)


def test_dns_policy_reapplies_to_every_resolution_result():
    from processos_studio_agent import _address_policy_error
    assert _address_policy_error("http", {"127.0.0.1"}) is None
    assert _address_policy_error("https", {"93.184.216.34"}) is None
    assert "Mixed" in _address_policy_error("https", {"127.0.0.1", "93.184.216.34"})
    assert "Link-local" in _address_policy_error("https", {"169.254.169.254"})
    assert "Reserved" in _address_policy_error("https", {"224.0.0.1"})
    assert "HTTPS/WSS" in _address_policy_error("http", {"93.184.216.34"})


def test_action_token_from_one_origin_is_not_reused_for_another_host(monkeypatch):
    from fastapi.testclient import TestClient
    import main

    session_id = "test-action-secret-origin-boundary"
    main.SESSIONS.pop(session_id, None)
    state = main.session_state(session_id)
    state["secrets"]["x-demo-api-key"] = {
        "name": "X-Demo-API-Key", "value": "origin-bound-secret", "origin": ("127.0.0.1", 8001)
    }
    calls = []

    async def fake_openapi(base_url, route_path, method, label):
        calls.append(("openapi", base_url, route_path, method, label))
        return {"url": f"{base_url}/openapi.json", "verified": True, "status_code": 200, "label": label, "reason": "route declared"}

    async def fake_probe(url, method="GET", headers=None, payload=None):
        calls.append(("probe", url, method, dict(headers or {})))
        return {"url": url, "verified": True, "status_code": 200, "reason": "read-only probe passed"}

    async def fake_reply(message, spec, probe_result=None, history=None):
        return {"reply": "Checked endpoint safely.", "spec_patch": {}}

    monkeypatch.setattr(main, "_verify_openapi_route", fake_openapi)
    monkeypatch.setattr(main, "probe_endpoint", fake_probe)
    monkeypatch.setattr(main, "conversational_reply", fake_reply)
    with TestClient(main.app) as client:
        response = client.post("/api/chat", json={
            "session_id": session_id,
            "message": "Inspect https://api.attacker.example/api/v1/refunds",
        })
    assert response.status_code == 200, response.text
    assert not any("origin-bound-secret" in str(call) for call in calls)
    assert not any(call[0] == "probe" and call[1].endswith("/api/v1/transactions") for call in calls)


def test_failed_gate_response_identifies_patched_build_and_repair(monkeypatch, tmp_path):
    import asyncio
    import subprocess
    import processos_studio_agent as agent

    responses = []
    for index in range(3):
        responses.extend([
            {"bpmn_xml": "<not-valid-bpmn/>"},
            {"passed": False, "audit_summary": f"test rejection {index + 1}", "feedback_for_coder": "test feedback"},
        ])

    async def fake_openai_json(system, user, model=None):
        return responses.pop(0)

    monkeypatch.setattr(agent, "_openai_json", fake_openai_json)
    monkeypatch.setattr(subprocess, "run", lambda *args, **kwargs: subprocess.CompletedProcess(args[0], 0, "self-test ok", ""))
    bp = initial_blueprint()
    bp.update({"process_id": "rainbow_refund_process", "refund_threshold": 5000})
    out_dir = tmp_path / "generated_workflow"
    result = asyncio.run(agent.coder_tester_loop(bp, out_dir))
    assert result["passed"] is False
    assert result["build_id"] == "processos-2026.10.14-audit8"
    assert len(result["history"]) == 3
    assert all(row["deterministic_template_repair_applied"] for row in result["history"])
    report = __import__("json").loads((out_dir / "tester_report.json").read_text(encoding="utf-8"))
    assert report["build_id"] == "processos-2026.10.14-audit8"
    assert all("deterministic_template_repair_applied" in row for row in report["checks"])
