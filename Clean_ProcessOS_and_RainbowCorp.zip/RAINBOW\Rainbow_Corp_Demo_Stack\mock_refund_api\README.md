# Rainbow Corp Mock Refund API

Standalone synthetic refund service for the interview demo. It persists simulated transactions in its own SQLite ledger and never calls a real bank or payment rail.

Run `run_mock_api.bat`; the API binds to `127.0.0.1:8001`. Health is available at `/health`, refund creation at `POST /api/v1/refunds`, and synthetic transaction history at `GET /api/v1/transactions` (requires `X-Demo-API-Key`). The request ID is used as an idempotency key so retries return the same demo transaction.

Only the **separate integration bridge's workflow worker** should call the refund endpoint. The Rainbow Corp app does not make refund API calls.
