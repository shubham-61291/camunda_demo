# Rainbow Corp Refund Demo Stack

A local interview demo split into three separate systems. **The customer-facing application has no Camunda-specific code.** The workflow integration is isolated in a local bridge.

## Components

- `rainbow_corp_app/` — rule-based chatbot, SQLite data console, product/customer records, refund request register, human-review UI, activity log and WebSocket updates. Exposes a token-protected generic integration REST API. Does not choose the workflow path or initiate a refund.
- `workflow_assets/` — BPMN process model for Camunda. The BPMN amount gateway selects automatic processing for amounts `<= ₹5,000` and human review for amounts `> ₹5,000`. Human rejection bypasses the refund API.
- `local_bridge/` — separate local integration worker. Polls the app every 60 seconds, starts process instances through workflow REST, handles BPMN service tasks, delivers human decisions, and syncs workflow results back.
- `mock_refund_api/` — a separate local fake refund service with its own SQLite ledger. It returns a synthetic transaction ID and never calls a real bank.
- `tests/` — local integration and bridge behavior tests.

## Run locally on Windows

Install Python 3.11+ first. Open three separate terminals and run:

1. **Rainbow Corp app:** open `rainbow_corp_app/` and run `run.bat`. Chatbot: `http://127.0.0.1:8000`; admin console: `http://127.0.0.1:8000/admin`; API docs: `http://127.0.0.1:8000/docs`.
2. **Mock Refund API:** open `mock_refund_api/` and run `run_mock_api.bat`. Health check: `http://127.0.0.1:8001/health`.
3. **Workflow bridge:** copy `local_bridge/.env.example` to `local_bridge/.env`, enter workflow REST address and client credentials, then run `local_bridge/deploy_process.bat` once and `local_bridge/run_bridge.bat` to start processing.

On first run, copy each component's `.env.example` to `.env` if needed. Set a long random `INTEGRATION_API_TOKEN` in both `rainbow_corp_app/.env` and `local_bridge/.env`; set the same `DEMO_REFUND_API_KEY` in `local_bridge/.env` and `mock_refund_api/.env`. The server-side services fail closed when a key is not configured. Do not use sample or hard-coded keys. The bridge also requires both APIs to be running. Before a refund can be submitted, add an active, verified order/customer record in the admin data console with matching order ID, registered email, product and purchase amount. The admin APIs have no login/authentication in this demo; bind to loopback only and never expose it to a network.

## Demo flow

- Customer submits a refund through the chatbot; the app stores it with `Queued for Workflow` status.
- The bridge polls every 60 seconds and starts a workflow instance.
- BPMN handles routing. At or below ₹5,000, the process can call the mock refund job automatically; above ₹5,000, the workflow creates a review entry and waits for a human decision in `/admin`.
- After approval, the bridge completes the workflow user task. The workflow then calls the mock refund API. A rejection does not call the refund API.
- When the mock API returns success, the bridge syncs the transaction ID and final status to SQLite. WebSocket updates refresh connected screens.

No real money moves. This setup is for a controlled interview demo only. To exercise the failure branch, stop the mock API, set `MOCK_REFUND_FORCE_STATUS=FAILED` in `mock_refund_api/.env`, restart it and submit a new request ID. Idempotent existing request IDs retain their original recorded result; reset only the mock ledger if you need to replay a scenario.

## Data and reset

The app database (`rainbow_corp_app/rainbow_refunds.db`) and mock transaction ledger (`mock_refund_api/mock_refund_api.sqlite3`) are separate local files created on first run. Keep them when updating code if you need to preserve test data. Use the admin wipe action to reset app demo records; the mock ledger is separate and should also be reset separately if you need a fully clean demo.

## Testing

From this project root, run:

```bash
python -m pytest -q
```

The tests verify local app API behavior, status transitions, duplicate prevention, workflow bridge dispatch/decision logic, and that the app stores requests without initiating refunds. They do not prove a live Camunda cluster has been configured; that requires valid cluster credentials and an actual deployment.
