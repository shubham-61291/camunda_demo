# Rainbow Corp Refund Assistant (standalone app)

This folder is the standalone customer-facing application and local data console. It contains **no workflow-engine SDK, BPMN model, workflow credentials, worker code, or refund-execution code**.

## Run

1. Install Python 3.11+.
2. Copy `.env.example` to `.env` only if you need to customise the local database path or integration token.
3. Double-click `run.bat`.
4. Open the chatbot at <http://127.0.0.1:8000>.
5. Open the data console at <http://127.0.0.1:8000/admin>.
6. API documentation: <http://127.0.0.1:8000/docs>.

The server binds to `127.0.0.1` only. The SQLite database is created automatically in this folder. Existing databases receive additive migrations; pre-existing requests are archived from dispatch so they are not automatically resubmitted on upgrade.

## Responsibilities

- Rule-based chatbot to collect refund requests and check status by order ID + registered email.
- Five standard products in SQLite (three at or below ₹5,000 and two above ₹5,000).
- Duplicate protection for normalised order ID + email + amount.
- Admin Data Console and human decision capture.
- Live admin updates over `ws://127.0.0.1:8000/ws/updates`.
- Generic, token-protected integration API for a separate local bridge.

This app does **not** decide which workflow branch to use, start a workflow process, or call the mock refund API. The external workflow's response is saved only through the authenticated integration result endpoint.

## Integration API

All `/api/integration/*` routes require the `X-Integration-Key` header matching `INTEGRATION_API_TOKEN`.

- `GET /api/integration/health`
- `GET /api/integration/requests/pending`
- `POST /api/integration/requests/{request_id}/claim`
- `POST /api/integration/requests/{request_id}/dispatch-result`
- `POST /api/integration/requests/{request_id}/review-required`
- `GET /api/integration/review-decisions/pending`
- `POST /api/integration/review-decisions/{review_id}/ack`
- `POST /api/integration/requests/{request_id}/workflow-result`

Request polling cadence is configured by the separate integration bridge. The app does not call out to that bridge. Status changes are pushed to connected UI sessions over WebSocket.

## Scope and safety

The human review console records approve/reject decisions. It does not execute a refund. Use synthetic customer data. Do not store full bank account numbers or credentials in the app database. This is a local interview demo, not a production refund system.


## Local verification requirements

Integration endpoints fail closed if `INTEGRATION_API_TOKEN` is absent. Copy `.env.example` to `.env` and set a private token that exactly matches `local_bridge/.env`. Refund submissions must match an active `product_customer_master` order by normalized order ID and registered email; the product and requested amount must agree with the master record. This demo has no admin login, so serve it only on `127.0.0.1`.
