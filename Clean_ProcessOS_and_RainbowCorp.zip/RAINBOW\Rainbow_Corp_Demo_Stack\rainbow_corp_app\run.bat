@echo off
setlocal
cd /d "%~dp0"
if not exist ".env" (
  copy ".env.example" ".env" >nul
  echo Created .env from .env.example.
  echo Set INTEGRATION_API_TOKEN to a long random value, then use the same value in local_bridge\.env.
  notepad .env
  echo Save .env, then run run.bat again.
  pause
  exit /b 0
)
where py >nul 2>nul
if errorlevel 1 (
  echo Python launcher 'py' was not found. Install Python 3.11+ and enable PATH.
  pause
  exit /b 1
)
if not exist ".venv\Scripts\python.exe" (
  echo Creating Rainbow Corp application environment...
  py -3 -m venv .venv
  if errorlevel 1 goto :error
)
echo Installing Rainbow Corp application requirements...
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto :error
echo.
echo Rainbow Corp standalone application:
echo   Chatbot:      http://127.0.0.1:8000
echo   Data Console: http://127.0.0.1:8000/admin
echo   API docs:     http://127.0.0.1:8000/docs
echo   WebSocket:    ws://127.0.0.1:8000/ws/updates
echo.
echo This application only stores requests and exposes an integration API. It does not contain workflow-engine code or initiate refunds.
".venv\Scripts\python.exe" -m uvicorn main:app --host 127.0.0.1 --port 8000
if errorlevel 1 goto :error
exit /b 0
:error
echo.
echo Startup failed. Check the error above.
pause
