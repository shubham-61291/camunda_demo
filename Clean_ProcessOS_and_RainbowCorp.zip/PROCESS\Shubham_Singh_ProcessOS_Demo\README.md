# Shubham Singh ProcessOS Demo

ProcessOS is an independent local workflow-discovery and Camunda tool that runs on `127.0.0.1:8090`. Conversation starts with the business process, not a presumed company, codebase, or project path. ProcessOS does **not** rewrite any existing target application's UI, database files, API, bridge source, BPMN files, or `.env` files.

## ProcessOS environment: one required key

The only required variable in ProcessOS `.env` is:

```dotenv
OPENAI_API_KEY=your_openai_api_key
```

Model defaults to `gpt-4.1-nano` in code. Do not add endpoint URLs or target API credentials to ProcessOS `.env`.

## What is collected in the conversation

The discovery agent first clarifies the workflow in plain language, then collects relevant app/API URLs, authentication header names and values, WebSocket URLs, and business rules. It does not assume Rainbow Corp or ask for a local project path as its opening question. A project path is requested only when an existing local integration is selected and that deployment adapter actually needs it. When a URL arrives, ProcessOS probes it immediately. Authentication values are parsed and used locally; the model receives redacted chat text and probe results, not raw credentials. Credentials remain in the running ProcessOS session's memory and are not written to `blueprint.json`, generated code, or logs.

Build: processos-2026.10.14-audit6. The current bundled execution adapter supports the Rainbow Corp refund demo contract. That constraint is a deployment compatibility check, not a discovery assumption. The existing bridge is deliberately unmodified. Its installed contract specifically requires:

- App integration header: `X-Integration-Key`
- Action API header: `X-Demo-API-Key`
- Action endpoint: `/api/v1/refunds`
- Existing worker types: `register-human-review`, `execute-demo-refund`, `sync-refund-result`, `record-refund-rejection`

If discovery supplies a different header or an unrelated action API contract, ProcessOS explains the incompatibility and blocks deployment instead of changing the original app or bridge.

## Windows setup

1. Extract ProcessOS into its **own separate directory**. Do not extract it over the Rainbow project.
2. Run `run.bat`.
3. On first run, edit the created `.env` and set only `OPENAI_API_KEY`; run `run.bat` again.
4. Open `http://127.0.0.1:8090`.
5. In **Discover & Probe**, describe the desired workflow in plain language. Work through the trigger, rules, decisions, and outcome first; provide endpoints and credentials when asked or whenever you are ready to validate a URL. Do not provide a local project path unless you choose an existing local integration that requires it. Enter credentials only on your own local ProcessOS instance.
6. Click **Probe configured endpoints**. All seven checks must pass.
7. Click **Build & Verify**. The Coder/Tester loop has at most three iterations.
8. In **CLI Control**, click **Install / start Camunda** or authorize **Run CLI automation**. The runtime checks the local Camunda prerequisites, installs the official CLI if needed, starts the local cluster if not running, re-checks target endpoints, deploys the verified BPMN, and starts the original bridge process with the credentials from this conversation.

## Camunda local install behavior

ProcessOS uses the official `@camunda8/cli` package (`c8ctl` / `c8`). Current CLI documentation lists Node.js `>= 22.18.0`. The `c8ctl`-managed Camunda 8 Run distribution normally bundles a Java runtime; a system JDK is a fallback if that bundled runtime is absent or corrupted. ProcessOS does not silently replace/install Node.js. If Node.js is missing or unsupported, it stops and explains what is needed. Once Node prerequisites exist, ProcessOS installs the Camunda CLI with `npm install -g @camunda8/cli`, then runs `c8ctl cluster start` if the local cluster is not healthy.

Local Camunda REST endpoint: `http://127.0.0.1:8080/v2`. ProcessOS uses unauthenticated local development mode for this local cluster; it does not reuse Camunda Cloud/OAuth settings from the original bridge `.env`.

Official references:

- https://docs.camunda.io/docs/apis-tools/c8ctl/getting-started/
- https://github.com/camunda/c8ctl
- https://docs.camunda.io/build-with-camunda/

## CLI commands

Run these from the ProcessOS folder after Build & Verify passes and while the web app is running with the same in-memory discovery session:

```powershell
.\.venv\Scripts\python.exe .\generated_workflow\cli_orchestrator.py --self-test
.\.venv\Scripts\python.exe .\generated_workflow\cli_orchestrator.py --run --confirm --session-id processos-local-session
```

`--self-test` is offline-only and never installs/starts Camunda. `--run` requires `--confirm`, calls back to the local ProcessOS service, and executes using the active session context. If ProcessOS has restarted, credentials are no longer in memory; repeat discovery/probing before running again.

Bridge logs are written in ProcessOS `logs/rainbow_bridge.log`. The original Rainbow app remains on `127.0.0.1:8000`, the mock action API on `127.0.0.1:8001`, and local Camunda on `127.0.0.1:8080`.

## Safety and limitations

- The Coder's BPMN draft is checked deterministically. If it violates the existing Rainbow refund contract, ProcessOS repairs it from a fixed BPMN template and checks the repaired artifact before the Tester Agent audit. A failing gate still blocks deployment.
- The Python CLI is a trusted fixed entrypoint, not arbitrary Python generated by the model. Secrets and execution are brokered by the current local ProcessOS session.
- Discovery is phrased generically, but the bundled deployment/runtime adapter currently supports the specific Rainbow refund bridge contract. A different target must pass compatibility checks; ProcessOS will not silently alter the original application's code or invent a generic adapter.
- ProcessOS never sends a real refund POST as part of probing. It checks health/read endpoints and verifies the action route in OpenAPI.
- If a Rainbow bridge process is already running, ProcessOS refuses to launch a duplicate and asks you to stop the existing process manually before retrying.
- Camunda download/deployment requires internet access, adequate disk/RAM, compatible Node.js/Java, and permission to install the npm package. This container build has not been tested against your actual desktop Camunda runtime or live OpenAI key.
- Rainbow's supplied mock refund API simulates transactions; it does not move real money.

## Tests

```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements-dev.txt
.\.venv\Scripts\python.exe -m pytest -q
```
