from __future__ import annotations

import os
import sqlite3
import uuid
import hmac
import anyio
import hmac
from contextlib import asynccontextmanager, contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Literal

from fastapi import FastAPI, Header, HTTPException, Query, Response, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, EmailStr, Field, field_validator

BASE_DIR = Path(__file__).resolve().parent
try:
    from dotenv import load_dotenv
    load_dotenv(BASE_DIR / ".env")
except ImportError:
    pass
DB_PATH = Path(os.getenv("LOCAL_DB_PATH", str(BASE_DIR / "rainbow_refunds.db"))).expanduser()
APP_NAME = "Rainbow Corp Refund Assistant"
INTEGRATION_API_TOKEN = os.getenv("INTEGRATION_API_TOKEN", "").strip()

DEFAULT_PRODUCTS = [
    {"product_id": "PROD-001", "product_name": "Wireless Mouse", "standard_cost_inr": 1299.00, "description": "Standard wireless office mouse"},
    {"product_id": "PROD-002", "product_name": "Office Keyboard", "standard_cost_inr": 2499.00, "description": "Standard wired office keyboard"},
    {"product_id": "PROD-003", "product_name": "Studio Headphones", "standard_cost_inr": 4499.00, "description": "Standard over-ear headphones"},
    {"product_id": "PROD-004", "product_name": "24-inch Monitor", "standard_cost_inr": 12999.00, "description": "Standard 24-inch monitor"},
    {"product_id": "PROD-005", "product_name": "Smartphone Pro", "standard_cost_inr": 24999.00, "description": "Standard demo smartphone"},
]

DEFAULT_MASTER_RECORDS = [
    {"master_record_id": "MST-A50BE17007", "order_id": "ORD-1001", "customer_id": "CUST-1001", "customer_name": "Rahul Sharma", "customer_email": "rahul@example.com", "customer_phone": "", "product_id": "PROD-001", "product_name": "Wireless Mouse", "purchase_amount_inr": 1299.00, "bank_account_reference": "TXN-A1001", "bank_account_last4": "1234"},
    {"master_record_id": "MST-6E3B743460", "order_id": "ORD-1002", "customer_id": "CUST-1002", "customer_name": "Priya Verma", "customer_email": "priya@example.com", "customer_phone": "", "product_id": "PROD-002", "product_name": "Office Keyboard", "purchase_amount_inr": 2499.00, "bank_account_reference": "TXN-A1002", "bank_account_last4": "5678"},
    {"master_record_id": "MST-43300001C2", "order_id": "ORD-1003", "customer_id": "CUST-1003", "customer_name": "Amit Kumar", "customer_email": "amit@example.com", "customer_phone": "", "product_id": "PROD-003", "product_name": "Studio Headphones", "purchase_amount_inr": 4499.00, "bank_account_reference": "TXN-A1003", "bank_account_last4": "9012"},
    {"master_record_id": "MST-33BA85CB87", "order_id": "ORD-1004", "customer_id": "CUST-1004", "customer_name": "Neha Singh", "customer_email": "neha@example.com", "customer_phone": "", "product_id": "PROD-004", "product_name": "24-inch Monitor", "purchase_amount_inr": 12999.00, "bank_account_reference": "TXN-A1004", "bank_account_last4": "3456"},
    {"master_record_id": "MST-A31B562A19", "order_id": "ORD-1005", "customer_id": "CUST-1005", "customer_name": "Vikram Patel", "customer_email": "vikram@example.com", "customer_phone": "", "product_id": "PROD-005", "product_name": "Smartphone Pro", "purchase_amount_inr": 24999.00, "bank_account_reference": "TXN-A1005", "bank_account_last4": "7890"},
    {"master_record_id": "MST-B006A1C2D3", "order_id": "ORD-1006", "customer_id": "CUST-1006", "customer_name": "Rajesh Khanna", "customer_email": "rajesh@example.com", "customer_phone": "+91 98765 43210", "product_id": "PROD-001", "product_name": "Wireless Mouse", "purchase_amount_inr": 1299.00, "bank_account_reference": "TXN-A1006", "bank_account_last4": "1122"},
    {"master_record_id": "MST-B007A1C2D3", "order_id": "ORD-1007", "customer_id": "CUST-1007", "customer_name": "Sunita Rao", "customer_email": "sunita@example.com", "customer_phone": "+91 98765 43211", "product_id": "PROD-002", "product_name": "Office Keyboard", "purchase_amount_inr": 2499.00, "bank_account_reference": "TXN-A1007", "bank_account_last4": "3344"},
    {"master_record_id": "MST-B008A1C2D3", "order_id": "ORD-1008", "customer_id": "CUST-1008", "customer_name": "Manoj Bajpayee", "customer_email": "manoj@example.com", "customer_phone": "+91 98765 43212", "product_id": "PROD-003", "product_name": "Studio Headphones", "purchase_amount_inr": 4499.00, "bank_account_reference": "TXN-A1008", "bank_account_last4": "5566"},
    {"master_record_id": "MST-B009A1C2D3", "order_id": "ORD-1009", "customer_id": "CUST-1009", "customer_name": "Deepika Padukone", "customer_email": "deepika@example.com", "customer_phone": "+91 98765 43213", "product_id": "PROD-004", "product_name": "24-inch Monitor", "purchase_amount_inr": 12999.00, "bank_account_reference": "TXN-A1009", "bank_account_last4": "7788"},
    {"master_record_id": "MST-B010A1C2D3", "order_id": "ORD-1010", "customer_id": "CUST-1010", "customer_name": "Arjun Kapoor", "customer_email": "arjun@example.com", "customer_phone": "+91 98765 43214", "product_id": "PROD-005", "product_name": "Smartphone Pro", "purchase_amount_inr": 24999.00, "bank_account_reference": "TXN-A1010", "bank_account_last4": "9900"},
    {"master_record_id": "MST-B011A1C2D3", "order_id": "ORD-1011", "customer_id": "CUST-1011", "customer_name": "Pooja Hegde", "customer_email": "pooja@example.com", "customer_phone": "+91 98765 43215", "product_id": "PROD-001", "product_name": "Wireless Mouse", "purchase_amount_inr": 1299.00, "bank_account_reference": "TXN-A1011", "bank_account_last4": "1357"},
    {"master_record_id": "MST-B012A1C2D3", "order_id": "ORD-1012", "customer_id": "CUST-1012", "customer_name": "Suresh Raina", "customer_email": "suresh@example.com", "customer_phone": "+91 98765 43216", "product_id": "PROD-002", "product_name": "Office Keyboard", "purchase_amount_inr": 2499.00, "bank_account_reference": "TXN-A1012", "bank_account_last4": "2468"},
    {"master_record_id": "MST-B013A1C2D3", "order_id": "ORD-1013", "customer_id": "CUST-1013", "customer_name": "Ananya Panday", "customer_email": "ananya@example.com", "customer_phone": "+91 98765 43217", "product_id": "PROD-003", "product_name": "Studio Headphones", "purchase_amount_inr": 4499.00, "bank_account_reference": "TXN-A1013", "bank_account_last4": "3579"},
    {"master_record_id": "MST-B014A1C2D3", "order_id": "ORD-1014", "customer_id": "CUST-1014", "customer_name": "Rohit Sharma", "customer_email": "rohit@example.com", "customer_phone": "+91 98765 43218", "product_id": "PROD-004", "product_name": "24-inch Monitor", "purchase_amount_inr": 12999.00, "bank_account_reference": "TXN-A1014", "bank_account_last4": "4680"},
    {"master_record_id": "MST-B015A1C2D3", "order_id": "ORD-1015", "customer_id": "CUST-1015", "customer_name": "Kavita Krishnan", "customer_email": "kavita@example.com", "customer_phone": "+91 98765 43219", "product_id": "PROD-005", "product_name": "Smartphone Pro", "purchase_amount_inr": 24999.00, "bank_account_reference": "TXN-A1015", "bank_account_last4": "5791"},
]

@asynccontextmanager
async def app_lifespan(_app: FastAPI):
    init_db()
    yield


app = FastAPI(title=APP_NAME, version="2.1.0-verified-local-integration-api", lifespan=app_lifespan)
app.mount("/static", StaticFiles(directory=BASE_DIR / "static"), name="static")


class WebSocketManager:
    def __init__(self) -> None:
        self.connections: set[WebSocket] = set()

    async def connect(self, websocket: WebSocket) -> None:
        await websocket.accept()
        self.connections.add(websocket)

    def disconnect(self, websocket: WebSocket) -> None:
        self.connections.discard(websocket)

    async def broadcast(self, event: dict[str, Any]) -> None:
        dead: list[WebSocket] = []
        for websocket in list(self.connections):
            try:
                await websocket.send_json(event)
            except Exception:
                dead.append(websocket)
        for websocket in dead:
            self.disconnect(websocket)


ws_manager = WebSocketManager()


def publish_update(entity: str, entity_id: str, action: str) -> None:
    """Broadcast a lightweight update to browser sessions without coupling to an external workflow."""
    event = {"type": "data_changed", "entity": entity, "entity_id": entity_id, "action": action, "timestamp": now_iso()}
    try:
        anyio.from_thread.run(ws_manager.broadcast, event)
    except Exception:
        # Called at startup or outside an async request context; DB operations still succeed.
        pass


def require_integration_token(token: str) -> None:
    if not INTEGRATION_API_TOKEN:
        raise HTTPException(status_code=503, detail="Integration authentication is not configured. Set INTEGRATION_API_TOKEN in rainbow_corp_app/.env and local_bridge/.env.")
    if not hmac.compare_digest(str(token or ""), INTEGRATION_API_TOKEN):
        raise HTTPException(status_code=401, detail="Invalid integration token.")


def now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


@contextmanager
def db_connection():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH, timeout=15)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA journal_mode = WAL")
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def log_activity(
    conn: sqlite3.Connection,
    entity_table: str,
    entity_id: str,
    action: str,
    summary: str,
    changed_by: str = "system",
) -> None:
    conn.execute(
        """INSERT INTO activity_log
           (entity_table, entity_id, action, summary, changed_by, created_at)
           VALUES (?, ?, ?, ?, ?, ?)""",
        (entity_table, entity_id, action, summary, changed_by, now_iso()),
    )


def init_db() -> None:
    with db_connection() as conn:
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS product_customer_master (
                master_record_id TEXT PRIMARY KEY,
                order_id TEXT NOT NULL,
                customer_id TEXT NOT NULL DEFAULT '',
                customer_name TEXT NOT NULL DEFAULT '',
                customer_email TEXT NOT NULL DEFAULT '',
                customer_phone TEXT NOT NULL DEFAULT '',
                product_id TEXT NOT NULL DEFAULT '',
                product_name TEXT NOT NULL DEFAULT '',
                product_image_url TEXT NOT NULL DEFAULT '',
                purchase_date TEXT NOT NULL DEFAULT '',
                purchase_amount_inr REAL NOT NULL DEFAULT 0,
                bank_account_reference TEXT NOT NULL DEFAULT '',
                bank_account_last4 TEXT NOT NULL DEFAULT '',
                record_status TEXT NOT NULL DEFAULT 'Active',
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );

            CREATE INDEX IF NOT EXISTS idx_master_order_id
                ON product_customer_master(order_id);
            CREATE INDEX IF NOT EXISTS idx_master_customer_id
                ON product_customer_master(customer_id);

            CREATE TABLE IF NOT EXISTS refund_requests (
                request_id TEXT PRIMARY KEY,
                source TEXT NOT NULL DEFAULT 'Website Chatbot',
                conversation_id TEXT NOT NULL DEFAULT '',
                customer_id TEXT NOT NULL DEFAULT '',
                customer_name TEXT NOT NULL,
                customer_email TEXT NOT NULL,
                order_id TEXT NOT NULL,
                product_id TEXT NOT NULL DEFAULT '',
                product TEXT NOT NULL,
                refund_amount REAL NOT NULL,
                reason TEXT NOT NULL,
                customer_notes TEXT NOT NULL DEFAULT '',
                evidence_url TEXT NOT NULL DEFAULT '',
                status TEXT NOT NULL,
                status_notes TEXT NOT NULL DEFAULT '',
                latest_customer_update TEXT NOT NULL DEFAULT '',
                human_review_required INTEGER NOT NULL DEFAULT 0,
                human_approved INTEGER NOT NULL DEFAULT 0,
                reviewer_id TEXT NOT NULL DEFAULT '',
                reviewer_decision TEXT NOT NULL DEFAULT 'Pending',
                reviewer_comments TEXT NOT NULL DEFAULT '',
                reviewed_at TEXT NOT NULL DEFAULT '',
                workflow_reference TEXT NOT NULL DEFAULT '',
                workflow_dispatch_status TEXT NOT NULL DEFAULT 'Queued',
                workflow_dispatch_claimed_at TEXT NOT NULL DEFAULT '',
                workflow_dispatch_attempts INTEGER NOT NULL DEFAULT 0,
                workflow_dispatched_at TEXT NOT NULL DEFAULT '',
                workflow_error TEXT NOT NULL DEFAULT '',
                refund_transaction_id TEXT NOT NULL DEFAULT '',
                final_outcome TEXT NOT NULL DEFAULT '',
                failure_reason TEXT NOT NULL DEFAULT '',
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );

            CREATE INDEX IF NOT EXISTS idx_refunds_email
                ON refund_requests(customer_email);
            CREATE INDEX IF NOT EXISTS idx_refunds_order_id
                ON refund_requests(order_id);
            CREATE INDEX IF NOT EXISTS idx_refunds_status
                ON refund_requests(status);

            CREATE TABLE IF NOT EXISTS human_review_queue (
                review_id TEXT PRIMARY KEY,
                request_id TEXT NOT NULL UNIQUE REFERENCES refund_requests(request_id) ON DELETE CASCADE,
                review_reason TEXT NOT NULL,
                approval_checkbox INTEGER NOT NULL DEFAULT 0,
                reviewer_id TEXT NOT NULL DEFAULT '',
                reviewer_decision TEXT NOT NULL DEFAULT 'Pending',
                reviewer_comments TEXT NOT NULL DEFAULT '',
                review_status TEXT NOT NULL DEFAULT 'Pending Review',
                workflow_event_status TEXT NOT NULL DEFAULT 'Not Applicable',
                workflow_event_dispatched_at TEXT NOT NULL DEFAULT '',
                reviewed_at TEXT NOT NULL DEFAULT '',
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS standard_products (
                product_id TEXT PRIMARY KEY,
                product_name TEXT NOT NULL,
                standard_cost_inr REAL NOT NULL CHECK (standard_cost_inr > 0),
                description TEXT NOT NULL DEFAULT '',
                active INTEGER NOT NULL DEFAULT 1,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS activity_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                entity_table TEXT NOT NULL,
                entity_id TEXT NOT NULL,
                action TEXT NOT NULL,
                summary TEXT NOT NULL,
                changed_by TEXT NOT NULL DEFAULT 'system',
                created_at TEXT NOT NULL
            );

            CREATE INDEX IF NOT EXISTS idx_activity_created_at
                ON activity_log(created_at DESC);
            """
        )
        # Safe additive migrations for databases created by earlier local demo versions.
        refund_columns = {row[1] for row in conn.execute("PRAGMA table_info(refund_requests)").fetchall()}
        refund_migrations = {
            "workflow_reference": "TEXT NOT NULL DEFAULT ''",
            "workflow_dispatch_status": "TEXT NOT NULL DEFAULT 'Queued'",
            "workflow_dispatch_claimed_at": "TEXT NOT NULL DEFAULT ''",
            "workflow_dispatch_attempts": "INTEGER NOT NULL DEFAULT 0",
            "workflow_dispatched_at": "TEXT NOT NULL DEFAULT ''",
            "workflow_error": "TEXT NOT NULL DEFAULT ''",
        }
        dispatch_column_was_missing = "workflow_dispatch_status" not in refund_columns
        for column, sql_type in refund_migrations.items():
            if column not in refund_columns:
                conn.execute(f"ALTER TABLE refund_requests ADD COLUMN {column} {sql_type}")
        if dispatch_column_was_missing:
            # Existing test records must never be silently re-dispatched on app upgrade.
            conn.execute(
                """UPDATE refund_requests SET workflow_dispatch_status = 'Archived',
                   workflow_error = 'Pre-existing local demo record; not automatically dispatched during migration.'
                   WHERE status != 'Queued for Workflow'"""
            )
        review_columns = {row[1] for row in conn.execute("PRAGMA table_info(human_review_queue)").fetchall()}
        review_migrations = {
            "workflow_event_status": "TEXT NOT NULL DEFAULT 'Not Applicable'",
            "workflow_event_dispatched_at": "TEXT NOT NULL DEFAULT ''",
        }
        for column, sql_type in review_migrations.items():
            if column not in review_columns:
                conn.execute(f"ALTER TABLE human_review_queue ADD COLUMN {column} {sql_type}")
        count = conn.execute("SELECT COUNT(*) FROM standard_products").fetchone()[0]
        if count == 0:
            timestamp = now_iso()
            for product in DEFAULT_PRODUCTS:
                conn.execute(
                    """INSERT INTO standard_products
                       (product_id, product_name, standard_cost_inr, description, active, created_at, updated_at)
                       VALUES (?, ?, ?, ?, 1, ?, ?)""",
                    (product["product_id"], product["product_name"], product["standard_cost_inr"], product["description"], timestamp, timestamp),
                )
            log_activity(conn, "standard_products", "catalog", "PRODUCT_CATALOG_SEEDED", "Seeded five standard demo products: three below ₹5,000 and two above ₹5,000.")
        master_count = conn.execute("SELECT COUNT(*) FROM product_customer_master").fetchone()[0]
        if master_count == 0:
            timestamp = now_iso()
            for rec in DEFAULT_MASTER_RECORDS:
                conn.execute(
                    """INSERT INTO product_customer_master
                       (master_record_id, order_id, customer_id, customer_name, customer_email, customer_phone,
                        product_id, product_name, product_image_url, purchase_date, purchase_amount_inr,
                        bank_account_reference, bank_account_last4, record_status, created_at, updated_at)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, '', '2026-10-01', ?, ?, ?, 'Active', ?, ?)""",
                    (rec["master_record_id"], rec["order_id"], rec["customer_id"], rec["customer_name"],
                     rec["customer_email"], rec["customer_phone"], rec["product_id"], rec["product_name"],
                     rec["purchase_amount_inr"], rec["bank_account_reference"], rec["bank_account_last4"],
                     timestamp, timestamp)
                )
            log_activity(conn, "product_customer_master", "catalog", "MASTER_RECORDS_SEEDED", "Seeded 15 standard customer and order master records.")


class CreateRequest(BaseModel):
    customer_name: str = Field(min_length=2, max_length=120)
    customer_email: EmailStr
    order_id: str = Field(min_length=1, max_length=100)
    product_id: str = Field(default="", max_length=50)
    product: str = Field(default="", max_length=150)
    # When product_id is supplied, the server ignores client price and reads the
    # standard cost from SQLite. The optional amount preserves the older API contract.
    refund_amount: float | None = Field(default=None, gt=0, le=10_000_000)
    reason: str = Field(min_length=3, max_length=2000)

    @field_validator("customer_name", "order_id", "reason")
    @classmethod
    def strip_required_text(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("This field cannot be blank.")
        return value

    @field_validator("product_id", "product")
    @classmethod
    def strip_product_text(cls, value: str) -> str:
        return value.strip()


class LookupRequest(BaseModel):
    customer_email: EmailStr


class OrderLookupRequest(BaseModel):
    order_id: str = Field(min_length=1, max_length=100)
    customer_email: EmailStr

    @field_validator("order_id")
    @classmethod
    def strip_order_id(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("Please enter the order ID.")
        return value


class AddInformationRequest(BaseModel):
    customer_email: EmailStr
    message: str = Field(min_length=3, max_length=2000)

    @field_validator("message")
    @classmethod
    def strip_message(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("Please enter the additional information.")
        return value


class MasterRecordCreate(BaseModel):
    order_id: str = Field(min_length=1, max_length=100)
    customer_id: str = Field(default="", max_length=100)
    customer_name: str = Field(default="", max_length=120)
    customer_email: str = Field(default="", max_length=254)
    customer_phone: str = Field(default="", max_length=40)
    product_id: str = Field(default="", max_length=100)
    product_name: str = Field(default="", max_length=150)
    product_image_url: str = Field(default="", max_length=1000)
    purchase_date: str = Field(default="", max_length=30)
    purchase_amount_inr: float = Field(default=0, ge=0, le=100_000_000)
    bank_account_reference: str = Field(default="", max_length=200)
    bank_account_last4: str = Field(default="", max_length=4)
    record_status: Literal["Active", "Inactive", "Needs Verification"] = "Active"

    @field_validator(
        "order_id", "customer_id", "customer_name", "customer_email", "customer_phone",
        "product_id", "product_name", "product_image_url", "purchase_date",
        "bank_account_reference", "bank_account_last4",
    )
    @classmethod
    def trim_optional_text(cls, value: str) -> str:
        return value.strip()

    @field_validator("bank_account_last4")
    @classmethod
    def validate_last4(cls, value: str) -> str:
        if value and (len(value) != 4 or not value.isdigit()):
            raise ValueError("Bank account last four must be exactly four digits.")
        return value

    @field_validator("customer_email")
    @classmethod
    def validate_email_if_supplied(cls, value: str) -> str:
        if value and ("@" not in value or "." not in value.split("@")[-1]):
            raise ValueError("Enter a valid email address or leave it blank.")
        return value.lower()

    @field_validator("product_image_url")
    @classmethod
    def validate_image_url(cls, value: str) -> str:
        if value and not value.lower().startswith(("https://", "http://")):
            raise ValueError("Product image URL must start with http:// or https://.")
        return value


class ReviewUpdate(BaseModel):
    decision: Literal["approve", "reject", "pending"]
    reviewer_id: str = Field(min_length=2, max_length=120)
    comments: str = Field(default="", max_length=2000)

    @field_validator("reviewer_id", "comments")
    @classmethod
    def trim_text(cls, value: str) -> str:
        return value.strip()


class WipeDataRequest(BaseModel):
    confirmation: str = Field(min_length=1, max_length=100)
    changed_by: str = Field(default="local admin", max_length=120)

    @field_validator("confirmation", "changed_by")
    @classmethod
    def trim_wipe_text(cls, value: str) -> str:
        return value.strip()


class DispatchResult(BaseModel):
    outcome: Literal["STARTED", "FAILED", "UNKNOWN"]
    workflow_reference: str = Field(default="", max_length=200)
    error: str = Field(default="", max_length=1500)

    @field_validator("workflow_reference", "error")
    @classmethod
    def strip_dispatch_text(cls, value: str) -> str:
        return value.strip()


class ManualRequeueRequest(BaseModel):
    confirmation: str = Field(min_length=1, max_length=100)

    @field_validator("confirmation")
    @classmethod
    def trim_confirmation(cls, value: str) -> str:
        return value.strip()


class ReviewRequiredFromWorkflow(BaseModel):
    review_reason: str = Field(default="Workflow selected human review", max_length=500)

    @field_validator("review_reason")
    @classmethod
    def strip_review_reason(cls, value: str) -> str:
        return value.strip()


class WorkflowResult(BaseModel):
    status: Literal["SUCCESS", "FAILED", "REJECTED"]
    transaction_id: str = Field(default="", max_length=150)
    message: str = Field(default="", max_length=2000)
    workflow_reference: str = Field(default="", max_length=200)

    @field_validator("transaction_id", "message", "workflow_reference")
    @classmethod
    def strip_result_text(cls, value: str) -> str:
        return value.strip()


def normalize_email(email: str) -> str:
    return email.strip().lower()


def make_id(prefix: str) -> str:
    return prefix + "-" + uuid.uuid4().hex[:10].upper()


def row_dict(row: sqlite3.Row | None) -> dict[str, Any] | None:
    return dict(row) if row else None


def public_request(row: sqlite3.Row | dict[str, Any]) -> dict[str, Any]:
    result = dict(row)
    result["refund_amount"] = float(result.get("refund_amount", 0) or 0)
    result["human_review_required"] = bool(result.get("human_review_required", 0))
    result["human_approved"] = bool(result.get("human_approved", 0))
    return result


def public_product(row: sqlite3.Row | dict[str, Any]) -> dict[str, Any]:
    result = dict(row)
    result["standard_cost_inr"] = float(result.get("standard_cost_inr", 0) or 0)
    result["active"] = bool(result.get("active", 0))
    return result


@app.get("/")
def index() -> FileResponse:
    return FileResponse(BASE_DIR / "static" / "index.html", headers={"Cache-Control": "no-cache, no-store, must-revalidate"})


@app.get("/admin")
def admin_page() -> FileResponse:
    return FileResponse(BASE_DIR / "static" / "admin.html", headers={"Cache-Control": "no-cache, no-store, must-revalidate"})


@app.get("/api/health")
def health() -> dict[str, Any]:
    with db_connection() as conn:
        total = conn.execute("SELECT COUNT(*) FROM refund_requests").fetchone()[0]
        queued = conn.execute("SELECT COUNT(*) FROM refund_requests WHERE workflow_dispatch_status IN ('Queued', 'Retry')").fetchone()[0]
        running = conn.execute("SELECT COUNT(*) FROM refund_requests WHERE workflow_dispatch_status = 'Dispatched'").fetchone()[0]
    return {
        "app_name": APP_NAME,
        "storage_mode": "local_sqlite",
        "database": "Rainbow Corp local database",
        "refund_request_count": total,
        "workflow_queue_count": queued,
        "workflow_dispatched_count": running,
        "workflow_integration": "standalone API; separate bridge required",
        "refund_execution_inside_app": False,
        "status": "ok",
    }


@app.get("/api/products")
def products() -> dict[str, Any]:
    with db_connection() as conn:
        rows = conn.execute("SELECT * FROM standard_products WHERE active = 1 ORDER BY product_id").fetchall()
    return {"products": [public_product(row) for row in rows], "count": len(rows)}


@app.get("/api/admin/products")
def admin_products() -> dict[str, Any]:
    with db_connection() as conn:
        rows = conn.execute("SELECT * FROM standard_products ORDER BY product_id").fetchall()
    return {"records": [public_product(row) for row in rows], "count": len(rows)}


@app.post("/api/requests", status_code=201)
def create_request(body: CreateRequest, response: Response) -> dict[str, Any]:
    """Store a refund request and queue it for the separately deployed workflow bridge.

    This application never makes approval-routing decisions or invokes the refund API.
    """
    normalized_order_id = body.order_id.strip().lower()
    normalized_email = normalize_email(str(body.customer_email))
    created = now_iso()
    with db_connection() as conn:
        conn.execute("BEGIN IMMEDIATE")
        product_record = None
        if body.product_id:
            product_record = conn.execute(
                "SELECT * FROM standard_products WHERE product_id = ? AND active = 1",
                (body.product_id.strip(),),
            ).fetchone()
            if not product_record:
                raise HTTPException(status_code=422, detail="Select one of the five active standard products.")
            product_name = product_record["product_name"]
            amount = round(float(product_record["standard_cost_inr"]), 2)
            product_id = product_record["product_id"]
        else:
            product_name = body.product.strip()
            if not product_name or body.refund_amount is None:
                raise HTTPException(status_code=422, detail="A standard product must be selected.")
            amount = round(float(body.refund_amount), 2)
            product_id = ""

        # Verify the claim against the registered order/customer master before queueing.
        master = conn.execute(
            """SELECT * FROM product_customer_master
               WHERE lower(trim(order_id)) = ?
                 AND lower(trim(customer_email)) = ?
                 AND record_status = 'Active'
               ORDER BY updated_at DESC LIMIT 1""",
            (normalized_order_id, normalized_email),
        ).fetchone()
        if not master:
            raise HTTPException(status_code=422, detail="We could not verify this order ID and email against an active registered customer order. Contact support or ask the admin to check the order master record.")
        registered_product_id = str(master["product_id"] or "").strip()
        registered_product_name = str(master["product_name"] or "").strip().casefold()
        requested_product_name = product_name.strip().casefold()
        if registered_product_name and requested_product_name and registered_product_name != requested_product_name:
            raise HTTPException(status_code=422, detail="The selected product does not match the registered order record.")
        if registered_product_id and product_id and registered_product_id != product_id:
            num_reg = re.sub(r"\D", "", registered_product_id)
            num_req = re.sub(r"\D", "", product_id)
            is_compatible = (
                (registered_product_name and registered_product_name == requested_product_name)
                or (num_reg and num_req and (num_reg.endswith(num_req) or num_req.endswith(num_reg)))
            )
            if not is_compatible:
                raise HTTPException(status_code=422, detail="The selected product does not match the registered order record.")
        purchase_amount = float(master["purchase_amount_inr"] or 0)
        if purchase_amount <= 0:
            raise HTTPException(status_code=422, detail="The registered order has no verified purchase amount. Ask the admin to update its customer master record.")
        if amount > round(purchase_amount, 2):
            raise HTTPException(status_code=422, detail="The refund amount cannot exceed the verified purchase amount for this order.")

        existing = conn.execute(
            """SELECT * FROM refund_requests
               WHERE lower(trim(order_id)) = ?
                 AND lower(trim(customer_email)) = ?
                 AND ROUND(refund_amount, 2) = ?
                 AND status NOT IN ('Refund API Failed - Retry Required', 'Rejected by Human', 'Workflow Dispatch Permanently Failed')
               ORDER BY created_at ASC LIMIT 1""",
            (normalized_order_id, normalized_email, amount),
        ).fetchone()
        if existing:
            existing_request = public_request(existing)
            log_activity(
                conn, "refund_requests", existing_request["request_id"], "DUPLICATE_REQUEST_BLOCKED",
                f"Duplicate submission blocked for order {body.order_id.strip()} and amount ₹{amount:.2f}; existing request {existing_request['request_id']} retained.",
                "system",
            )
            response.status_code = 200
            publish_update("refund_requests", existing_request["request_id"], "DUPLICATE_REQUEST_BLOCKED")
            return {
                "duplicate": True,
                "message": "A refund request already exists for this order ID, registered email and amount. No duplicate was created.",
                "request": existing_request,
                "storage_mode": "local_sqlite",
            }

        request_id = make_id("RBC")
        conversation_id = make_id("CONV")
        status = "Queued for Workflow"
        notes = "Request saved locally. Waiting for the separate workflow bridge to pick it up. No routing decision or refund has occurred yet."
        conn.execute(
            """INSERT INTO refund_requests (
                request_id, source, conversation_id, customer_name, customer_email,
                order_id, product_id, product, refund_amount, reason, status, status_notes,
                human_review_required, human_approved, reviewer_decision, workflow_dispatch_status,
                created_at, updated_at
            ) VALUES (?, 'Website Chatbot', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, 0, 'Pending', 'Queued', ?, ?)""",
            (
                request_id, conversation_id, body.customer_name.strip(), normalized_email,
                body.order_id.strip(), product_id, product_name, amount, body.reason.strip(),
                status, notes, created, created,
            ),
        )
        log_activity(conn, "refund_requests", request_id, "REQUEST_CREATED", f"Refund request created for order {body.order_id.strip()}; {product_name}; amount ₹{amount:.2f}. Awaiting workflow orchestration.")
        row = conn.execute("SELECT * FROM refund_requests WHERE request_id = ?", (request_id,)).fetchone()
        new_request = public_request(row)
    publish_update("refund_requests", request_id, "REQUEST_CREATED")
    return {"duplicate": False, "request": new_request, "storage_mode": "local_sqlite", "workflow": {"queued": True, "message": "Saved locally; awaiting the separate workflow bridge."}}


@app.post("/api/requests/lookup")
def lookup_requests_by_order(body: OrderLookupRequest) -> dict[str, Any]:
    """Find refund requests using the order ID customers already have and their registered email."""
    order_id = body.order_id.strip()
    email = normalize_email(str(body.customer_email))
    with db_connection() as conn:
        rows = conn.execute(
            """SELECT * FROM refund_requests
               WHERE lower(trim(order_id)) = lower(?)
                 AND lower(trim(customer_email)) = lower(?)
               ORDER BY created_at DESC LIMIT 20""",
            (order_id, email),
        ).fetchall()
    if not rows:
        raise HTTPException(
            status_code=404,
            detail="No refund request was found for that order ID and registered email. Check both details and try again.",
        )
    requests = [public_request(row) for row in rows]
    return {"requests": requests, "count": len(requests), "storage_mode": "local_sqlite"}


@app.post("/api/requests/{request_id}/lookup")
def lookup_request(request_id: str, body: LookupRequest) -> dict[str, Any]:
    with db_connection() as conn:
        row = conn.execute(
            "SELECT * FROM refund_requests WHERE request_id = ? AND lower(customer_email) = lower(?)",
            (request_id.strip(), normalize_email(str(body.customer_email))),
        ).fetchone()
    if not row:
        raise HTTPException(status_code=404, detail="No matching request was found. Check the request ID and registered email.")
    return {"request": public_request(row), "storage_mode": "local_sqlite"}


@app.post("/api/requests/{request_id}/information")
def add_information(request_id: str, body: AddInformationRequest) -> dict[str, Any]:
    email = normalize_email(str(body.customer_email))
    timestamp = now_iso()
    message = body.message.strip()
    with db_connection() as conn:
        row = conn.execute(
            "SELECT * FROM refund_requests WHERE request_id = ? AND lower(customer_email) = lower(?)",
            (request_id.strip(), email),
        ).fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="No matching request was found. Check the request ID and registered email.")
        if str(row["status"]).lower() in {"completed", "rejected by human", "cancelled", "failed"}:
            raise HTTPException(status_code=409, detail="This request is closed, so additional information cannot be added.")
        combined = f"{row['latest_customer_update']}\n[{timestamp}] {message}".strip()
        conn.execute(
            "UPDATE refund_requests SET latest_customer_update = ?, updated_at = ? WHERE request_id = ?",
            (combined, timestamp, request_id.strip()),
        )
        log_activity(conn, "refund_requests", request_id.strip(), "CUSTOMER_UPDATE_ADDED", "Customer added information to the request.", "customer")
        updated = conn.execute("SELECT * FROM refund_requests WHERE request_id = ?", (request_id.strip(),)).fetchone()
    publish_update("refund_requests", request_id.strip(), "CUSTOMER_UPDATE_ADDED")
    return {"request": public_request(updated), "storage_mode": "local_sqlite"}


# ----- Generic integration API for an external workflow bridge -----
# This app exposes contracts only. Workflow orchestration and refund API calls run elsewhere.


def verify_integration(x_integration_key: str) -> None:
    require_integration_token(x_integration_key)


@app.get("/api/integration/health")
def integration_health(x_integration_key: str = Header(default="", alias="X-Integration-Key")) -> dict[str, Any]:
    verify_integration(x_integration_key)
    with db_connection() as conn:
        queued = conn.execute("SELECT COUNT(*) FROM refund_requests WHERE workflow_dispatch_status IN ('Queued', 'Retry')").fetchone()[0]
        dispatched = conn.execute("SELECT COUNT(*) FROM refund_requests WHERE workflow_dispatch_status = 'Dispatched'").fetchone()[0]
        pending_decisions = conn.execute("SELECT COUNT(*) FROM human_review_queue WHERE workflow_event_status = 'Pending'").fetchone()[0]
    return {"ok": True, "queued_requests": queued, "dispatched_requests": dispatched, "pending_review_decisions": pending_decisions}


@app.get("/api/integration/requests/pending")
def integration_pending_requests(
    limit: int = Query(default=100, ge=1, le=500),
    x_integration_key: str = Header(default="", alias="X-Integration-Key"),
) -> dict[str, Any]:
    verify_integration(x_integration_key)
    with db_connection() as conn:
        rows = conn.execute(
            """SELECT * FROM refund_requests
               WHERE workflow_dispatch_status IN ('Queued', 'Retry')
               ORDER BY created_at ASC LIMIT ?""",
            (limit,),
        ).fetchall()
    records = [public_request(row) for row in rows]
    return {"records": records, "count": len(records)}


@app.post("/api/integration/requests/{request_id}/claim")
def integration_claim_request(
    request_id: str,
    x_integration_key: str = Header(default="", alias="X-Integration-Key"),
) -> dict[str, Any]:
    verify_integration(x_integration_key)
    timestamp = now_iso()
    with db_connection() as conn:
        row = conn.execute("SELECT * FROM refund_requests WHERE request_id = ?", (request_id,)).fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="Refund request not found.")
        if row["workflow_dispatch_status"] == "Dispatched" and row["workflow_reference"]:
            return {"claimed": False, "already_dispatched": True, "request": public_request(row)}
        if row["workflow_dispatch_status"] not in {"Queued", "Retry"}:
            raise HTTPException(status_code=409, detail=f"Request cannot be claimed from state {row['workflow_dispatch_status']}. Unknown/dispatching starts require an explicit admin requeue after checking Camunda.")
        conn.execute(
            "UPDATE refund_requests SET workflow_dispatch_status = 'Dispatching', workflow_dispatch_attempts = workflow_dispatch_attempts + 1, workflow_dispatch_claimed_at = ?, workflow_error = '', updated_at = ? WHERE request_id = ?",
            (timestamp, timestamp, request_id),
        )
        if row["status"] in {"Queued for Workflow", "Workflow Dispatch Failed"}:
            conn.execute("UPDATE refund_requests SET status = 'Workflow Dispatching', status_notes = ?, updated_at = ? WHERE request_id = ?", ("The external workflow bridge claimed this request. No refund is executed by this application.", timestamp, request_id))
        log_activity(conn, "refund_requests", request_id, "WORKFLOW_DISPATCH_CLAIMED", "External workflow bridge claimed the request for dispatch.", "integration bridge")
        updated = conn.execute("SELECT * FROM refund_requests WHERE request_id = ?", (request_id,)).fetchone()
    publish_update("refund_requests", request_id, "WORKFLOW_DISPATCH_CLAIMED")
    return {"claimed": True, "request": public_request(updated)}


@app.post("/api/integration/requests/{request_id}/dispatch-result")
def integration_dispatch_result(
    request_id: str,
    body: DispatchResult,
    x_integration_key: str = Header(default="", alias="X-Integration-Key"),
) -> dict[str, Any]:
    verify_integration(x_integration_key)
    timestamp = now_iso()
    if body.outcome == "STARTED":
        dispatch_status = "Dispatched"
        new_status = "Workflow Running"
        note = "The external workflow engine accepted the request. Routing and refund execution are owned by that workflow."
        error = ""
        workflow_reference = body.workflow_reference
        if not workflow_reference:
            raise HTTPException(status_code=422, detail="workflow_reference is required when outcome is STARTED.")
    elif body.outcome == "FAILED":
        dispatch_status = "Retry"
        new_status = "Workflow Dispatch Failed"
        note = body.error or "The external workflow engine rejected the process start. The request is queued for retry."
        error = body.error[:1500]
        workflow_reference = ""
    else:
        dispatch_status = "Unknown"
        new_status = "Workflow Start Outcome Unknown"
        note = body.error or "The connection ended before the workflow-start outcome could be confirmed. Verify the external engine before retrying to avoid a duplicate process."
        error = body.error[:1500]
        workflow_reference = ""
    with db_connection() as conn:
        row = conn.execute("SELECT * FROM refund_requests WHERE request_id = ?", (request_id,)).fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="Refund request not found.")
        if row["status"] == "Refund Completed (Demo)" and body.outcome in {"FAILED", "UNKNOWN"}:
            raise HTTPException(status_code=409, detail="A confirmed successful workflow result cannot be overwritten by a failed or unknown dispatch response.")
        # A known start failure may retry only a bounded number of times. An
        # unknown outcome is never retried automatically because Camunda may have started it.
        if body.outcome == "FAILED" and int(row["workflow_dispatch_attempts"] or 0) >= 3:
            dispatch_status = "Failed"
            new_status = "Workflow Dispatch Permanently Failed"
            note = (body.error or "Workflow start failed.") + " Automatic start retries exhausted after 3 attempts."
            error = note[:1500]
        # Never overwrite a status written by a fast-running workflow callback.
        if body.outcome == "STARTED":
            conn.execute(
                """UPDATE refund_requests SET workflow_dispatch_status = ?, workflow_reference = ?,
                   workflow_dispatched_at = ?, workflow_error = '',
                   status = CASE WHEN status IN ('Queued for Workflow', 'Workflow Dispatching', 'Workflow Dispatch Failed') THEN ? ELSE status END,
                   status_notes = CASE WHEN status IN ('Queued for Workflow', 'Workflow Dispatching', 'Workflow Dispatch Failed') THEN ? ELSE status_notes END,
                   updated_at = ? WHERE request_id = ?""",
                (dispatch_status, workflow_reference, timestamp, new_status, note, timestamp, request_id),
            )
        else:
            conn.execute(
                "UPDATE refund_requests SET workflow_dispatch_status = ?, workflow_error = ?, status = CASE WHEN status = 'Refund Completed (Demo)' THEN status ELSE ? END, status_notes = CASE WHEN status = 'Refund Completed (Demo)' THEN status_notes ELSE ? END, updated_at = ? WHERE request_id = ?",
                (dispatch_status, error, new_status, note, timestamp, request_id),
            )
        log_activity(conn, "refund_requests", request_id, f"WORKFLOW_DISPATCH_{body.outcome}", note, "integration bridge")
        updated = conn.execute("SELECT * FROM refund_requests WHERE request_id = ?", (request_id,)).fetchone()
    publish_update("refund_requests", request_id, f"WORKFLOW_DISPATCH_{body.outcome}")
    return {"request": public_request(updated), "dispatch_status": dispatch_status}


@app.post("/api/admin/requests/{request_id}/requeue-start")
def admin_requeue_uncertain_start(request_id: str, body: ManualRequeueRequest) -> dict[str, Any]:
    """Explicitly requeue an uncertain/failed start only after an operator checks Camunda."""
    required_confirmation = "I VERIFIED NO PROCESS STARTED"
    if body.confirmation != required_confirmation:
        raise HTTPException(status_code=422, detail=f"Type the exact confirmation phrase: {required_confirmation}")
    timestamp = now_iso()
    with db_connection() as conn:
        row = conn.execute("SELECT * FROM refund_requests WHERE request_id = ?", (request_id,)).fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="Refund request not found.")
        current = str(row["workflow_dispatch_status"] or "")
        if current not in {"Unknown", "Dispatching", "Failed"}:
            raise HTTPException(status_code=409, detail=f"Only Unknown, stale Dispatching, or Failed starts can be manually requeued; current state is {current}.")
        if current == "Dispatching":
            try:
                claimed = datetime.fromisoformat(str(row["workflow_dispatch_claimed_at"] or "")).timestamp()
            except (ValueError, TypeError):
                claimed = 0
            if claimed > datetime.now(timezone.utc).timestamp() - 300:
                raise HTTPException(status_code=409, detail="This dispatch is still recent. Wait at least five minutes, verify Camunda, then retry.")
        if row["workflow_reference"]:
            raise HTTPException(status_code=409, detail="A workflow reference is already attached; this request must not be requeued.")
        conn.execute(
            """UPDATE refund_requests SET workflow_dispatch_status='Queued', workflow_dispatch_attempts=0,
               workflow_dispatch_claimed_at='', workflow_error='', workflow_reference='',
               status='Queued for Workflow', status_notes=?, updated_at=? WHERE request_id=?""",
            ("Admin manually requeued after explicitly verifying that no process instance was started.", timestamp, request_id),
        )
        log_activity(conn, "refund_requests", request_id, "WORKFLOW_START_MANUALLY_REQUEUED", "Admin explicitly verified that no Camunda process was started and requeued this request.", "local admin")
        updated = conn.execute("SELECT * FROM refund_requests WHERE request_id = ?", (request_id,)).fetchone()
        return {"request": public_request(updated), "dispatch_status": "Queued"}


@app.post("/api/admin/requests/{request_id}/send-to-review")
def admin_send_to_review(request_id: str) -> dict[str, Any]:
    """Allow an admin to send any refund request (including sub-₹5000) to the human review queue."""
    timestamp = now_iso()
    with db_connection() as conn:
        request = conn.execute("SELECT * FROM refund_requests WHERE request_id = ?", (request_id,)).fetchone()
        if not request:
            raise HTTPException(status_code=404, detail="Refund request not found.")
        existing = conn.execute("SELECT * FROM human_review_queue WHERE request_id = ?", (request_id,)).fetchone()
        if existing:
            review_id = existing["review_id"]
        else:
            review_id = make_id("REV")
            conn.execute(
                """INSERT INTO human_review_queue (review_id, request_id, review_reason, review_status,
                   workflow_event_status, created_at, updated_at) VALUES (?, ?, 'Manual review requested by admin', 'Pending Review', 'Not Applicable', ?, ?)""",
                (review_id, request_id, timestamp, timestamp),
            )
        conn.execute(
            """UPDATE refund_requests SET human_review_required = 1, status = 'Pending Human Review',
               status_notes = 'Sent to human review queue by administrator.', updated_at = ? WHERE request_id = ? AND status != 'Refund Completed (Demo)'""",
            (timestamp, request_id),
        )
        log_activity(conn, "human_review_queue", review_id, "REVIEW_QUEUED_BY_ADMIN", f"Manually sent to review: request {request_id}", "local admin")
        review = conn.execute("SELECT * FROM human_review_queue WHERE review_id = ?", (review_id,)).fetchone()
        request_updated = conn.execute("SELECT * FROM refund_requests WHERE request_id = ?", (request_id,)).fetchone()
    publish_update("human_review_queue", review_id, "REVIEW_QUEUED_BY_ADMIN")
    return {"review": dict(review), "request": public_request(request_updated)}


@app.post("/api/integration/requests/{request_id}/review-required")
def integration_review_required(
    request_id: str,
    body: ReviewRequiredFromWorkflow,
    x_integration_key: str = Header(default="", alias="X-Integration-Key"),
) -> dict[str, Any]:
    """Create a review item only when the external workflow selects its human-review path."""
    verify_integration(x_integration_key)
    timestamp = now_iso()
    with db_connection() as conn:
        request = conn.execute("SELECT * FROM refund_requests WHERE request_id = ?", (request_id,)).fetchone()
        if not request:
            raise HTTPException(status_code=404, detail="Refund request not found.")
        existing = conn.execute("SELECT * FROM human_review_queue WHERE request_id = ?", (request_id,)).fetchone()
        if existing:
            review_id = existing["review_id"]
        else:
            review_id = make_id("REV")
            conn.execute(
                """INSERT INTO human_review_queue (review_id, request_id, review_reason, review_status,
                   workflow_event_status, created_at, updated_at) VALUES (?, ?, ?, 'Pending Review', 'Not Applicable', ?, ?)""",
                (review_id, request_id, body.review_reason, timestamp, timestamp),
            )
        conn.execute(
            """UPDATE refund_requests SET human_review_required = 1, status = 'Pending Human Review',
               status_notes = ?, updated_at = ? WHERE request_id = ? AND status != 'Refund Completed (Demo)'""",
            ("The external workflow routed this request to human review. The application records the decision but does not execute the refund.", timestamp, request_id),
        )
        log_activity(conn, "human_review_queue", review_id, "REVIEW_QUEUED_BY_WORKFLOW", f"External workflow requested human review: {body.review_reason}", "integration bridge")
        review = conn.execute("SELECT * FROM human_review_queue WHERE review_id = ?", (review_id,)).fetchone()
        request_updated = conn.execute("SELECT * FROM refund_requests WHERE request_id = ?", (request_id,)).fetchone()
    publish_update("human_review_queue", review_id, "REVIEW_QUEUED_BY_WORKFLOW")
    return {"review": dict(review), "request": public_request(request_updated)}


@app.get("/api/integration/review-decisions/pending")
def integration_pending_review_decisions(
    limit: int = Query(default=100, ge=1, le=500),
    x_integration_key: str = Header(default="", alias="X-Integration-Key"),
) -> dict[str, Any]:
    verify_integration(x_integration_key)
    with db_connection() as conn:
        rows = conn.execute(
            """SELECT h.*, r.workflow_reference, r.request_id AS linked_request_id
               FROM human_review_queue h JOIN refund_requests r ON r.request_id = h.request_id
               WHERE h.workflow_event_status = 'Pending' AND h.review_status IN ('Approved', 'Rejected')
               ORDER BY h.updated_at ASC LIMIT ?""",
            (limit,),
        ).fetchall()
    records = []
    for row in rows:
        item = dict(row)
        item["approval_checkbox"] = bool(item["approval_checkbox"])
        records.append(item)
    return {"records": records, "count": len(records)}


@app.post("/api/integration/review-decisions/{review_id}/ack")
def integration_ack_review_decision(
    review_id: str,
    x_integration_key: str = Header(default="", alias="X-Integration-Key"),
) -> dict[str, Any]:
    verify_integration(x_integration_key)
    timestamp = now_iso()
    with db_connection() as conn:
        row = conn.execute("SELECT * FROM human_review_queue WHERE review_id = ?", (review_id,)).fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="Review item not found.")
        if row["workflow_event_status"] != "Pending":
            return {"acknowledged": row["workflow_event_status"] == "Sent", "status": row["workflow_event_status"]}
        conn.execute("UPDATE human_review_queue SET workflow_event_status = 'Sent', workflow_event_dispatched_at = ?, updated_at = ? WHERE review_id = ?", (timestamp, timestamp, review_id))
        log_activity(conn, "human_review_queue", review_id, "REVIEW_DECISION_DELIVERED", "Human decision was delivered to the external workflow engine.", "integration bridge")
    publish_update("human_review_queue", review_id, "REVIEW_DECISION_DELIVERED")
    return {"acknowledged": True, "status": "Sent"}


@app.post("/api/integration/requests/{request_id}/workflow-result")
def integration_workflow_result(
    request_id: str,
    body: WorkflowResult,
    x_integration_key: str = Header(default="", alias="X-Integration-Key"),
) -> dict[str, Any]:
    """Persist a result reported by the external workflow after its own API task completes."""
    verify_integration(x_integration_key)
    timestamp = now_iso()
    status_map = {"SUCCESS": "Refund Completed (Demo)", "FAILED": "Refund API Failed - Retry Required", "REJECTED": "Rejected by Human"}
    final_status = status_map[body.status]
    final_outcome = {
        "SUCCESS": "SUCCESS — simulated refund completed; no real money moved.",
        "FAILED": "FAILED — external workflow did not confirm a successful demo refund.",
        "REJECTED": "REJECTED — request was rejected during human review; no refund API call should have occurred.",
    }[body.status]
    with db_connection() as conn:
        row = conn.execute("SELECT * FROM refund_requests WHERE request_id = ?", (request_id,)).fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="Refund request not found.")
        if row["status"] == "Refund Completed (Demo)" and body.status != "SUCCESS":
            raise HTTPException(status_code=409, detail="A confirmed successful transaction cannot be overwritten by a non-success result.")
        transaction_id = body.transaction_id if body.status == "SUCCESS" else row["refund_transaction_id"]
        error = body.message if body.status == "FAILED" else ""
        conn.execute(
            """UPDATE refund_requests SET status = ?, status_notes = ?, refund_transaction_id = ?,
               final_outcome = ?, failure_reason = ?, workflow_reference = CASE WHEN ? != '' THEN ? ELSE workflow_reference END,
               updated_at = ? WHERE request_id = ?""",
            (final_status, body.message or final_outcome, transaction_id, final_outcome, error,
             body.workflow_reference, body.workflow_reference, timestamp, request_id),
        )
        log_activity(conn, "refund_requests", request_id, "WORKFLOW_RESULT_RECEIVED", f"External workflow result {body.status}: {body.message or final_outcome}; transaction={transaction_id}", "integration bridge")
        updated = conn.execute("SELECT * FROM refund_requests WHERE request_id = ?", (request_id,)).fetchone()
    publish_update("refund_requests", request_id, "WORKFLOW_RESULT_RECEIVED")
    return {"request": public_request(updated), "status": final_status}


@app.websocket("/ws/updates")
async def websocket_updates(websocket: WebSocket) -> None:
    await ws_manager.connect(websocket)
    try:
        while True:
            # Optional client pings keep the connection alive; all actual messages are server push.
            await websocket.receive_text()
    except WebSocketDisconnect:
        ws_manager.disconnect(websocket)
    except Exception:
        ws_manager.disconnect(websocket)


# ----- Local data console APIs -----

@app.get("/api/admin/summary")
def admin_summary() -> dict[str, Any]:
    with db_connection() as conn:
        requests_total = conn.execute("SELECT COUNT(*) FROM refund_requests").fetchone()[0]
        pending_review = conn.execute("SELECT COUNT(*) FROM human_review_queue WHERE review_status = 'Pending Review'").fetchone()[0]
        ready = conn.execute("SELECT COUNT(*) FROM refund_requests WHERE human_approved = 1").fetchone()[0]
        master_total = conn.execute("SELECT COUNT(*) FROM product_customer_master").fetchone()[0]
        product_total = conn.execute("SELECT COUNT(*) FROM standard_products WHERE active = 1").fetchone()[0]
        demo_success = conn.execute("SELECT COUNT(*) FROM refund_requests WHERE status = 'Refund Completed (Demo)'").fetchone()[0]
        activity_total = conn.execute("SELECT COUNT(*) FROM activity_log").fetchone()[0]
        total_requested = conn.execute("SELECT COALESCE(SUM(refund_amount), 0) FROM refund_requests").fetchone()[0]
    return {
        "requests_total": requests_total,
        "pending_review": pending_review,
        "ready_for_processing": ready,
        "master_records": master_total,
        "products_total": product_total,
        "demo_refunds_succeeded": demo_success,
        "activity_events": activity_total,
        "total_requested_inr": round(float(total_requested), 2),
    }


@app.get("/api/admin/requests")
def admin_requests(
    q: str = Query(default="", max_length=200),
    status: str = Query(default="", max_length=100),
) -> dict[str, Any]:
    clauses: list[str] = []
    params: list[Any] = []
    if q.strip():
        like = f"%{q.strip()}%"
        clauses.append("(request_id LIKE ? OR customer_name LIKE ? OR customer_email LIKE ? OR order_id LIKE ? OR product LIKE ?)")
        params.extend([like] * 5)
    if status.strip():
        clauses.append("status = ?")
        params.append(status.strip())
    sql = "SELECT * FROM refund_requests"
    if clauses:
        sql += " WHERE " + " AND ".join(clauses)
    sql += " ORDER BY created_at DESC LIMIT 500"
    with db_connection() as conn:
        rows = conn.execute(sql, params).fetchall()
    return {"records": [public_request(row) for row in rows], "count": len(rows)}


@app.get("/api/admin/master-records")
def admin_master_records(q: str = Query(default="", max_length=200)) -> dict[str, Any]:
    sql = "SELECT * FROM product_customer_master"
    params: list[Any] = []
    if q.strip():
        like = f"%{q.strip()}%"
        sql += " WHERE order_id LIKE ? OR customer_id LIKE ? OR customer_name LIKE ? OR product_id LIKE ? OR product_name LIKE ?"
        params.extend([like] * 5)
    sql += " ORDER BY updated_at DESC LIMIT 500"
    with db_connection() as conn:
        rows = conn.execute(sql, params).fetchall()
    return {"records": [dict(row) for row in rows], "count": len(rows)}


@app.post("/api/admin/master-records", status_code=201)
def create_master_record(body: MasterRecordCreate) -> dict[str, Any]:
    master_id = make_id("MST")
    timestamp = now_iso()
    payload = body.model_dump()
    with db_connection() as conn:
        conn.execute(
            """INSERT INTO product_customer_master (
                master_record_id, order_id, customer_id, customer_name, customer_email, customer_phone,
                product_id, product_name, product_image_url, purchase_date, purchase_amount_inr,
                bank_account_reference, bank_account_last4, record_status, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                master_id, payload["order_id"], payload["customer_id"], payload["customer_name"], payload["customer_email"],
                payload["customer_phone"], payload["product_id"], payload["product_name"], payload["product_image_url"],
                payload["purchase_date"], payload["purchase_amount_inr"], payload["bank_account_reference"],
                payload["bank_account_last4"], payload["record_status"], timestamp, timestamp,
            ),
        )
        log_activity(conn, "product_customer_master", master_id, "MASTER_RECORD_CREATED", f"Master record created for order {payload['order_id']}.", "local admin")
        row = conn.execute("SELECT * FROM product_customer_master WHERE master_record_id = ?", (master_id,)).fetchone()
    publish_update("product_customer_master", master_id, "MASTER_RECORD_CREATED")
    return {"record": dict(row)}


@app.patch("/api/admin/master-records/{master_record_id}/status")
def update_master_status(master_record_id: str, body: dict[str, str]) -> dict[str, Any]:
    new_status = body.get("record_status", "")
    changed_by = body.get("changed_by", "local admin").strip() or "local admin"
    if new_status not in {"Active", "Inactive", "Needs Verification"}:
        raise HTTPException(status_code=422, detail="Invalid master record status.")
    timestamp = now_iso()
    with db_connection() as conn:
        row = conn.execute("SELECT * FROM product_customer_master WHERE master_record_id = ?", (master_record_id,)).fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="Master record not found.")
        conn.execute("UPDATE product_customer_master SET record_status = ?, updated_at = ? WHERE master_record_id = ?", (new_status, timestamp, master_record_id))
        log_activity(conn, "product_customer_master", master_record_id, "MASTER_STATUS_CHANGED", f"Master record status changed from '{row['record_status']}' to '{new_status}'.", changed_by)
        updated = conn.execute("SELECT * FROM product_customer_master WHERE master_record_id = ?", (master_record_id,)).fetchone()
    publish_update("product_customer_master", master_record_id, "MASTER_STATUS_CHANGED")
    return {"record": dict(updated)}


@app.get("/api/admin/review-queue")
def admin_review_queue(q: str = Query(default="", max_length=200)) -> dict[str, Any]:
    sql = """SELECT h.*, r.customer_name, r.customer_email, r.order_id, r.product,
                    r.refund_amount, r.status AS request_status, r.reason
             FROM human_review_queue h
             JOIN refund_requests r ON r.request_id = h.request_id"""
    params: list[Any] = []
    if q.strip():
        like = f"%{q.strip()}%"
        sql += " WHERE h.request_id LIKE ? OR r.customer_name LIKE ? OR r.order_id LIKE ? OR r.product LIKE ?"
        params.extend([like] * 4)
    sql += " ORDER BY CASE h.review_status WHEN 'Pending Review' THEN 0 ELSE 1 END, h.created_at DESC LIMIT 500"
    with db_connection() as conn:
        rows = conn.execute(sql, params).fetchall()
    records = []
    for row in rows:
        item = dict(row)
        item["approval_checkbox"] = bool(item["approval_checkbox"])
        item["refund_amount"] = float(item["refund_amount"])
        records.append(item)
    return {"records": records, "count": len(records)}


@app.patch("/api/admin/review-queue/{review_id}")
def update_review(review_id: str, body: ReviewUpdate) -> dict[str, Any]:
    """Record the human decision. The separate bridge forwards it to the running workflow."""
    timestamp = now_iso()
    approved = body.decision == "approve"
    checkbox = 1 if approved else 0
    review_status = "Approved" if approved else "Rejected" if body.decision == "reject" else "Pending Review"
    request_status = (
        "Human Approval Recorded - Awaiting Workflow" if approved else
        "Human Rejection Recorded - Awaiting Workflow" if body.decision == "reject" else
        "Pending Human Review"
    )
    notes = (
        "Human approval recorded. The separate workflow bridge must deliver the decision; this application does not initiate the refund."
        if approved else
        "Human rejection recorded. The separate workflow bridge must deliver the decision; this application does not execute the workflow."
        if body.decision == "reject" else
        "The request remains pending human review."
    )
    with db_connection() as conn:
        review = conn.execute("SELECT * FROM human_review_queue WHERE review_id = ?", (review_id,)).fetchone()
        if not review:
            raise HTTPException(status_code=404, detail="Review item not found.")
        request = conn.execute("SELECT * FROM refund_requests WHERE request_id = ?", (review["request_id"],)).fetchone()
        if not request:
            raise HTTPException(status_code=404, detail="Associated refund request not found.")
        final_statuses = {"Refund Completed (Demo)", "Rejected by Human", "Refund API Failed - Retry Required", "Workflow Dispatch Permanently Failed"}
        if request["status"] in final_statuses:
            raise HTTPException(status_code=409, detail="This workflow request is already in a final state. Its review decision cannot be changed.")
        if review["workflow_event_status"] == "Sent":
            raise HTTPException(status_code=409, detail="This review decision has already been sent to the workflow. Reset is no longer allowed.")
        previous = review["review_status"]
        event_status = "Pending" if body.decision in {"approve", "reject"} else "Not Applicable"
        conn.execute(
            """UPDATE human_review_queue SET approval_checkbox = ?, reviewer_id = ?, reviewer_decision = ?,
               reviewer_comments = ?, review_status = ?, workflow_event_status = ?, workflow_event_dispatched_at = '',
               reviewed_at = ?, updated_at = ? WHERE review_id = ?""",
            (checkbox, body.reviewer_id, body.decision.title(), body.comments, review_status, event_status,
             timestamp if body.decision != "pending" else "", timestamp, review_id),
        )
        conn.execute(
            """UPDATE refund_requests SET human_approved = ?, reviewer_id = ?, reviewer_decision = ?,
               reviewer_comments = ?, reviewed_at = ?, status = ?, status_notes = ?, updated_at = ?
               WHERE request_id = ?""",
            (checkbox, body.reviewer_id, body.decision.title(), body.comments,
             timestamp if body.decision != "pending" else "", request_status, notes, timestamp, review["request_id"]),
        )
        log_activity(conn, "human_review_queue", review_id, "HUMAN_REVIEW_DECISION", f"Review decision changed from '{previous}' to '{review_status}' by {body.reviewer_id}. Decision delivery: {event_status}. {body.comments}".strip(), body.reviewer_id)
        request_result = conn.execute("SELECT * FROM refund_requests WHERE request_id = ?", (review["request_id"],)).fetchone()
        review_result = conn.execute("SELECT * FROM human_review_queue WHERE review_id = ?", (review_id,)).fetchone()
        request_dict = public_request(request_result)
        review_dict = dict(review_result)
    publish_update("refund_requests", request_dict["request_id"], "HUMAN_REVIEW_DECISION")
    return {"review": review_dict, "request": request_dict, "workflow_event_queued": event_status == "Pending"}


@app.get("/api/admin/activity")
def admin_activity(limit: int = Query(default=200, ge=1, le=500)) -> dict[str, Any]:
    with db_connection() as conn:
        rows = conn.execute("SELECT * FROM activity_log ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
    return {"records": [dict(row) for row in rows], "count": len(rows)}


@app.post("/api/admin/wipe-data")
def admin_wipe_data(body: WipeDataRequest) -> dict[str, Any]:
    """Clear all local demo records after an explicit typed confirmation.

    The old activity log is cleared too, then a single reset event is recorded so
    the console can show that a wipe occurred. This endpoint is for local demos
    only; the admin console is intentionally not an authenticated production UI.
    """
    if body.confirmation != "WIPE RAINBOW CORP DATA":
        raise HTTPException(
            status_code=422,
            detail="Confirmation phrase did not match. No data was deleted.",
        )

    changed_by = body.changed_by.strip() or "local admin"
    with db_connection() as conn:
        deleted = {
            "refund_requests": conn.execute("SELECT COUNT(*) FROM refund_requests").fetchone()[0],
            "product_customer_master": conn.execute("SELECT COUNT(*) FROM product_customer_master").fetchone()[0],
            "human_review_queue": conn.execute("SELECT COUNT(*) FROM human_review_queue").fetchone()[0],
            "activity_log": conn.execute("SELECT COUNT(*) FROM activity_log").fetchone()[0],
        }
        # Delete children first because review_queue references refund_requests.
        conn.execute("DELETE FROM human_review_queue")
        conn.execute("DELETE FROM refund_requests")
        conn.execute("DELETE FROM product_customer_master")
        conn.execute("DELETE FROM activity_log")
        conn.execute("DELETE FROM sqlite_sequence WHERE name = 'activity_log'")
        log_activity(
            conn,
            "database",
            "local-demo",
            "DEMO_DATA_WIPED",
            (
                "Local demo data reset. Deleted "
                f"{deleted['refund_requests']} refund requests, "
                f"{deleted['product_customer_master']} master records, "
                f"{deleted['human_review_queue']} review items and "
                f"{deleted['activity_log']} prior activity events."
            ),
            changed_by,
        )
    publish_update("database", "local-demo", "DEMO_DATA_WIPED")
    return {
        "ok": True,
        "deleted": deleted,
        "message": "Demo data wiped. A single reset event remains in Activity Log.",
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=True)
